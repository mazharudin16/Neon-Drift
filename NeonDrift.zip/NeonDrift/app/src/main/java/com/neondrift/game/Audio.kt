package com.neondrift.game

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.*

/** Multi-layer engine: idle thump + RPM harmonics + tyre squeal + turbo whoosh */
class EngineAudio(private val g: Game) {
    private var track: AudioTrack? = null
    @Volatile private var running = false
    private var thread: Thread? = null
    private val sr = 22050

    fun start() {
        if (running) return
        try {
            val min = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            val t = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                .setAudioFormat(AudioFormat.Builder()
                    .setSampleRate(sr)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
                .setBufferSizeInBytes(maxOf(min, 8192))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            track = t; running = true; t.play()
            thread = Thread { loop(t) }.also { it.isDaemon = true; it.start() }
        } catch (_: Exception) { running = false }
    }

    private fun loop(t: AudioTrack) {
        val buf = ShortArray(512)
        // oscillator phases
        var ph1 = 0.0; var ph2 = 0.0; var ph3 = 0.0; var ph4 = 0.0
        var phSq = 0.0; var phTurbo = 0.0; var phIdle = 0.0
        // smoothed params
        var rpmS = 1000.0; var loadS = 0.0; var sqS = 0.0
        var nitS = 0.0; var volS = 0.5; var brkS = 0.0
        var lpF = 0.0; var lpF2 = 0.0  // low-pass filters
        var seed = 1234567

        while (running) {
            val c = g.car
            val active = g.state == 1 && g.ready
            val rpmT = if (active) c.rpm.toDouble().coerceIn(800.0, 8500.0) else 900.0
            val gasT = maxOf(g.touchGasAmt.toDouble(), if (g.keyGas) 1.0 else 0.0, g.padGas.toDouble())
            val loadT = if (active) gasT.coerceIn(0.0, 1.0) else 0.1
            val sqT = if (active) maxOf(c.rearSlip, c.frontSlip * 0.6f).toDouble().coerceIn(0.0, 1.0) *
                      (if (g.surf == 0) 1.0 else 0.3) else 0.0
            val nitT = if (g.nitroActive) 1.0 else 0.0
            val brkT = if (active) g.touchBrkAmt.toDouble() else 0.0
            val master = g.volume / 10.0

            for (i in 0 until buf.size / 2) {
                // Smooth params
                rpmS += (rpmT - rpmS) * 0.0006
                loadS += (loadT - loadS) * 0.004
                sqS   += (sqT - sqS)   * 0.006
                nitS  += (nitT - nitS) * 0.012
                brkS  += (brkT - brkS) * 0.008
                volS  += (master - volS) * 0.002

                val f = rpmS / 60.0  // fundamental freq (Hz)

                // Phase advance
                val dt = 1.0 / sr
                ph1 += 2.0 * PI * f * dt;        if (ph1 > 2*PI) ph1 -= 2*PI
                ph2 += 2.0 * PI * f * 2.0 * dt;  if (ph2 > 2*PI) ph2 -= 2*PI
                ph3 += 2.0 * PI * f * 4.0 * dt;  if (ph3 > 2*PI) ph3 -= 2*PI
                ph4 += 2.0 * PI * f * 0.5 * dt;  if (ph4 > 2*PI) ph4 -= 2*PI
                phIdle += 2.0 * PI * 28.0 * dt;  if (phIdle > 2*PI) phIdle -= 2*PI
                phSq   += 2.0 * PI * (1800.0 + 600.0*sqS) * dt; if (phSq > 2*PI) phSq -= 2*PI
                phTurbo += 2.0 * PI * (120.0 + rpmS*0.015) * dt; if (phTurbo > 2*PI) phTurbo -= 2*PI

                // White noise
                seed = seed * 1103515245 + 12345
                val noise = ((seed shr 15) and 0xFFFF) / 32768.0 - 1.0
                // Low-pass noise for body rumble
                lpF  += (noise - lpF)  * 0.08
                lpF2 += (lpF   - lpF2) * 0.15

                // --- Engine layers ---
                // 1. Fundamental + odd harmonics (diesel-like thump)
                val fund = sin(ph1) * 0.55 + sin(ph1 * 3) * 0.18 + sin(ph1 * 5) * 0.08
                // 2. Even harmonics (sportier at high RPM)
                val even = sin(ph2) * 0.35 + sin(ph3) * 0.15
                val rpmFactor = ((rpmS - 1000.0) / 7000.0).coerceIn(0.0, 1.0)
                // 3. Idle thump (low freq body shake)
                val idle = sin(phIdle) * 0.4 * (1.0 - rpmFactor * 0.7)
                // 4. Load noise (intake/exhaust noise under load)
                val loadNoise = lpF2 * loadS * 0.4
                // 5. Turbo whoosh
                val turbo = sin(phTurbo) * nitS * 0.3 + noise * nitS * 0.15
                // Mix engine
                val engine = (fund * (0.5 + loadS * 0.5) +
                              even * rpmFactor +
                              idle + loadNoise + turbo) *
                             (0.55 + loadS * 0.35)

                // 6. Tyre squeal
                val squeal = if (sqS > 0.2) {
                    (sin(phSq) * 0.5 + noise * 0.5) * (sqS - 0.2) * 0.6
                } else 0.0

                // 7. Brake squeak
                val brakeNoise = if (brkS > 0.3 && rpmS < 2000.0) noise * brkS * 0.08 else 0.0

                // 8. Nitro crackle
                val crackle = if (nitS > 0.5 && i % 7 == 0) noise * 0.25 else 0.0

                // Final mix
                val mix = (engine + squeal + brakeNoise + crackle) * volS
                val out = mix.coerceIn(-1.0, 1.0)
                val s = (out * 15000).toInt().toShort()

                // Stereo (slight L/R variation for width)
                buf[i * 2]     = s
                buf[i * 2 + 1] = ((out * 0.95) * 15000).toInt().toShort()
            }
            t.write(buf, 0, buf.size)
        }
    }

    fun stop() {
        running = false
        try { thread?.join(300) } catch (_: Exception) {}
        try { track?.stop(); track?.release() } catch (_: Exception) {}
        track = null; thread = null
    }
}
