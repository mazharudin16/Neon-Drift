package com.neondrift.game

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.*

/** Synthesised engine + soft tyre squeal. Engine is the main sound; squeal is kept quiet. */
class EngineAudio(private val g: Game) {
    private var track: AudioTrack? = null
    @Volatile private var running = false
    private var thread: Thread? = null
    private val sr = 22050

    fun start() {
        if (running) return
        try {
            val min = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val t = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(sr).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(max(min, 4096))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            track = t
            running = true
            t.play()
            thread = Thread {
                val buf = ShortArray(512)
                var ph = 0.0; var ph2 = 0.0; var sq = 0.0; var lp = 0.0
                var seed = 12345
                var rpmS = 1000.0; var volS = 0.0; var sqS = 0.0
                while (running) {
                    val c = g.car
                    val active = g.state == 1 && g.ready
                    val rpmT = if (active) c.rpm.toDouble() else 1000.0
                    val gasing = g.touchGasAmt > 0.05f || g.keyGas || g.padGas > 0.1f
                    val load = if (active) (if (gasing) max(0.35, g.touchGasAmt.toDouble()).coerceAtLeast(if (g.keyGas) 1.0 else 0.0) else 0.2) else 0.2
                    val surfMul = if (g.surf == 0) 1.0 else 0.35
                    val sqT = if (active) max(c.rearSlip, c.frontSlip * 0.7f).toDouble() * surfMul else 0.0
                    val nit = if (g.nitroActive) 1.0 else 0.0
                    val master = g.volume / 10.0
                    for (i in buf.indices) {
                        rpmS += (rpmT - rpmS) * 0.0005
                        volS += ((0.55 + 0.45 * load) - volS) * 0.0006
                        sqS += (sqT - sqS) * 0.0010
                        val f = rpmS / 60.0 * 2.0
                        ph += 2.0 * PI * f / sr; if (ph > 2 * PI) ph -= 2 * PI
                        ph2 += 2.0 * PI * (f * 0.5) / sr; if (ph2 > 2 * PI) ph2 -= 2 * PI
                        var s = 0.0
                        for (k in 1..8) s += sin(ph * k) / k * (if (k % 2 == 0) 0.8 else 1.0)
                        s += sin(ph2) * 0.7 + sin(ph * 0.5) * 0.5
                        seed = seed * 1103515245 + 12345
                        val n = ((seed shr 16) and 0x7fff) / 16384.0 - 1.0
                        lp += (n - lp) * 0.25
                        s = s * 0.30 + lp * (0.05 + 0.12 * load) + nit * lp * 0.18
                        sq += 2.0 * PI * (1500.0 + 350.0 * sqS) / sr; if (sq > 2 * PI) sq -= 2 * PI
                        val squeal = if (sqS > 0.35) (sin(sq) * 0.4 + lp * 0.6) * (sqS - 0.35) * 0.18 else 0.0
                        val out = (s * volS + squeal) * master
                        buf[i] = (out.coerceIn(-1.0, 1.0) * 15000).toInt().toShort()
                    }
                    t.write(buf, 0, buf.size)
                }
            }.also { it.isDaemon = true; it.start() }
        } catch (e: Exception) { running = false }
    }

    fun stop() {
        running = false
        try { thread?.join(300) } catch (_: Exception) {}
        try { track?.stop(); track?.release() } catch (_: Exception) {}
        track = null; thread = null
    }
}
