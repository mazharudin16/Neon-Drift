package com.neondrift.game

import kotlin.math.*
import kotlin.random.Random

const val HALF = 1600f
const val CH = 200f
const val NC = 16

/** Growable float list; 4 floats per entry. */
class FL {
    var a = FloatArray(64)
    var n = 0
    fun add(x: Float, y: Float, z: Float, w: Float) {
        if (n + 4 > a.size) a = a.copyOf(a.size * 2)
        a[n++] = x; a[n++] = y; a[n++] = z; a[n++] = w
    }
    val count: Int get() = n / 4
}

/** kind 0 asphalt, 1 dirt. marks: 0 none, 1 city street, 2 highway, 3 mountain/ring. */
class Road(val kind: Int, val width: Float, val pts: FloatArray, val closed: Boolean, val marks: Int, val city: Boolean, val spacing: Float)
class Building(val x: Float, val z: Float, val hx: Float, val hz: Float, val h: Float)

class ChunkData {
    var ground: MB? = MB()
    var road: MB? = MB()
    var marks: MB? = MB()
    val inst = Array(4) { FL() }   // pine, oak, tuft, rock : x z scale var
    val col = FL()                 // colliders: x z r 0
}

class World {
    val roads = ArrayList<Road>()
    val buildings = ArrayList<Building>()
    val chunks = Array(NC * NC) { ChunkData() }
    var outer: MB? = MB()
    var mountains: MB? = MB()
    val discs = ArrayList<FloatArray>()
    var ringIdx = 0
    val ring: Road get() = roads[ringIdx]
    val raceTrack: Road get() = roads[ringIdx + 1]

    private val ORG = -HALF - 200f
    private val GC = 24f
    private val GN = ceil((2 * HALF + 400f) / GC).toInt() + 1
    private var seg = FL()
    private var segRoad = IntArray(0)
    private var cellStart = IntArray(0)
    private var cellItems = IntArray(0)
    var lastRoad = -1

    private val rnd = Random(2024)
    private val streets = floatArrayOf(-650f, -520f, -390f, -260f, -130f, 0f, 130f, 260f, 390f, 520f, 650f)

    // ---------------------------------------------------------------- helpers
    private fun soft(v: Float): Float { val t = v.coerceIn(0f, 1f); return t * t * (3f - 2f * t) }
    private fun hash(ix: Int, iz: Int): Float {
        val h = sin(ix * 127.1f + iz * 311.7f) * 43758.5453f
        return h - floor(h)
    }
    fun vnoise(x: Float, z: Float): Float {
        val ix = floor(x).toInt(); val iz = floor(z).toInt()
        val fx = x - ix; val fz = z - iz
        val sx = fx * fx * (3f - 2f * fx); val sz = fz * fz * (3f - 2f * fz)
        val a = hash(ix, iz); val b = hash(ix + 1, iz); val c = hash(ix, iz + 1); val d = hash(ix + 1, iz + 1)
        return (a + (b - a) * sx) + ((c + (d - c) * sx) - (a + (b - a) * sx)) * sz
    }
    private fun boxF(x: Float, z: Float, x0: Float, x1: Float, z0: Float, z1: Float, s: Float) =
        soft(min(min(x - x0, x1 - x), min(z - z0, z1 - z)) / s)

    fun forestFactor(x: Float, z: Float): Float {
        val f = maxOf(boxF(x, z, -1560f, -120f, 780f, 1560f, 150f),
            boxF(x, z, -1560f, -650f, -1560f, -350f, 150f),
            boxF(x, z, 700f, 1560f, -1560f, -250f, 150f))
        return f * (0.30f + 0.70f * vnoise(x * 0.012f, z * 0.012f))
    }
    fun cityFactor(x: Float, z: Float) = soft(min(650f - abs(x), 650f - abs(z)) / 60f)
    fun cIdx(x: Float, z: Float): Int =
        ((z + HALF) / CH).toInt().coerceIn(0, NC - 1) * NC + ((x + HALF) / CH).toInt().coerceIn(0, NC - 1)

    // ---------------------------------------------------------------- roads
    private fun spline(c: Array<FloatArray>, closed: Boolean, spacing: Float): FloatArray {
        val m = c.size
        val segs = if (closed) m else m - 1
        val dx = ArrayList<Float>(); val dz = ArrayList<Float>()
        for (i in 0 until segs) {
            val p0 = c[if (closed) (i - 1 + m) % m else max(i - 1, 0)]
            val p1 = c[i]; val p2 = c[(i + 1) % m]
            val p3 = c[if (closed) (i + 2) % m else min(i + 2, m - 1)]
            for (s in 0 until 40) {
                val t = s / 40f; val t2 = t * t; val t3 = t2 * t
                for (k in 0..1) {
                    val v = 0.5f * (2f * p1[k] + (-p0[k] + p2[k]) * t + (2f * p0[k] - 5f * p1[k] + 4f * p2[k] - p3[k]) * t2 +
                        (-p0[k] + 3f * p1[k] - 3f * p2[k] + p3[k]) * t3)
                    if (k == 0) dx.add(v) else dz.add(v)
                }
            }
        }
        if (!closed) { dx.add(c[m - 1][0]); dz.add(c[m - 1][1]) }
        val d = dx.size
        val sn = if (closed) d else d - 1
        val cum = FloatArray(sn + 1)
        for (i in 0 until sn) { val j = (i + 1) % d; cum[i + 1] = cum[i] + hypot(dx[j] - dx[i], dz[j] - dz[i]) }
        val total = cum[sn]
        val n = if (closed) max(8, (total / spacing).roundToInt()) else max(2, ceil(total / spacing).toInt() + 1)
        val out = FloatArray(n * 2)
        var j = 0
        for (k in 0 until n) {
            val tg = if (closed) k * total / n else k * total / (n - 1)
            while (j < sn - 1 && cum[j + 1] < tg) j++
            val b = (j + 1) % d
            val f = (tg - cum[j]) / (cum[j + 1] - cum[j])
            out[k * 2] = dx[j] + (dx[b] - dx[j]) * f
            out[k * 2 + 1] = dz[j] + (dz[b] - dz[j]) * f
        }
        return out
    }

    private fun line(x0: Float, z0: Float, x1: Float, z1: Float, sp: Float): FloatArray {
        val l = hypot(x1 - x0, z1 - z0)
        val n = ceil(l / sp).toInt() + 1
        val o = FloatArray(n * 2)
        for (i in 0 until n) { val t = i / (n - 1f); o[i * 2] = x0 + (x1 - x0) * t; o[i * 2 + 1] = z0 + (z1 - z0) * t }
        return o
    }

    private fun pts(vararg v: Float): Array<FloatArray> = Array(v.size / 2) { floatArrayOf(v[it * 2], v[it * 2 + 1]) }

    private fun buildRoads() {
        for (s in streets) {
            roads.add(Road(0, 14f, line(s, -750f, s, 750f, 12f), false, 1, true, 12f))
            roads.add(Road(0, 14f, line(-750f, s, 750f, s, 12f), false, 1, true, 12f))
        }
        roads.add(Road(0, 20f, line(600f, 75f, 1550f, 75f, 12f), false, 2, false, 12f))
        roads.add(Road(0, 20f, line(-600f, 75f, -1550f, 75f, 12f), false, 2, false, 12f))
        roads.add(Road(0, 20f, line(75f, 600f, 75f, 1550f, 12f), false, 2, false, 12f))
        roads.add(Road(0, 20f, line(75f, -600f, 75f, -1550f, 12f), false, 2, false, 12f))
        ringIdx = roads.size
        roads.add(Road(0, 16f, spline(pts(850f, 0f, 800f, 300f, 640f, 560f, 300f, 780f, -100f, 850f, -450f, 700f, -760f, 420f,
            -860f, 40f, -780f, -330f, -520f, -640f, -120f, -800f, 280f, -780f, 640f, -600f, 830f, -300f), true, 4f), true, 3, false, 4f))
        // Dedicated race oval track
        roads.add(Road(0, 22f, spline(pts(
            350f, -1300f, 500f, -1280f, 620f, -1240f, 700f, -1160f, 720f, -1060f,
            700f, -960f, 620f, -880f, 500f, -840f, 350f, -820f, 200f, -840f,
            80f, -880f, 0f, -960f, -20f, -1060f, 0f, -1160f, 80f, -1240f, 200f, -1280f
        ), true, 4f), true, 2, false, 4f))
        roads.add(Road(0, 10f, spline(pts(75f, 1000f, -60f, 1090f, -240f, 1070f, -380f, 1150f, -330f, 1260f, -170f, 1290f, -60f, 1370f,
            -150f, 1470f, -340f, 1500f, -520f, 1430f, -560f, 1300f, -700f, 1250f, -860f, 1330f, -1000f, 1250f, -1120f, 1330f,
            -1250f, 1240f, -1180f, 1100f, -1300f, 1000f), false, 4f), false, 3, false, 4f))
        roads.add(Road(1, 9f, spline(pts(1000f, 75f, 1110f, -100f, 1030f, -280f, 1180f, -420f, 1330f, -360f, 1440f, -520f, 1330f, -700f,
            1150f, -650f, 1010f, -780f, 1120f, -960f, 1300f, -1050f, 1230f, -1220f, 1010f, -1180f, 850f, -1050f, 880f, -900f), false, 4f), false, 0, false, 4f))
        roads.add(Road(1, 9f, spline(pts(-1100f, -650f, -900f, -720f, -780f, -900f, -880f, -1100f, -1080f, -1180f, -1280f, -1080f,
            -1360f, -900f, -1260f, -720f), true, 4f), true, 0, false, 4f))
        discs.add(floatArrayOf(1150f, 750f, 95f))
        discs.add(floatArrayOf(-1000f, 350f, 80f))
    }

    private fun buildGrid() {
        seg = FL()
        val rid = ArrayList<Int>()
        for ((ri, r) in roads.withIndex()) {
            val n = r.pts.size / 2
            val cnt = if (r.closed) n else n - 1
            for (i in 0 until cnt) {
                val j = (i + 1) % n
                seg.add(r.pts[i * 2], r.pts[i * 2 + 1], r.pts[j * 2], r.pts[j * 2 + 1]); rid.add(ri)
            }
        }
        segRoad = rid.toIntArray()
        val sc = seg.count
        val cellOf = IntArray(sc)
        cellStart = IntArray(GN * GN + 1)
        for (s in 0 until sc) {
            val mx = (seg.a[s * 4] + seg.a[s * 4 + 2]) / 2f; val mz = (seg.a[s * 4 + 1] + seg.a[s * 4 + 3]) / 2f
            val cx = ((mx - ORG) / GC).toInt().coerceIn(0, GN - 1); val cz = ((mz - ORG) / GC).toInt().coerceIn(0, GN - 1)
            cellOf[s] = cz * GN + cx; cellStart[cellOf[s] + 1]++
        }
        for (i in 0 until GN * GN) cellStart[i + 1] += cellStart[i]
        val fill = cellStart.copyOf()
        cellItems = IntArray(sc)
        for (s in 0 until sc) cellItems[fill[cellOf[s]]++] = s
    }

    /** Distance from point to nearest road edge (negative = on road). Sets lastRoad. */
    fun roadClear(x: Float, z: Float): Float {
        val cx = ((x - ORG) / GC).toInt(); val cz = ((z - ORG) / GC).toInt()
        var best = 1e9f; lastRoad = -1
        for (dz in -1..1) for (dx in -1..1) {
            val gx = cx + dx; val gz = cz + dz
            if (gx < 0 || gz < 0 || gx >= GN || gz >= GN) continue
            val c = gz * GN + gx
            for (k in cellStart[c] until cellStart[c + 1]) {
                val s = cellItems[k]
                val x0 = seg.a[s * 4]; val z0 = seg.a[s * 4 + 1]; val vx = seg.a[s * 4 + 2] - x0; val vz = seg.a[s * 4 + 3] - z0
                val l2 = vx * vx + vz * vz
                val t = if (l2 > 0f) (((x - x0) * vx + (z - z0) * vz) / l2).coerceIn(0f, 1f) else 0f
                val px = x0 + vx * t - x; val pz = z0 + vz * t - z
                val d = sqrt(px * px + pz * pz) - roads[segRoad[s]].width / 2f
                if (d < best) { best = d; lastRoad = segRoad[s] }
            }
        }
        return best
    }

    /** 0 asphalt, 1 dirt, 2 grass */
    fun surfaceAt(x: Float, z: Float): Int {
        for (d in discs) { val dx = x - d[0]; val dz = z - d[1]; if (dx * dx + dz * dz < d[2] * d[2]) return 0 }
        if (abs(x) < 68f && abs(z) < 68f) return 0
        val c = roadClear(x, z)
        if (c < 1.0f && lastRoad >= 0) return roads[lastRoad].kind
        if (abs(x) < 650f && abs(z) < 650f) return 0
        return 2
    }

    // ---------------------------------------------------------------- buildings
    private val palette = arrayOf(
        floatArrayOf(0.85f, 0.85f, 0.87f), floatArrayOf(0.88f, 0.82f, 0.70f), floatArrayOf(0.72f, 0.45f, 0.38f),
        floatArrayOf(0.62f, 0.70f, 0.82f), floatArrayOf(0.78f, 0.78f, 0.72f), floatArrayOf(0.55f, 0.58f, 0.62f))

    private fun addBuilding(x: Float, z: Float, hx: Float, hz: Float, h: Float) {
        buildings.add(Building(x, z, hx, hz, h))
        val mb = chunks[cIdx(x, z)].ground!!
        val c = palette[rnd.nextInt(palette.size)]
        mb.box(x, h / 2f, z, hx, h / 2f, hz, col(c[0], c[1], c[2]), 1f / 25.6f, 1f / 28.8f, rnd.nextFloat(), rnd.nextFloat())
        mb.box(x, h + 0.5f, z, hx * 0.55f, 0.5f, hz * 0.55f, col(0.45f, 0.45f, 0.47f))
        if (h > 60f) mb.box(x + hx * 0.3f, h + 4f, z, 0.25f, 4f, 0.25f, col(0.8f, 0.1f, 0.1f, 0.3f))
    }

    private fun genCity() {
        for (bi in -5..5) for (bj in -5..5) {
            if (abs(bi) <= 1 && abs(bj) <= 1) continue
            val bx = bi * 130f; val bz = bj * 130f
            for (lx in -1..1 step 2) for (lz in -1..1 step 2) {
                val cx = bx + lx * 28f; val cz = bz + lz * 28f
                if (rnd.nextFloat() < 0.92f) {
                    val hx = 11f + rnd.nextFloat() * 16f; val hz = 11f + rnd.nextFloat() * 16f
                    val dc = hypot(cx, cz)
                    val h = if (dc < 200f) 80f + rnd.nextFloat() * 140f else if (dc < 380f) 45f + rnd.nextFloat() * 80f else if (dc < 550f) 20f + rnd.nextFloat() * 40f else 10f + rnd.nextFloat() * 25f
                    addBuilding(cx, cz, hx, hz, h)
                } else {
                    val ch = chunks[cIdx(cx, cz)]
                    for (k in 0..2) {
                        val tx = cx + (rnd.nextFloat() - 0.5f) * 36f; val tz = cz + (rnd.nextFloat() - 0.5f) * 36f
                        val s = 0.9f + rnd.nextFloat() * 0.4f
                        ch.inst[1].add(tx, tz, s, rnd.nextFloat()); ch.col.add(tx, tz, 0.5f * s, 0f)
                    }
                }
            }
        }
    }

    private fun genHouses() {
        var made = 0; var tries = 0
        val spots = ArrayList<FloatArray>()
        while (made < 90 && tries < 4000) {
            tries++
            val x = rnd.nextFloat() * 3000f - 1500f; val z = rnd.nextFloat() * 3000f - 1500f
            if (abs(x) < 720f && abs(z) < 720f) continue
            if (forestFactor(x, z) > 0.25f) continue
            if (roadClear(x, z) < 16f) continue
            var ok = true
            for (s in spots) if (abs(s[0] - x) < 30f && abs(s[1] - z) < 30f) { ok = false; break }
            for (d in discs) if (hypot(x - d[0], z - d[1]) < d[2] + 25f) { ok = false; break }
            if (!ok) continue
            spots.add(floatArrayOf(x, z)); made++
            val hw = 5.5f + rnd.nextFloat() * 2.5f
            buildings.add(Building(x, z, hw, hw, 5f))
            val mb = chunks[cIdx(x, z)].ground!!
            val wc = if (rnd.nextBoolean()) col(0.92f, 0.88f, 0.78f) else col(0.80f, 0.86f, 0.90f)
            mb.box(x, 2.5f, z, hw, 2.5f, hw, wc)
            val rc = col(0.55f, 0.20f, 0.15f)
            mb.cylY(x, 5f, z, hw * 1.55f, 0f, 3.4f, 4, rc, col(0.62f, 0.25f, 0.18f), (PI / 4).toFloat())
            mb.box(x + hw * 0.4f, 1.1f, z + hw + 0.02f, 0.7f, 1.1f, 0.05f, col(0.25f, 0.15f, 0.08f))
        }
    }

    // ---------------------------------------------------------------- ground
    private val tmpA = FloatArray(3); private val tmpB = FloatArray(3); private val tmpC = FloatArray(3); private val tmpD = FloatArray(3)

    private fun groundCol(x: Float, z: Float, out: FloatArray) {
        val n1 = vnoise(x * 0.004f, z * 0.004f); val n2 = vnoise(x * 0.02f + 50f, z * 0.02f)
        var r = 0.20f + 0.15f * n1; var g = 0.40f + 0.13f * n1; var b = 0.09f + 0.04f * n1
        val dry = soft((n2 - 0.62f) * 5f)
        r += dry * 0.22f; g += dry * 0.06f; b += dry * 0.03f
        val f = forestFactor(x, z)
        r *= 1f - 0.35f * f; g *= 1f - 0.30f * f; b *= 1f - 0.25f * f
        val c = cityFactor(x, z)
        out[0] = r * (1f - c) + 0.50f * c; out[1] = g * (1f - c) + 0.50f * c; out[2] = b * (1f - c) + 0.51f * c
    }

    private fun genGround() {
        val q = 50f
        for (ci in 0 until NC * NC) {
            val mb = chunks[ci].ground!!
            val x0 = -HALF + (ci % NC) * CH; val z0 = -HALF + (ci / NC) * CH
            for (i in 0 until 4) for (j in 0 until 4) {
                val ax = x0 + i * q; val az = z0 + j * q; val bx = ax + q; val bz = az + q
                groundCol(ax, az, tmpA); groundCol(bx, az, tmpB); groundCol(bx, bz, tmpC); groundCol(ax, bz, tmpD)
                val flag = if (cityFactor(ax + q / 2, az + q / 2) > 0.5f) -1f else -2f
                mb.gq(ax, az, bx, bz, 0f, tmpA.copyOf(), tmpB.copyOf(), tmpC.copyOf(), tmpD.copyOf(), flag)
            }
        }
        outer!!.flat(-9000f, -9000f, 9000f, -9000f, 9000f, 9000f, -9000f, 9000f, -0.15f, col(0.24f, 0.40f, 0.13f))
    }

    // ---------------------------------------------------------------- road meshes
    private fun nearStreet(c: Float): Boolean { for (s in streets) if (abs(c - s) < 16f) return true; return false }

    private fun emitRoad(r: Road) {
        val n = r.pts.size / 2
        val cnt = if (r.closed) n else n - 1
        val hw = r.width / 2f
        val grp = max(1, (8f / r.spacing).roundToInt())
        val horizontal = abs(r.pts[(n - 1) * 2] - r.pts[0]) > abs(r.pts[(n - 1) * 2 + 1] - r.pts[1])
        fun dirAt(k: Int, out: FloatArray) {
            val a = if (r.closed) (k - 1 + n) % n else max(k - 1, 0)
            val b = if (r.closed) (k + 1) % n else min(k + 1, n - 1)
            val dx = r.pts[b * 2] - r.pts[a * 2]; val dz = r.pts[b * 2 + 1] - r.pts[a * 2 + 1]
            val l = hypot(dx, dz).coerceAtLeast(0.001f)
            out[0] = dx / l; out[1] = dz / l
        }
        val d0 = FloatArray(2); val d1 = FloatArray(2)
        for (i in 0 until cnt) {
            val j = (i + 1) % n
            val x0 = r.pts[i * 2]; val z0 = r.pts[i * 2 + 1]; val x1 = r.pts[j * 2]; val z1 = r.pts[j * 2 + 1]
            dirAt(i, d0); dirAt(j, d1)
            val lx0 = d0[1]; val lz0 = -d0[0]; val lx1 = d1[1]; val lz1 = -d1[0]
            val mx = (x0 + x1) / 2f; val mz = (z0 + z1) / 2f
            val cd = chunks[cIdx(mx, mz)]
            val road = cd.road!!; val marks = cd.marks!!
            fun strip(mb: MB, o0: Float, o1: Float, y: Float, c: FloatArray) {
                mb.flat(x0 + lx0 * o0, z0 + lz0 * o0, x0 + lx0 * o1, z0 + lz0 * o1,
                    x1 + lx1 * o1, z1 + lz1 * o1, x1 + lx1 * o0, z1 + lz1 * o0, y, c)
            }
            val v = rnd.nextFloat() * 0.025f
            if (r.kind == 0) strip(road, -hw, hw, 0.04f, col(0.17f + v, 0.17f + v, 0.19f + v))
            else strip(road, -hw, hw, 0.04f, col(0.46f + v, 0.34f + v, 0.21f + v))
            val on = (i / grp) % 2 == 0
            val white = col(0.92f, 0.92f, 0.94f, 0.05f); val yellow = col(0.95f, 0.78f, 0.15f, 0.05f)
            when (r.marks) {
                1 -> {
                    strip(road, hw, hw + 6f, 0.04f, col(0.62f, 0.62f, 0.60f)); strip(road, -hw - 6f, -hw, 0.04f, col(0.62f, 0.62f, 0.60f))
                    strip(marks, hw, hw + 0.4f, 0.05f, col(0.78f, 0.78f, 0.76f)); strip(marks, -hw - 0.4f, -hw, 0.05f, col(0.78f, 0.78f, 0.76f))
                    val along = if (horizontal) mx else mz
                    if (on && !nearStreet(along)) strip(marks, -0.12f, 0.12f, 0.05f, white)
                    if (i % 2 == 0 && !nearStreet(along)) for (sd in -1..1 step 2) {
                        val tx = mx + (if (horizontal) 0f else sd * (hw + 3.2f)); val tz = mz + (if (horizontal) sd * (hw + 3.2f) else 0f)
                        val s = 0.85f + rnd.nextFloat() * 0.3f
                        cd.inst[1].add(tx, tz, s, rnd.nextFloat()); cd.col.add(tx, tz, 0.5f * s, 0f)
                    }
                }
                2 -> {
                    strip(marks, hw - 1.0f, hw - 0.7f, 0.05f, white); strip(marks, -hw + 0.7f, -hw + 1.0f, 0.05f, white)
                    strip(marks, -0.4f, -0.1f, 0.05f, yellow); strip(marks, 0.1f, 0.4f, 0.05f, yellow)
                    if (on) { strip(marks, hw / 2f - 0.12f, hw / 2f + 0.12f, 0.05f, white); strip(marks, -hw / 2f - 0.12f, -hw / 2f + 0.12f, 0.05f, white) }
                    strip(road, hw, hw + 2.5f, 0.04f, col(0.30f, 0.29f, 0.26f)); strip(road, -hw - 2.5f, -hw, 0.04f, col(0.30f, 0.29f, 0.26f))
                }
                3 -> {
                    strip(marks, hw - 0.9f, hw - 0.65f, 0.05f, white); strip(marks, -hw + 0.65f, -hw + 0.9f, 0.05f, white)
                    if (on) strip(marks, -0.12f, 0.12f, 0.05f, yellow)
                    val kc = if (on) col(0.85f, 0.12f, 0.12f) else col(0.92f, 0.92f, 0.94f)
                    strip(marks, hw, hw + 0.8f, 0.06f, kc); strip(marks, -hw - 0.8f, -hw, 0.06f, kc)
                }
                else -> {
                    val tk = col(0.30f, 0.21f, 0.12f)
                    strip(marks, -2.1f, -1.2f, 0.05f, tk); strip(marks, 1.2f, 2.1f, 0.05f, tk)
                }
            }
        }
    }

    private fun emitDiscs() {
        val plazaCh = chunks[cIdx(0f, 0f)]
        plazaCh.road!!.flat(-68f, -68f, 68f, -68f, 68f, 68f, -68f, 68f, 0.04f, col(0.16f, 0.16f, 0.18f))
        ring(plazaCh.marks!!, 0f, 0f, 20f, 0.7f, col(1f, 0.25f, 0.85f, 0.2f)); ring(plazaCh.marks!!, 0f, 0f, 44f, 0.6f, col(0.95f, 0.95f, 0.95f, 0.1f))
        for (d in discs) {
            val cd = chunks[cIdx(d[0], d[1])]
            cd.road!!.disc(d[0], 0.04f, d[1], d[2], 40, col(0.16f, 0.16f, 0.18f))
            ring(cd.marks!!, d[0], d[1], d[2] * 0.30f, 0.7f, col(1f, 0.25f, 0.85f, 0.2f))
            ring(cd.marks!!, d[0], d[1], d[2] * 0.65f, 0.6f, col(0.95f, 0.95f, 0.95f, 0.1f))
            ring(cd.marks!!, d[0], d[1], d[2] - 1.5f, 0.8f, col(0.95f, 0.78f, 0.15f, 0.1f))
        }
    }

    private fun ring(mb: MB, cx: Float, cz: Float, r: Float, w: Float, c: FloatArray) {
        val seg = 48
        for (i in 0 until seg) {
            val a0 = (2.0 * PI * i / seg).toFloat(); val a1 = (2.0 * PI * (i + 1) / seg).toFloat()
            mb.flat(cx + sin(a0) * r, cz + cos(a0) * r, cx + sin(a0) * (r + w), cz + cos(a0) * (r + w),
                cx + sin(a1) * (r + w), cz + cos(a1) * (r + w), cx + sin(a1) * r, cz + cos(a1) * r, 0.05f, c)
        }
    }

    // ---------------------------------------------------------------- props
    private fun scatter() {
        for (ci in 0 until NC * NC) {
            val cd = chunks[ci]
            val x0 = -HALF + (ci % NC) * CH; val z0 = -HALF + (ci / NC) * CH
            repeat(300) {
                val x = x0 + rnd.nextFloat() * CH; val z = z0 + rnd.nextFloat() * CH
                if (cityFactor(x, z) > 0.2f) return@repeat
                if (roadClear(x, z) < 1.5f) return@repeat
                cd.inst[2].add(x, z, 0.8f + rnd.nextFloat() * 0.9f, rnd.nextFloat())
            }
            repeat(230) {
                val x = x0 + rnd.nextFloat() * CH; val z = z0 + rnd.nextFloat() * CH
                if (rnd.nextFloat() > forestFactor(x, z)) return@repeat
                if (roadClear(x, z) < 3.5f) return@repeat
                val s = 0.8f + rnd.nextFloat() * 0.7f
                cd.inst[0].add(x, z, s, rnd.nextFloat()); cd.col.add(x, z, 0.5f * s, 0f)
            }
            repeat(16) {
                val x = x0 + rnd.nextFloat() * CH; val z = z0 + rnd.nextFloat() * CH
                if (forestFactor(x, z) > 0.3f || cityFactor(x, z) > 0.1f) return@repeat
                if (roadClear(x, z) < 5f) return@repeat
                val s = 0.8f + rnd.nextFloat() * 0.6f
                cd.inst[1].add(x, z, s, rnd.nextFloat()); cd.col.add(x, z, 0.5f * s, 0f)
            }
            repeat(9) {
                val x = x0 + rnd.nextFloat() * CH; val z = z0 + rnd.nextFloat() * CH
                if (cityFactor(x, z) > 0.1f) return@repeat
                if (roadClear(x, z) < 4f) return@repeat
                if (rnd.nextFloat() > 0.35f + forestFactor(x, z)) return@repeat
                val s = 0.7f + rnd.nextFloat() * 1.8f
                cd.inst[3].add(x, z, s, rnd.nextFloat()); cd.col.add(x, z, 0.9f * s, 0f)
            }
        }
    }

    private fun genMountains() {
        val mb = mountains!!
        for (k in 0 until 40) {
            val a = (2.0 * PI * k / 40).toFloat() + rnd.nextFloat() * 0.1f
            val rad = 2300f + rnd.nextFloat() * 500f
            val base = 420f + rnd.nextFloat() * 380f; val h = 260f + rnd.nextFloat() * 420f
            val cx = sin(a) * rad; val cz = cos(a) * rad
            mb.cylY(cx, -2f, cz, base, base * 0.32f, h * 0.66f, 7, col(0.30f, 0.38f, 0.28f), col(0.45f, 0.46f, 0.50f), a)
            mb.cylY(cx, h * 0.66f - 2f, cz, base * 0.32f, 0f, h * 0.34f, 7, col(0.52f, 0.52f, 0.56f), col(0.96f, 0.97f, 1.0f), a)
        }
    }

    // ---------------------------------------------------------------- collisions
    fun collide(c: CarPhysics): Float {
        var impact = 0f
        val sn = sin(c.psi); val cs = cos(c.psi)
        val rad = 1.0f
        val ci = ((c.x + HALF) / CH).toInt(); val cj = ((c.z + HALF) / CH).toInt()
        for (off in OFFS) {
            val px = c.x + sn * off; val pz = c.z + cs * off
            for (bd in buildings) {
                if (abs(px - bd.x) > bd.hx + 3f || abs(pz - bd.z) > bd.hz + 3f) continue
                val qx = px.coerceIn(bd.x - bd.hx, bd.x + bd.hx); val qz = pz.coerceIn(bd.z - bd.hz, bd.z + bd.hz)
                val ddx = px - qx; val ddz = pz - qz
                val d2 = ddx * ddx + ddz * ddz
                if (d2 >= rad * rad) continue
                var nx = 0f; var nz = 0f; val pen: Float
                if (d2 < 1e-6f) {
                    val l = px - (bd.x - bd.hx); val r = (bd.x + bd.hx) - px; val t = pz - (bd.z - bd.hz); val bt = (bd.z + bd.hz) - pz
                    val m = min(min(l, r), min(t, bt))
                    if (m == l) nx = -1f else if (m == r) nx = 1f else if (m == t) nz = -1f else nz = 1f
                    pen = m + rad
                } else { val dd = sqrt(d2); nx = ddx / dd; nz = ddz / dd; pen = rad - dd }
                impact = max(impact, bounce(c, nx, nz, pen, sn, cs))
            }
            for (gz in cj - 1..cj + 1) for (gx in ci - 1..ci + 1) {
                if (gx < 0 || gz < 0 || gx >= NC || gz >= NC) continue
                val col = chunks[gz * NC + gx].col
                var k = 0
                while (k < col.n) {
                    val ox = col.a[k]; val oz = col.a[k + 1]; val rr = col.a[k + 2] + rad
                    k += 4
                    val dx = px - ox; val dz = pz - oz
                    val d2 = dx * dx + dz * dz
                    if (d2 < rr * rr) {
                        val d = sqrt(d2).coerceAtLeast(0.001f)
                        impact = max(impact, bounce(c, dx / d, dz / d, rr - d, sn, cs))
                    }
                }
            }
        }
        val lim = 1570f
        if (abs(c.x) > lim) { c.x = lim * c.x.sign; c.u *= 0.6f; c.v *= 0.6f; impact = max(impact, 6f) }
        if (abs(c.z) > lim) { c.z = lim * c.z.sign; c.u *= 0.6f; c.v *= 0.6f; impact = max(impact, 6f) }
        return impact
    }

    private fun bounce(c: CarPhysics, nx: Float, nz: Float, pen: Float, sn: Float, cs: Float): Float {
        c.x += nx * pen; c.z += nz * pen
        val vx = c.u * sn + c.v * cs; val vz = c.u * cs - c.v * sn
        val vn = vx * nx + vz * nz
        if (vn >= 0f) return 0f
        val nvx = (vx - 1.2f * vn * nx) * 0.97f; val nvz = (vz - 1.2f * vn * nz) * 0.97f
        c.u = nvx * sn + nvz * cs; c.v = nvx * cs - nvz * sn; c.r *= 0.75f
        return -vn
    }

    init {
        buildRoads()
        buildGrid()
        genCity()
        genHouses()
        genGround()
        for (r in roads) emitRoad(r)
        emitDiscs()
        scatter()
        genMountains()
    }


    fun nearest(x: Float, z: Float): Int {
        val p = ring.pts
        val n = p.size / 2
        var best = 0; var bd = Float.MAX_VALUE
        for (i in 0 until n) {
            val d = (p[i*2]-x)*(p[i*2]-x)+(p[i*2+1]-z)*(p[i*2+1]-z)
            if (d < bd) { bd = d; best = i }
        }
        return best
    }
    fun releaseMeshes() {
        for (c in chunks) { c.ground = null; c.road = null; c.marks = null }
        outer = null; mountains = null
    }

    companion object { private val OFFS = floatArrayOf(-1.5f, 0f, 1.5f) }
}
