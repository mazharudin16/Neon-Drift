package com.neondrift.game

import kotlin.math.*

/** Bicycle-model car with Pacejka-style tyres, weight transfer, friction circle and drift assist. */
class CarPhysics {
    var mass = 1300f
    var torque = 400f
    var muF = 1.15f
    var muR = 1.08f
    var nitroPower = 0.35f
    var gripMul = 1f
    var rollRes = 0f
    var powerMul = 1f
    var assist = 1.0f
    var ydamp = 2.6f

    val a = 1.25f
    val b = 1.35f
    private val h = 0.5f
    private val iz = 1900f

    var x = 0f; var z = 0f; var psi = 0f
    var u = 0f; var v = 0f; var r = 0f
    var ax = 0f; var ay = 0f
    var gear = 0; var rpm = 1000f
    var steerAngle = 0f
    var rearSlip = 0f; var frontSlip = 0f
    var wheelSpin = 0f
    var spinning = false

    val speed: Float get() = sqrt(u * u + v * v)
    val beta: Float get() = if (u > 2f) atan2(v, u) else 0f

    fun place(px: Float, pz: Float, heading: Float) {
        x = px; z = pz; psi = heading
        u = 0f; v = 0f; r = 0f; ax = 0f; ay = 0f; gear = 0
    }

    private fun tire(alpha: Float, d: Float): Float = -d * sin(1.5f * atan(9f * alpha))

    fun step(dt: Float, steerIn: Float, thr: Float, brk: Float, hb: Boolean, nitro: Boolean) {
        val g = 9.81f
        val l = a + b
        val nf = max(mass * g * b / l - mass * ax * h / l, mass * g * 0.15f)
        val nr = max(mass * g * a / l + mass * ax * h / l, mass * g * 0.15f)
        val au = abs(u)

        val dmax = 0.62f / (1f + (au / 22f).pow(1.6f)) + 0.12f
        val bet = if (u > 1f) atan2(v, u) else 0f
        val k = assist * ((au - 4f) / 8f).coerceIn(0f, 1f)
        val delta = (steerIn * dmax + k * bet).coerceIn(-0.65f, 0.65f)
        steerAngle = delta

        val ratio = GEARS[gear] * FD
        val rpmRaw = max(1100f, au / RW * ratio * 60f / (2f * PI.toFloat()))
        if (rpmRaw > 7300f && gear < 5) gear++
        if (rpmRaw < 3200f && gear > 0) gear--
        val tq = if (rpmRaw < 8200f) torque * max(0.35f, 1f - ((rpmRaw - 5300f) / 4600f).pow(2)) else 0f
        val nm = 1f + nitroPower * (if (nitro) 1f else 0f)
        var fxDem = thr * tq * powerMul * ratio * 0.9f / RW * nm
        if (u < -0.5f) fxDem = -brk * 3500f + thr * 5000f
        else if (u < 1f && brk > 0.3f && thr < 0.05f) fxDem = -brk * 3500f

        val mr = muR * gripMul * (if (hb) 0.32f else 1f)
        val dr = mr * nr
        val df = muF * gripMul * nf
        var fx = if (fxDem > 0f) min(fxDem, dr * 0.97f) else max(fxDem, -dr)
        spinning = fxDem > dr * 0.97f && thr > 0.3f
        val dlat = sqrt(max(dr * dr - fx * fx, (0.35f * dr) * (0.35f * dr)))

        val ua = max(au, 0.5f)
        val af = atan2(v + a * r, ua) - delta
        val ar = atan2(v - b * r, ua)
        val ff = tire(af, df)
        val fr = tire(ar, dlat)

        var fb = 0f
        if (brk > 0f && u > 1f) fb -= brk * min(0.95f * mass * g, 11000f)
        if (hb && u > 1f) fb -= 0.25f * dr
        val sgn = if (u > 0f) 1f else if (u < 0f) -1f else 0f
        val drag = 0.40f * u * au + 180f * sgn * min(1f, au) + rollRes * mass * 0.5f * sgn * min(1f, au)

        var fxt = fx + fb - ff * sin(delta) - drag
        if (thr > 0.5f && u > 8f && abs(bet) > 0.2f) fxt += mass * 1.2f * (abs(bet) / 0.6f).coerceAtMost(1f)

        val ud = fxt / mass + v * r
        val vd = (fr + ff * cos(delta)) / mass - u * r
        val rd = (a * ff * cos(delta) - b * fr) / iz - ydamp * r

        ax = 0.9f * ax + 0.1f * (fxt / mass)
        ay = 0.85f * ay + 0.15f * (vd + u * r)
        u += ud * dt; v += vd * dt; r += rd * dt
        psi += r * dt
        val s = sin(psi); val c = cos(psi)
        x += (u * s + v * c) * dt
        z += (u * c - v * s) * dt

        rpm = rpmRaw + (if (spinning) 1800f else 0f)
        val ws = if (spinning) max(u, 12f) else u
        wheelSpin += ws / RW * dt
        val moving = if (au > 3f) 1f else 0f
        rearSlip = maxOf(abs(ar) / 0.30f, if (spinning) 0.7f else 0f, if (hb) 1f else 0f).coerceIn(0f, 1f) * moving
        frontSlip = (abs(af) / 0.35f).coerceIn(0f, 1f) * moving
    }

    companion object {
        val GEARS = floatArrayOf(3.6f, 2.5f, 1.85f, 1.45f, 1.15f, 0.95f)
        const val FD = 3.7f
        const val RW = 0.33f
    }
}
