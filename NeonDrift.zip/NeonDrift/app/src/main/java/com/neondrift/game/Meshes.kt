package com.neondrift.game

import kotlin.math.*
import kotlin.random.Random

class MB {
    var d = FloatArray(1 shl 17)
    var n = 0
    val verts: Int get() = n / 12

    fun v(px: Float, py: Float, pz: Float, nx: Float, ny: Float, nz: Float,
          r: Float, g: Float, b: Float, e: Float, u: Float, w: Float) {
        if (n + 12 > d.size) d = d.copyOf(d.size * 2)
        d[n++]=px; d[n++]=py; d[n++]=pz; d[n++]=nx; d[n++]=ny; d[n++]=nz
        d[n++]=r;  d[n++]=g;  d[n++]=b;  d[n++]=e;  d[n++]=u;  d[n++]=w
    }

    fun quad(a: FloatArray, b: FloatArray, c: FloatArray, dd: FloatArray,
             nx: Float, ny: Float, nz: Float, col: FloatArray,
             u0: Float=-1f, v0: Float=-1f, u1: Float=-1f, v1: Float=-1f) {
        val r=col[0]; val g=col[1]; val bl=col[2]; val e=col[3]
        v(a[0],a[1],a[2],nx,ny,nz,r,g,bl,e,u0,v0)
        v(b[0],b[1],b[2],nx,ny,nz,r,g,bl,e,u1,v0)
        v(c[0],c[1],c[2],nx,ny,nz,r,g,bl,e,u1,v1)
        v(a[0],a[1],a[2],nx,ny,nz,r,g,bl,e,u0,v0)
        v(c[0],c[1],c[2],nx,ny,nz,r,g,bl,e,u1,v1)
        v(dd[0],dd[1],dd[2],nx,ny,nz,r,g,bl,e,u0,v1)
    }

    fun quadAuto(a: FloatArray, b: FloatArray, c: FloatArray, dd: FloatArray,
                 hx: Float, hy: Float, hz: Float, col: FloatArray) {
        val ux=b[0]-a[0]; val uy=b[1]-a[1]; val uz=b[2]-a[2]
        val wx=dd[0]-a[0]; val wy=dd[1]-a[1]; val wz=dd[2]-a[2]
        var nx=uy*wz-uz*wy; var ny=uz*wx-ux*wz; var nz=ux*wy-uy*wx
        val l=sqrt(nx*nx+ny*ny+nz*nz); if(l<1e-6f) return
        nx/=l; ny/=l; nz/=l
        val cx=(a[0]+b[0]+c[0]+dd[0])/4f-hx
        val cy=(a[1]+b[1]+c[1]+dd[1])/4f-hy
        val cz=(a[2]+b[2]+c[2]+dd[2])/4f-hz
        if(nx*cx+ny*cy+nz*cz<0f){nx=-nx;ny=-ny;nz=-nz}
        quad(a,b,c,dd,nx,ny,nz,col)
    }

    private fun p(x: Float, y: Float, z: Float) = floatArrayOf(x,y,z)

    fun box(cx: Float, cy: Float, cz: Float, hx: Float, hy: Float, hz: Float,
            col: FloatArray, texU: Float=0f, texV: Float=0f,
            uo: Float=0f, vo: Float=0f, bottom: Boolean=false) {
        val x0=cx-hx; val x1=cx+hx; val y0=cy-hy; val y1=cy+hy; val z0=cz-hz; val z1=cz+hz
        val t=texU>0f
        val uz=if(t) uo+2f*hz*texU else -1f; val ux=if(t) uo+2f*hx*texU else -1f
        val u0=if(t) uo else -1f; val v0b=if(t) vo else -1f; val v1=if(t) vo+2f*hy*texV else -1f
        quad(p(x1,y0,z0),p(x1,y0,z1),p(x1,y1,z1),p(x1,y1,z0),1f,0f,0f,col,u0,v0b,uz,v1)
        quad(p(x0,y0,z1),p(x0,y0,z0),p(x0,y1,z0),p(x0,y1,z1),-1f,0f,0f,col,u0,v0b,uz,v1)
        quad(p(x1,y0,z1),p(x0,y0,z1),p(x0,y1,z1),p(x1,y1,z1),0f,0f,1f,col,u0,v0b,ux,v1)
        quad(p(x0,y0,z0),p(x1,y0,z0),p(x1,y1,z0),p(x0,y1,z0),0f,0f,-1f,col,u0,v0b,ux,v1)
        quad(p(x0,y1,z0),p(x1,y1,z0),p(x1,y1,z1),p(x0,y1,z1),0f,1f,0f,col)
        if(bottom) quad(p(x0,y0,z1),p(x1,y0,z1),p(x1,y0,z0),p(x0,y0,z0),0f,-1f,0f,col)
    }

    fun flat(x0: Float, z0: Float, x1: Float, z1: Float,
             x2: Float, z2: Float, x3: Float, z3: Float, y: Float, col: FloatArray) {
        val p0=floatArrayOf(x0,y,z0); val p1=floatArrayOf(x1,y,z1)
        val p2=floatArrayOf(x2,y,z2); val p3=floatArrayOf(x3,y,z3)
        quad(p0,p1,p2,p3,0f,1f,0f,col)
    }

    fun loft(s: Array<FloatArray>, col: FloatArray) {
        for(i in 0 until s.size-1) {
            val a=s[i]; val b=s[i+1]
            val hy=(a[2]+a[3]+b[2]+b[3])/4f; val hz=(a[0]+b[0])/2f
            val p=fun(arr: FloatArray, side: Int, top: Boolean) =
                floatArrayOf(if(side==0) -arr[1] else arr[1], if(top) arr[3] else arr[2], arr[0])
            quadAuto(p(a,0,false),p(b,0,false),p(b,0,true),p(a,0,true),0f,hy,hz,col)
            quadAuto(p(a,1,false),p(b,1,false),p(b,1,true),p(a,1,true),0f,hy,hz,col)
            val top = arrayOf(p(a,0,true),p(a,1,true),p(b,1,true),p(b,0,true))
            quadAuto(top[0],top[1],top[2],top[3],0f,hy+1f,hz,col)
        }
    }

    fun cylX(cx: Float, cy: Float, cz: Float, rad: Float, hw: Float, seg: Int,
             col: FloatArray, caps: Boolean=true) {
        val r=col[0]; val g=col[1]; val b=col[2]; val e=col[3]
        for(i in 0 until seg) {
            val a0=(2.0*PI*i/seg).toFloat(); val a1=(2.0*PI*(i+1)/seg).toFloat()
            val y0=cos(a0); val z0=sin(a0); val y1=cos(a1); val z1=sin(a1)
            val ax=cx-hw; val bx=cx+hw
            v(ax,cy+y0*rad,cz+z0*rad,0f,y0,z0,r,g,b,e,-1f,-1f)
            v(bx,cy+y0*rad,cz+z0*rad,0f,y0,z0,r,g,b,e,-1f,-1f)
            v(bx,cy+y1*rad,cz+z1*rad,0f,y1,z1,r,g,b,e,-1f,-1f)
            v(ax,cy+y0*rad,cz+z0*rad,0f,y0,z0,r,g,b,e,-1f,-1f)
            v(bx,cy+y1*rad,cz+z1*rad,0f,y1,z1,r,g,b,e,-1f,-1f)
            v(ax,cy+y1*rad,cz+z1*rad,0f,y1,z1,r,g,b,e,-1f,-1f)
            if(caps) for(sgn in floatArrayOf(-1f,1f)) {
                val x=cx+sgn*hw
                v(x,cy,cz,sgn,0f,0f,r,g,b,e,-1f,-1f)
                v(x,cy+y0*rad,cz+z0*rad,sgn,0f,0f,r,g,b,e,-1f,-1f)
                v(x,cy+y1*rad,cz+z1*rad,sgn,0f,0f,r,g,b,e,-1f,-1f)
            }
        }
    }

    fun cylY(cx: Float, y0: Float, cz: Float, r0: Float, r1: Float, h: Float,
             seg: Int, cb: FloatArray, ct: FloatArray, rot: Float=0f) {
        val ny=(r0-r1)/h; val l=sqrt(1f+ny*ny)
        for(i in 0 until seg) {
            val a0=rot+(2.0*PI*i/seg).toFloat(); val a1=rot+(2.0*PI*(i+1)/seg).toFloat()
            val c0=cos(a0); val s0=sin(a0); val c1=cos(a1); val s1=sin(a1)
            v(cx+c0*r0,y0,cz+s0*r0,c0/l,ny/l,s0/l,cb[0],cb[1],cb[2],cb[3],-1f,-1f)
            v(cx+c1*r0,y0,cz+s1*r0,c1/l,ny/l,s1/l,cb[0],cb[1],cb[2],cb[3],-1f,-1f)
            v(cx+c1*r1,y0+h,cz+s1*r1,c1/l,ny/l,s1/l,ct[0],ct[1],ct[2],ct[3],-1f,-1f)
            v(cx+c0*r0,y0,cz+s0*r0,c0/l,ny/l,s0/l,cb[0],cb[1],cb[2],cb[3],-1f,-1f)
            v(cx+c1*r1,y0+h,cz+s1*r1,c1/l,ny/l,s1/l,ct[0],ct[1],ct[2],ct[3],-1f,-1f)
            v(cx+c0*r1,y0+h,cz+s0*r1,c0/l,ny/l,s0/l,ct[0],ct[1],ct[2],ct[3],-1f,-1f)
        }
    }

    fun disc(cx: Float, y: Float, cz: Float, r: Float, seg: Int, c: FloatArray) {
        for(i in 0 until seg) {
            val a0=(2.0*PI*i/seg).toFloat(); val a1=(2.0*PI*(i+1)/seg).toFloat()
            v(cx,y,cz,0f,1f,0f,c[0],c[1],c[2],c[3],-1f,-1f)
            v(cx+cos(a0)*r,y,cz+sin(a0)*r,0f,1f,0f,c[0],c[1],c[2],c[3],-1f,-1f)
            v(cx+cos(a1)*r,y,cz+sin(a1)*r,0f,1f,0f,c[0],c[1],c[2],c[3],-1f,-1f)
        }
    }

    fun gq(x0: Float, z0: Float, x1: Float, z1: Float, y: Float,
           c00: FloatArray, c10: FloatArray, c11: FloatArray, c01: FloatArray, flag: Float) {
        fun vv(x: Float, z: Float, c: FloatArray) = v(x,y,z,0f,1f,0f,c[0],c[1],c[2],0f,flag,flag)
        vv(x0,z0,c00); vv(x1,z0,c10); vv(x1,z1,c11)
        vv(x0,z0,c00); vv(x1,z1,c11); vv(x0,z1,c01)
    }
}

class CarMeshes(val paint: MB, val trim: MB, val glass: MB, val head: MB, val tail: MB, val wheel: MB)

fun col(r: Float, g: Float, b: Float, e: Float=0f) = floatArrayOf(r,g,b,e)

/** Build detailed car mesh. style 0=JDM coupe, 1=muscle, 2=sports */
fun buildCar(style: Int): CarMeshes {
    val paint=MB(); val trim=MB(); val glass=MB(); val head=MB(); val tail=MB(); val wheel=MB()
    val white=col(1f,1f,1f); val dark=col(0.03f,0.03f,0.035f)
    val chrome=col(0.75f,0.77f,0.80f); val rubber=col(0.04f,0.04f,0.045f)
    val glassC=col(0.06f,0.10f,0.14f); val grayD=col(0.12f,0.12f,0.14f)

    when(style) {
        1 -> buildMuscle(paint,trim,glass,head,tail,white,dark,chrome,glassC,grayD)
        2 -> buildSports(paint,trim,glass,head,tail,white,dark,chrome,glassC,grayD)
        else -> buildJDM(paint,trim,glass,head,tail,white,dark,chrome,glassC,grayD)
    }

    // Shared detailed wheel
    wheel.cylX(0f,0f,0f,0.33f,0.125f,20,rubber)
    wheel.cylX(0f,0f,0f,0.215f,0.128f,20,col(0.55f,0.57f,0.60f,0.08f))
    for(k in 0 until 5) {
        val a=(2.0*PI*k/5).toFloat()
        val y=cos(a)*0.10f; val z=sin(a)*0.10f
        for(sgn in floatArrayOf(-1f,1f)) {
            wheel.box(sgn*0.13f,y,z,0.012f,0.032f+abs(sin(a))*0.028f,0.032f+abs(cos(a))*0.028f,chrome)
            wheel.box(sgn*0.13f,y*0.5f,z*0.5f,0.008f,0.016f,0.016f,col(0.20f,0.20f,0.22f))
        }
    }
    wheel.disc(0f,0.13f,0f,0.20f,16,col(0.50f,0.52f,0.55f))
    wheel.disc(0f,-0.13f,0f,0.20f,16,col(0.50f,0.52f,0.55f))
    wheel.cylX(0f,0f,0f,0.08f,0.135f,10,col(0.30f,0.30f,0.32f))

    return CarMeshes(paint,trim,glass,head,tail,wheel)
}

private fun buildJDM(paint: MB, trim: MB, glass: MB, head: MB, tail: MB,
                     white: FloatArray, dark: FloatArray, chrome: FloatArray,
                     glassC: FloatArray, grayD: FloatArray) {
    // Low wide JDM coupe body sections
    val body = arrayOf(
        floatArrayOf(-2.20f,.82f,.30f,.92f), floatArrayOf(-1.85f,.93f,.28f,1.04f),
        floatArrayOf(-0.90f,.95f,.27f,1.06f), floatArrayOf(0.20f,.95f,.27f,1.04f),
        floatArrayOf(1.15f,.94f,.28f,.98f), floatArrayOf(1.90f,.88f,.30f,.72f),
        floatArrayOf(2.22f,.80f,.34f,.52f))
    val cabin = arrayOf(
        floatArrayOf(-1.40f,.74f,1.02f,1.08f), floatArrayOf(-0.60f,.78f,1.02f,1.50f),
        floatArrayOf(0.28f,.78f,1.02f,1.50f), floatArrayOf(0.88f,.76f,1.02f,1.14f))
    val roof = arrayOf(
        floatArrayOf(-0.55f,.64f,1.46f,1.50f), floatArrayOf(0.22f,.64f,1.46f,1.50f))
    paint.loft(body,white); paint.loft(roof,white)
    trim.loft(cabin,glassC)
    // Side skirts
    trim.box(0f,.32f,0f,.97f,.04f,2.0f,dark)
    trim.box(0f,.30f,2.18f,.80f,.06f,.08f,dark)
    trim.box(0f,.30f,-2.16f,.65f,.06f,.08f,dark)
    // Front bumper
    trim.box(0f,.46f,2.18f,.85f,.20f,.08f,dark)
    trim.box(0.55f,.55f,2.14f,.25f,.08f,.06f,col(.92f,.92f,.95f))
    trim.box(-0.55f,.55f,2.14f,.25f,.08f,.06f,col(.92f,.92f,.95f))
    // Rear diffuser
    trim.box(0f,.28f,-2.14f,.70f,.06f,.10f,grayD)
    trim.box(0.30f,.28f,-2.10f,.18f,.06f,.04f,dark)
    trim.box(-0.30f,.28f,-2.10f,.18f,.06f,.04f,dark)
    // Wing
    trim.box(0f,1.30f,-2.08f,.85f,.03f,.18f,dark)
    trim.box(0.62f,1.14f,-2.08f,.04f,.16f,.05f,dark)
    trim.box(-0.62f,1.14f,-2.08f,.04f,.16f,.05f,dark)
    // Headlights (quad LED style)
    head.box(0.62f,.62f,2.14f,.22f,.06f,.04f,col(.92f,.95f,1f,1f))
    head.box(0.62f,.72f,2.14f,.22f,.03f,.04f,col(.92f,.95f,1f,.8f))
    head.box(-0.62f,.62f,2.14f,.22f,.06f,.04f,col(.92f,.95f,1f,1f))
    head.box(-0.62f,.72f,2.14f,.22f,.03f,.04f,col(.92f,.95f,1f,.8f))
    // DRL strip
    head.box(0f,.78f,2.14f,.90f,.018f,.04f,col(1f,.95f,.85f,.6f))
    // Tail lights (full width LED bar)
    tail.box(0f,.88f,-2.14f,.88f,.055f,.035f,col(1f,.04f,.04f,1f))
    tail.box(0f,.78f,-2.14f,.55f,.025f,.035f,col(1f,.04f,.04f,.6f))
    // Exhaust
    trim.cylX(0.32f,.30f,-2.20f,.055f,.06f,10,chrome)
    trim.cylX(-0.32f,.30f,-2.20f,.055f,.06f,10,chrome)
    // Door handles
    trim.box(0.97f,.76f,0.40f,.012f,.025f,.08f,chrome)
    trim.box(0.97f,.76f,-0.25f,.012f,.025f,.08f,chrome)
    trim.box(-0.97f,.76f,0.40f,.012f,.025f,.08f,chrome)
    trim.box(-0.97f,.76f,-0.25f,.012f,.025f,.08f,chrome)
}

private fun buildMuscle(paint: MB, trim: MB, glass: MB, head: MB, tail: MB,
                        white: FloatArray, dark: FloatArray, chrome: FloatArray,
                        glassC: FloatArray, grayD: FloatArray) {
    val body = arrayOf(
        floatArrayOf(-2.40f,.84f,.36f,.96f), floatArrayOf(-1.90f,.96f,.33f,1.08f),
        floatArrayOf(-0.80f,.98f,.32f,1.10f), floatArrayOf(0.30f,.98f,.32f,1.06f),
        floatArrayOf(1.40f,.96f,.33f,.98f), floatArrayOf(2.10f,.90f,.36f,.78f),
        floatArrayOf(2.42f,.82f,.40f,.60f))
    val cabin = arrayOf(
        floatArrayOf(-1.10f,.76f,1.06f,1.12f), floatArrayOf(-0.50f,.80f,1.06f,1.55f),
        floatArrayOf(0.25f,.80f,1.06f,1.55f), floatArrayOf(0.70f,.77f,1.06f,1.15f))
    val roof = arrayOf(
        floatArrayOf(-0.48f,.67f,1.52f,1.56f), floatArrayOf(0.20f,.67f,1.52f,1.56f))
    paint.loft(body,white); paint.loft(roof,white)
    trim.loft(cabin,glassC)
    trim.box(0f,.38f,0f,1.00f,.06f,2.20f,dark)
    trim.box(0f,.44f,2.40f,.96f,.24f,.10f,dark)
    trim.box(0f,.65f,2.38f,.50f,.08f,.08f,col(.88f,.88f,.90f))
    // Hood scoop
    paint.box(0f,.98f,1.10f,.28f,.04f,.45f,white)
    paint.box(0f,1.00f,1.12f,.18f,.02f,.40f,dark)
    // Wide rear
    trim.box(0f,.32f,-2.38f,.85f,.08f,.12f,dark)
    tail.box(0f,.88f,-2.40f,.95f,.06f,.04f,col(1f,.03f,.03f,1f))
    tail.box(0.55f,.75f,-2.40f,.22f,.04f,.04f,col(1f,.03f,.03f,.7f))
    tail.box(-0.55f,.75f,-2.40f,.22f,.04f,.04f,col(1f,.03f,.03f,.7f))
    // Quad exhaust
    for(ox in listOf(.50f,.70f,-.50f,-.70f)) trim.cylX(ox,.32f,-2.44f,.048f,.06f,10,chrome)
    head.box(0.70f,.64f,2.40f,.20f,.07f,.04f,col(.92f,.95f,1f,1f))
    head.box(-0.70f,.64f,2.40f,.20f,.07f,.04f,col(.92f,.95f,1f,1f))
    head.box(0f,.78f,2.40f,.95f,.016f,.04f,col(1f,.92f,.75f,.5f))
    trim.box(0.97f,.80f,0.35f,.012f,.03f,.09f,chrome)
    trim.box(-0.97f,.80f,0.35f,.012f,.03f,.09f,chrome)
}

private fun buildSports(paint: MB, trim: MB, glass: MB, head: MB, tail: MB,
                        white: FloatArray, dark: FloatArray, chrome: FloatArray,
                        glassC: FloatArray, grayD: FloatArray) {
    val body = arrayOf(
        floatArrayOf(-2.08f,.78f,.28f,.88f), floatArrayOf(-1.70f,.90f,.26f,1.02f),
        floatArrayOf(-0.70f,.92f,.26f,1.04f), floatArrayOf(0.35f,.92f,.26f,.98f),
        floatArrayOf(1.22f,.90f,.27f,.80f), floatArrayOf(1.88f,.84f,.30f,.58f),
        floatArrayOf(2.10f,.76f,.34f,.46f))
    val cabin = arrayOf(
        floatArrayOf(-1.55f,.70f,.98f,1.04f), floatArrayOf(-0.95f,.76f,.98f,1.46f),
        floatArrayOf(0.10f,.76f,.98f,1.46f), floatArrayOf(0.78f,.73f,.98f,1.08f))
    val roof = arrayOf(
        floatArrayOf(-0.90f,.62f,1.42f,1.46f), floatArrayOf(0.05f,.62f,1.42f,1.46f))
    paint.loft(body,white); paint.loft(roof,white)
    trim.loft(cabin,glassC)
    trim.box(0f,.30f,0f,.93f,.04f,1.95f,dark)
    // Low front splitter
    trim.box(0f,.24f,2.06f,.90f,.02f,.12f,dark)
    trim.box(0f,.40f,2.08f,.80f,.18f,.08f,dark)
    // Center roof scoop (exotic feel)
    paint.box(0f,1.06f,0.10f,.12f,.03f,.55f,col(0.06f,0.06f,0.08f))
    // Side vents
    trim.box(0.95f,.55f,0.90f,.015f,.06f,.22f,dark)
    trim.box(-0.95f,.55f,0.90f,.015f,.06f,.22f,dark)
    // Large rear wing
    trim.box(0f,1.38f,-2.00f,.92f,.025f,.20f,dark)
    trim.box(0.65f,1.20f,-2.00f,.035f,.18f,.06f,dark)
    trim.box(-0.65f,1.20f,-2.00f,.035f,.18f,.06f,dark)
    // Diffuser fins
    for(i in -2..2) trim.box(i*0.14f,.24f,-2.08f,.018f,.06f,.14f,dark)
    tail.box(0f,.86f,-2.10f,.84f,.05f,.035f,col(1f,.04f,.04f,1f))
    tail.box(0f,.78f,-2.10f,.60f,.025f,.035f,col(1f,.04f,.04f,.5f))
    head.box(0.58f,.56f,2.08f,.24f,.055f,.04f,col(.92f,.95f,1f,1f))
    head.box(-0.58f,.56f,2.08f,.24f,.055f,.04f,col(.92f,.95f,1f,1f))
    head.box(0f,.70f,2.08f,.88f,.014f,.04f,col(1f,.94f,.80f,.5f))
    trim.cylX(0.28f,.28f,-2.14f,.05f,.06f,10,chrome)
    trim.cylX(-0.28f,.28f,-2.14f,.05f,.06f,10,chrome)
    trim.box(0.97f,.74f,0.30f,.012f,.025f,.08f,chrome)
    trim.box(-0.97f,.74f,0.30f,.012f,.025f,.08f,chrome)
}

fun buildProps(): Array<MB> {
    val pine=MB(); val oak=MB(); val tuft=MB(); val rock=MB()
    val brown=col(.28f,.18f,.10f); val brown2=col(.20f,.13f,.07f)
    pine.cylY(0f,0f,0f,.30f,.22f,2.6f,6,brown,brown2)
    pine.cylY(0f,1.7f,0f,2.5f,0f,3.4f,7,col(.05f,.20f,.08f),col(.11f,.34f,.13f))
    pine.cylY(0f,3.3f,0f,2.0f,0f,3.2f,7,col(.06f,.23f,.09f),col(.13f,.38f,.15f))
    pine.cylY(0f,4.8f,0f,1.4f,0f,3.0f,7,col(.07f,.26f,.10f),col(.15f,.42f,.17f))
    pine.disc(0f,.03f,0f,3.0f,10,col(.08f,.16f,.06f))
    oak.cylY(0f,0f,0f,.40f,.30f,3.2f,6,brown,brown2)
    oak.cylY(0f,2.4f,0f,1.2f,3.0f,1.2f,8,col(.08f,.26f,.07f),col(.14f,.38f,.09f))
    oak.cylY(0f,3.6f,0f,3.0f,2.2f,1.6f,8,col(.14f,.38f,.09f),col(.22f,.50f,.12f))
    oak.cylY(0f,5.2f,0f,2.2f,0f,2.0f,8,col(.22f,.50f,.12f),col(.30f,.60f,.15f))
    oak.disc(0f,.03f,0f,3.4f,10,col(.09f,.17f,.06f))
    val gb=col(.10f,.28f,.07f); val gt=col(.38f,.64f,.16f)
    for(k in 0 until 6) {
        val a=(PI*k/3.0).toFloat(); val ox=cos(a*1.7f)*.18f; val oz=sin(a*1.7f)*.18f
        val dx=cos(a)*.14f; val dz=sin(a)*.14f; val ht=.55f+.25f*((k*37)%5)/4f
        tuft.v(ox-dx,0f,oz-dz,0f,1f,0f,gb[0],gb[1],gb[2],0f,-1f,-1f)
        tuft.v(ox+dx,0f,oz+dz,0f,1f,0f,gb[0],gb[1],gb[2],0f,-1f,-1f)
        tuft.v(ox+dx*.2f+cos(a+1.5f)*.1f,ht,oz+dz*.2f,0f,1f,0f,gt[0],gt[1],gt[2],0f,-1f,-1f)
    }
    rock.cylY(0f,0f,0f,1.0f,.78f,.55f,6,col(.36f,.35f,.34f),col(.50f,.49f,.47f),.3f)
    rock.cylY(0f,.55f,0f,.78f,0f,.5f,6,col(.50f,.49f,.47f),col(.60f,.59f,.57f),.3f)
    return arrayOf(pine,oak,tuft,rock)
}

fun buildWorld(w: World, glows: ArrayList<FloatArray>, pools: ArrayList<Float>): MB {
    val mb=MB(); val rnd=Random(5)
    val ground=col(.020f,.022f,.032f)
    mb.flat(-9000f,-9000f,9000f,-9000f,9000f,9000f,-9000f,9000f,-.15f,col(.24f,.40f,.13f))
    val plaza=85; val seg=40
    for(i in 0 until seg) {
        val a0=(2.0*PI*i/seg).toFloat(); val a1=(2.0*PI*(i+1)/seg).toFloat()
        for((rA,rB,c) in arrayOf(Triple(0f,plaza.toFloat(),col(.06f,.06f,.075f)),
            Triple(plaza-3f,plaza-2.4f,col(.9f,.9f,1f,.3f)),
            Triple(46f,46.6f,col(.9f,.9f,1f,.3f)),Triple(20f,20.6f,col(1f,.2f,.9f,.6f)))) {
            mb.flat(sin(a0)*rA,cos(a0)*rA,sin(a0)*rB,cos(a0)*rB,
                sin(a1)*rB,cos(a1)*rB,sin(a1)*rA,cos(a1)*rA,
                if(rA>0f) .07f else .06f,c)
        }
    }
    val n=w.n; val hw=w.roadW/2f
    for(i in 0 until n) {
        val j=(i+1)%n
        val lx0=w.dirZ(i); val lz0=-w.dirX(i)
        val lx1=w.dirZ(j); val lz1=-w.dirX(j)
        val x0=w.tx[i]; val z0=w.tz[i]; val x1=w.tx[j]; val z1=w.tz[j]
        val shade=.065f+rnd.nextFloat()*.012f
        val asph=col(shade,shade,shade+.015f)
        fun strip(m: MB,o0: Float,o1: Float,y: Float,c: FloatArray) =
            m.flat(x0+lx0*o0,z0+lz0*o0,x0+lx0*o1,z0+lz0*o1,
                x1+lx1*o1,z1+lz1*o1,x1+lx1*o0,z1+lz1*o0,y,c)
        strip(mb,-hw,hw,.07f,asph)
        strip(mb,hw-1.1f,hw-.85f,.085f,col(.85f,.85f,.9f))
        strip(mb,-hw+.85f,-hw+1.1f,.085f,col(.85f,.85f,.9f))
        if(i%4<2) strip(mb,-.12f,.12f,.085f,col(.95f,.8f,.2f,.2f))
        strip(mb,hw,hw+.8f,.09f,if((i/2)%2==0) col(.9f,.1f,.1f,.1f) else col(.9f,.9f,.92f,.1f))
        strip(mb,-hw-.8f,-hw,.09f,if((i/2)%2==0) col(.9f,.1f,.1f,.1f) else col(.9f,.9f,.92f,.1f))
        strip(mb,hw+.8f,hw+6f,.08f,col(.11f,.11f,.13f))
        strip(mb,-hw-6f,-hw-.8f,.08f,col(.11f,.11f,.13f))
        if(i%14==0) {
            val side=if((i/14)%2==0) 1f else -1f; val off=side*(hw+2.2f)
            val px=x0+lx0*off; val pz=z0+lz0*off
            mb.box(px,3.6f,pz,.09f,3.6f,.09f,col(.08f,.08f,.10f))
            mb.box(px-lx0*side*1.0f,7.25f,pz-lz0*side*1.0f,.5f,.07f,.5f,col(1f,.85f,.55f,1f))
            glows.add(floatArrayOf(px-lx0*side,7.1f,pz-lz0*side,5.5f,1f,.75f,.4f))
            pools.add(px-lx0*side*5f); pools.add(pz-lz0*side*5f); pools.add(11f)
        }
    }
    val neon=arrayOf(floatArrayOf(1f,.15f,.85f),floatArrayOf(0f,.9f,1f),
        floatArrayOf(1f,.5f,.1f),floatArrayOf(.5f,1f,.2f),floatArrayOf(.6f,.3f,1f))
    for(b in w.buildings) {
        val t=.035f+rnd.nextFloat()*.04f
        val c=col(t,t,t+.025f+rnd.nextFloat()*.02f)
        mb.box(b.x,b.h/2f,b.z,b.hx,b.h/2f,b.hz,c,1f/25.6f,1f/28.8f,rnd.nextFloat(),rnd.nextFloat())
        mb.box(b.x,b.h+.4f,b.z,b.hx*.6f,.4f,b.hz*.6f,col(.03f,.03f,.04f))
        if(rnd.nextFloat()<.8f) {
            val nc=neon[rnd.nextInt(neon.size)]
            val sh=6f+rnd.nextFloat()*10f; val sy=8f+rnd.nextFloat()*(b.h*.6f)
            val ec=col(nc[0],nc[1],nc[2],1f)
            if(rnd.nextBoolean()) {
                val sx=b.x+(if(rnd.nextBoolean()) b.hx+.15f else -b.hx-.15f)
                mb.box(sx,sy,b.z+(rnd.nextFloat()-.5f)*b.hz,.12f,sh/2f,.7f,ec)
                glows.add(floatArrayOf(sx,sy,b.z,9f,nc[0],nc[1],nc[2]))
            } else {
                val sz=b.z+(if(rnd.nextBoolean()) b.hz+.15f else -b.hz-.15f)
                mb.box(b.x+(rnd.nextFloat()-.5f)*b.hx,sy,sz,.7f,sh/2f,.12f,ec)
                glows.add(floatArrayOf(b.x,sy,sz,9f,nc[0],nc[1],nc[2]))
            }
        }
        if(b.h>60f) glows.add(floatArrayOf(b.x,b.h+1.2f,b.z,4f,1f,.1f,.1f))
    }
    return mb
}
