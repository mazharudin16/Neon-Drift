package com.neondrift.game

import kotlin.math.*
import kotlin.random.Random

/** Mesh vertex: pos3 normal3 color4(rgb + emissive) uv2 = 12 floats. uv.x < 0 => untextured. */
class MB {
    var d = FloatArray(1 shl 16)
    var n = 0
    val verts: Int get() = n / 12

    fun v(px: Float, py: Float, pz: Float, nx: Float, ny: Float, nz: Float,
          r: Float, g: Float, b: Float, e: Float, u: Float, w: Float) {
        if (n + 12 > d.size) d = d.copyOf(d.size * 2)
        d[n++] = px; d[n++] = py; d[n++] = pz; d[n++] = nx; d[n++] = ny; d[n++] = nz
        d[n++] = r; d[n++] = g; d[n++] = b; d[n++] = e; d[n++] = u; d[n++] = w
    }

    fun quad(a: FloatArray, b: FloatArray, c: FloatArray, dd: FloatArray, nx: Float, ny: Float, nz: Float,
             col: FloatArray, u0: Float = -1f, v0: Float = -1f, u1: Float = -1f, v1: Float = -1f) {
        val r = col[0]; val g = col[1]; val bl = col[2]; val e = col[3]
        v(a[0], a[1], a[2], nx, ny, nz, r, g, bl, e, u0, v0)
        v(b[0], b[1], b[2], nx, ny, nz, r, g, bl, e, u1, v0)
        v(c[0], c[1], c[2], nx, ny, nz, r, g, bl, e, u1, v1)
        v(a[0], a[1], a[2], nx, ny, nz, r, g, bl, e, u0, v0)
        v(c[0], c[1], c[2], nx, ny, nz, r, g, bl, e, u1, v1)
        v(dd[0], dd[1], dd[2], nx, ny, nz, r, g, bl, e, u0, v1)
    }

    /** Quad whose normal is computed and flipped to point away from (hx,hy,hz). */
    fun quadAuto(a: FloatArray, b: FloatArray, c: FloatArray, dd: FloatArray, hx: Float, hy: Float, hz: Float, col: FloatArray) {
        val ux = b[0] - a[0]; val uy = b[1] - a[1]; val uz = b[2] - a[2]
        val wx = dd[0] - a[0]; val wy = dd[1] - a[1]; val wz = dd[2] - a[2]
        var nx = uy * wz - uz * wy; var ny = uz * wx - ux * wz; var nz = ux * wy - uy * wx
        val l = sqrt(nx * nx + ny * ny + nz * nz)
        if (l < 1e-6f) return
        nx /= l; ny /= l; nz /= l
        val cx = (a[0] + b[0] + c[0] + dd[0]) / 4f - hx
        val cy = (a[1] + b[1] + c[1] + dd[1]) / 4f - hy
        val cz = (a[2] + b[2] + c[2] + dd[2]) / 4f - hz
        if (nx * cx + ny * cy + nz * cz < 0f) { nx = -nx; ny = -ny; nz = -nz }
        quad(a, b, c, dd, nx, ny, nz, col)
    }

    private fun p(x: Float, y: Float, z: Float) = floatArrayOf(x, y, z)

    /** Axis-aligned box. If texU>0 the 4 side faces get window-texture UVs. */
    fun box(cx: Float, cy: Float, cz: Float, hx: Float, hy: Float, hz: Float, col: FloatArray,
            texU: Float = 0f, texV: Float = 0f, uo: Float = 0f, vo: Float = 0f, bottom: Boolean = false) {
        val x0 = cx - hx; val x1 = cx + hx; val y0 = cy - hy; val y1 = cy + hy; val z0 = cz - hz; val z1 = cz + hz
        val t = texU > 0f
        val uz = if (t) uo + 2f * hz * texU else -1f
        val ux = if (t) uo + 2f * hx * texU else -1f
        val u0 = if (t) uo else -1f
        val v0 = if (t) vo else -1f
        val v1 = if (t) vo + 2f * hy * texV else -1f
        quad(p(x1, y0, z0), p(x1, y0, z1), p(x1, y1, z1), p(x1, y1, z0), 1f, 0f, 0f, col, u0, v0, uz, v1)
        quad(p(x0, y0, z1), p(x0, y0, z0), p(x0, y1, z0), p(x0, y1, z1), -1f, 0f, 0f, col, u0, v0, uz, v1)
        quad(p(x1, y0, z1), p(x0, y0, z1), p(x0, y1, z1), p(x1, y1, z1), 0f, 0f, 1f, col, u0, v0, ux, v1)
        quad(p(x0, y0, z0), p(x1, y0, z0), p(x1, y1, z0), p(x0, y1, z0), 0f, 0f, -1f, col, u0, v0, ux, v1)
        quad(p(x0, y1, z0), p(x1, y1, z0), p(x1, y1, z1), p(x0, y1, z1), 0f, 1f, 0f, col)
        if (bottom) quad(p(x0, y0, z1), p(x1, y0, z1), p(x1, y0, z0), p(x0, y0, z0), 0f, -1f, 0f, col)
    }

    /** Horizontal quad on the ground plane. */
    fun flat(x0: Float, z0: Float, x1: Float, z1: Float, x2: Float, z2: Float, x3: Float, z3: Float, y: Float, col: FloatArray) {
        quad(p(x0, y, z0), p(x1, y, z1), p(x2, y, z2), p(x3, y, z3), 0f, 1f, 0f, col)
    }

    /** Loft through cross sections [z, halfWidth, yBottom, yTop]. */
    fun loft(s: Array<FloatArray>, col: FloatArray) {
        for (i in 0 until s.size - 1) {
            val a = s[i]; val b = s[i + 1]
            val hy = (a[2] + a[3] + b[2] + b[3]) / 4f; val hz = (a[0] + b[0]) / 2f
            quadAuto(p(-a[1], a[3], a[0]), p(a[1], a[3], a[0]), p(b[1], b[3], b[0]), p(-b[1], b[3], b[0]), 0f, hy, hz, col)
            quadAuto(p(a[1], a[2], a[0]), p(b[1], b[2], b[0]), p(b[1], b[3], b[0]), p(a[1], a[3], a[0]), 0f, hy, hz, col)
            quadAuto(p(-a[1], a[2], a[0]), p(-b[1], b[2], b[0]), p(-b[1], b[3], b[0]), p(-a[1], a[3], a[0]), 0f, hy, hz, col)
        }
        val f = s[0]; val l = s[s.size - 1]
        quad(p(-f[1], f[2], f[0]), p(f[1], f[2], f[0]), p(f[1], f[3], f[0]), p(-f[1], f[3], f[0]), 0f, 0f, -1f, col)
        quad(p(-l[1], l[2], l[0]), p(l[1], l[2], l[0]), p(l[1], l[3], l[0]), p(-l[1], l[3], l[0]), 0f, 0f, 1f, col)
    }

    /** Cylinder whose axis is the X axis. */
    fun cylX(cx: Float, cy: Float, cz: Float, rad: Float, hw: Float, seg: Int, col: FloatArray, caps: Boolean = true) {
        val r = col[0]; val g = col[1]; val b = col[2]; val e = col[3]
        for (i in 0 until seg) {
            val a0 = (2.0 * PI * i / seg).toFloat(); val a1 = (2.0 * PI * (i + 1) / seg).toFloat()
            val y0 = cos(a0); val z0 = sin(a0); val y1 = cos(a1); val z1 = sin(a1)
            val ax = cx - hw; val bx = cx + hw
            v(ax, cy + y0 * rad, cz + z0 * rad, 0f, y0, z0, r, g, b, e, -1f, -1f)
            v(bx, cy + y0 * rad, cz + z0 * rad, 0f, y0, z0, r, g, b, e, -1f, -1f)
            v(bx, cy + y1 * rad, cz + z1 * rad, 0f, y1, z1, r, g, b, e, -1f, -1f)
            v(ax, cy + y0 * rad, cz + z0 * rad, 0f, y0, z0, r, g, b, e, -1f, -1f)
            v(bx, cy + y1 * rad, cz + z1 * rad, 0f, y1, z1, r, g, b, e, -1f, -1f)
            v(ax, cy + y1 * rad, cz + z1 * rad, 0f, y1, z1, r, g, b, e, -1f, -1f)
            if (caps) for (sgn in floatArrayOf(-1f, 1f)) {
                val x = cx + sgn * hw
                v(x, cy, cz, sgn, 0f, 0f, r, g, b, e, -1f, -1f)
                v(x, cy + y0 * rad, cz + z0 * rad, sgn, 0f, 0f, r, g, b, e, -1f, -1f)
                v(x, cy + y1 * rad, cz + z1 * rad, sgn, 0f, 0f, r, g, b, e, -1f, -1f)
            }
        }
    }
}

class CarMeshes(val paint: MB, val trim: MB, val head: MB, val tail: MB, val wheel: MB)

fun col(r: Float, g: Float, b: Float, e: Float = 0f) = floatArrayOf(r, g, b, e)

fun buildCar(style: Int): CarMeshes {
    val paint = MB(); val trim = MB(); val head = MB(); val tail = MB(); val wheel = MB()
    val white = col(1f, 1f, 1f)
    val glass = col(0.03f, 0.05f, 0.08f)
    val dark = col(0.02f, 0.02f, 0.025f)
    val body: Array<FloatArray>; val cabin: Array<FloatArray>; val roof: Array<FloatArray>
    val zf: Float; val zr: Float
    when (style) {
        1 -> {
            body = arrayOf(floatArrayOf(-2.30f, .84f, .34f, .95f), floatArrayOf(-1.80f, .95f, .32f, 1.05f), floatArrayOf(-0.50f, .96f, .32f, 1.05f),
                floatArrayOf(0.50f, .96f, .32f, 1.04f), floatArrayOf(1.50f, .95f, .32f, 1.00f), floatArrayOf(2.15f, .90f, .34f, .80f), floatArrayOf(2.40f, .82f, .38f, .62f))
            cabin = arrayOf(floatArrayOf(-1.00f, .76f, 1.02f, 1.10f), floatArrayOf(-0.55f, .78f, 1.02f, 1.50f), floatArrayOf(0.20f, .78f, 1.02f, 1.50f), floatArrayOf(0.60f, .76f, 1.02f, 1.12f))
            roof = arrayOf(floatArrayOf(-0.5f, .66f, 1.46f, 1.52f), floatArrayOf(0.15f, .66f, 1.46f, 1.52f))
            zf = 2.4f; zr = -2.3f
        }
        2 -> {
            body = arrayOf(floatArrayOf(-1.95f, .82f, .32f, .98f), floatArrayOf(-1.60f, .90f, .30f, 1.08f), floatArrayOf(-0.60f, .92f, .30f, 1.06f),
                floatArrayOf(0.50f, .92f, .30f, .98f), floatArrayOf(1.30f, .90f, .30f, .80f), floatArrayOf(1.85f, .84f, .32f, .60f), floatArrayOf(2.05f, .78f, .36f, .52f))
            cabin = arrayOf(floatArrayOf(-1.55f, .70f, 1.02f, 1.12f), floatArrayOf(-1.00f, .74f, 1.02f, 1.50f), floatArrayOf(0.05f, .74f, 1.02f, 1.50f), floatArrayOf(0.75f, .72f, 1.02f, 1.15f))
            roof = arrayOf(floatArrayOf(-0.95f, .64f, 1.46f, 1.52f), floatArrayOf(0.0f, .64f, 1.46f, 1.52f))
            zf = 2.05f; zr = -1.95f
        }
        else -> {
            body = arrayOf(floatArrayOf(-2.15f, .80f, .32f, .86f), floatArrayOf(-1.75f, .91f, .30f, 1.00f), floatArrayOf(-0.90f, .93f, .30f, 1.02f),
                floatArrayOf(0.30f, .93f, .30f, .98f), floatArrayOf(1.25f, .92f, .30f, .86f), floatArrayOf(1.95f, .86f, .32f, .62f), floatArrayOf(2.20f, .78f, .36f, .52f))
            cabin = arrayOf(floatArrayOf(-1.30f, .70f, .98f, 1.02f), floatArrayOf(-0.55f, .74f, .98f, 1.42f), floatArrayOf(0.35f, .74f, .98f, 1.42f), floatArrayOf(0.95f, .72f, .98f, 1.10f))
            roof = arrayOf(floatArrayOf(-0.60f, .62f, 1.40f, 1.45f), floatArrayOf(0.30f, .62f, 1.40f, 1.45f))
            zf = 2.2f; zr = -2.15f
        }
    }
    paint.loft(body, white)
    paint.loft(roof, white)
    trim.loft(cabin, glass)
    trim.box(0f, 0.29f, (zf + zr) / 2f, 0.8f, 0.02f, (zf - zr) / 2f - 0.1f, dark)
    trim.box(0f, 0.30f, zf - 0.1f, 0.82f, 0.03f, 0.25f, dark)
    trim.box(0f, 0.32f, zr + 0.1f, 0.70f, 0.05f, 0.20f, dark)
    trim.box(0.94f, 0.34f, 0f, 0.03f, 0.08f, 1.0f, dark)
    trim.box(-0.94f, 0.34f, 0f, 0.03f, 0.08f, 1.0f, dark)
    trim.box(0f, 0.50f, zf - 0.03f, 0.50f, 0.07f, 0.03f, dark)
    trim.box(0.98f, 1.02f, 0.55f, 0.10f, 0.05f, 0.06f, dark)
    trim.box(-0.98f, 1.02f, 0.55f, 0.10f, 0.05f, 0.06f, dark)
    val metal = col(0.55f, 0.57f, 0.6f)
    trim.box(0.45f, 0.38f, zr - 0.02f, 0.07f, 0.07f, 0.04f, metal)
    trim.box(-0.45f, 0.38f, zr - 0.02f, 0.07f, 0.07f, 0.04f, metal)
    if (style == 1) {
        trim.box(0f, 1.05f, zr + 0.1f, 0.8f, 0.03f, 0.12f, dark)
        trim.box(0f, 1.07f, 1.2f, 0.28f, 0.03f, 0.5f, dark)
    } else {
        val wy = if (style == 2) 1.30f else 1.22f
        trim.box(0f, wy, zr + 0.2f, 0.88f, 0.025f, 0.22f, dark)
        trim.box(0.55f, wy - 0.13f, zr + 0.2f, 0.03f, 0.13f, 0.05f, dark)
        trim.box(-0.55f, wy - 0.13f, zr + 0.2f, 0.03f, 0.13f, 0.05f, dark)
    }
    val hy = if (style == 1) 0.60f else 0.55f
    head.box(0.62f, hy, zf - 0.08f, 0.20f, 0.05f, 0.05f, col(0.9f, 0.95f, 1f, 1f))
    head.box(-0.62f, hy, zf - 0.08f, 0.20f, 0.05f, 0.05f, col(0.9f, 0.95f, 1f, 1f))
    tail.box(0f, 0.82f, zr + 0.02f, 0.72f, 0.05f, 0.03f, col(1f, 0.05f, 0.05f, 1f))

    // wheel (axis = X), 0.34m radius
    wheel.cylX(0f, 0f, 0f, 0.34f, 0.13f, 14, col(0.025f, 0.025f, 0.03f))
    wheel.cylX(0f, 0f, 0f, 0.23f, 0.135f, 14, col(0.62f, 0.64f, 0.68f, 0.10f))
    for (k in 0 until 5) {
        val a = (2.0 * PI * k / 5).toFloat()
        for (sgn in floatArrayOf(-1f, 1f)) {
            val y = cos(a) * 0.12f; val z = sin(a) * 0.12f
            wheel.box(sgn * 0.138f, y, z, 0.01f, 0.025f + abs(sin(a)) * 0.035f, 0.025f + abs(cos(a)) * 0.035f, col(0.12f, 0.12f, 0.14f))
        }
    }
    return CarMeshes(paint, trim, head, tail, wheel)
}


/** Y-axis frustum (cone if r1 = 0). Normals radial + slope. */
fun MB.cylY(cx: Float, y0: Float, cz: Float, r0: Float, r1: Float, h: Float, seg: Int,
            cb: FloatArray, ct: FloatArray, rot: Float = 0f) {
    val ny = (r0 - r1) / h
    val l = sqrt(1f + ny * ny)
    for (i in 0 until seg) {
        val a0 = rot + (2.0 * PI * i / seg).toFloat(); val a1 = rot + (2.0 * PI * (i + 1) / seg).toFloat()
        val c0 = cos(a0); val s0 = sin(a0); val c1 = cos(a1); val s1 = sin(a1)
        v(cx + c0 * r0, y0, cz + s0 * r0, c0 / l, ny / l, s0 / l, cb[0], cb[1], cb[2], cb[3], -1f, -1f)
        v(cx + c1 * r0, y0, cz + s1 * r0, c1 / l, ny / l, s1 / l, cb[0], cb[1], cb[2], cb[3], -1f, -1f)
        v(cx + c1 * r1, y0 + h, cz + s1 * r1, c1 / l, ny / l, s1 / l, ct[0], ct[1], ct[2], ct[3], -1f, -1f)
        v(cx + c0 * r0, y0, cz + s0 * r0, c0 / l, ny / l, s0 / l, cb[0], cb[1], cb[2], cb[3], -1f, -1f)
        v(cx + c1 * r1, y0 + h, cz + s1 * r1, c1 / l, ny / l, s1 / l, ct[0], ct[1], ct[2], ct[3], -1f, -1f)
        v(cx + c0 * r1, y0 + h, cz + s0 * r1, c0 / l, ny / l, s0 / l, ct[0], ct[1], ct[2], ct[3], -1f, -1f)
    }
}

fun MB.disc(cx: Float, y: Float, cz: Float, r: Float, seg: Int, c: FloatArray) {
    for (i in 0 until seg) {
        val a0 = (2.0 * PI * i / seg).toFloat(); val a1 = (2.0 * PI * (i + 1) / seg).toFloat()
        v(cx, y, cz, 0f, 1f, 0f, c[0], c[1], c[2], c[3], -1f, -1f)
        v(cx + cos(a0) * r, y, cz + sin(a0) * r, 0f, 1f, 0f, c[0], c[1], c[2], c[3], -1f, -1f)
        v(cx + cos(a1) * r, y, cz + sin(a1) * r, 0f, 1f, 0f, c[0], c[1], c[2], c[3], -1f, -1f)
    }
}

/** Ground quad with per-corner colours. flag: -2 = grass shading, -1 = plain. */
fun MB.gq(x0: Float, z0: Float, x1: Float, z1: Float, y: Float,
          c00: FloatArray, c10: FloatArray, c11: FloatArray, c01: FloatArray, flag: Float) {
    fun vv(x: Float, z: Float, c: FloatArray) = v(x, y, z, 0f, 1f, 0f, c[0], c[1], c[2], 0f, flag, flag)
    vv(x0, z0, c00); vv(x1, z0, c10); vv(x1, z1, c11)
    vv(x0, z0, c00); vv(x1, z1, c11); vv(x0, z1, c01)
}

/** Prop meshes: 0 pine, 1 oak, 2 grass tuft, 3 rock. */
fun buildProps(): Array<MB> {
    val pine = MB(); val oak = MB(); val tuft = MB(); val rock = MB()
    val brown = col(0.28f, 0.18f, 0.10f); val brown2 = col(0.20f, 0.13f, 0.07f)
    pine.cylY(0f, 0f, 0f, 0.30f, 0.22f, 2.6f, 6, brown, brown2)
    pine.cylY(0f, 1.7f, 0f, 2.5f, 0f, 3.4f, 7, col(0.05f, 0.20f, 0.08f), col(0.11f, 0.34f, 0.13f))
    pine.cylY(0f, 3.3f, 0f, 2.0f, 0f, 3.2f, 7, col(0.06f, 0.23f, 0.09f), col(0.13f, 0.38f, 0.15f))
    pine.cylY(0f, 4.8f, 0f, 1.4f, 0f, 3.0f, 7, col(0.07f, 0.26f, 0.10f), col(0.15f, 0.42f, 0.17f))
    pine.disc(0f, 0.03f, 0f, 3.0f, 10, col(0.08f, 0.16f, 0.06f))
    oak.cylY(0f, 0f, 0f, 0.40f, 0.30f, 3.2f, 6, brown, brown2)
    oak.cylY(0f, 2.4f, 0f, 1.2f, 3.0f, 1.2f, 8, col(0.08f, 0.26f, 0.07f), col(0.14f, 0.38f, 0.09f))
    oak.cylY(0f, 3.6f, 0f, 3.0f, 2.2f, 1.6f, 8, col(0.14f, 0.38f, 0.09f), col(0.22f, 0.50f, 0.12f))
    oak.cylY(0f, 5.2f, 0f, 2.2f, 0f, 2.0f, 8, col(0.22f, 0.50f, 0.12f), col(0.30f, 0.60f, 0.15f))
    oak.disc(0f, 0.03f, 0f, 3.4f, 10, col(0.09f, 0.17f, 0.06f))
    val gb = col(0.10f, 0.28f, 0.07f); val gt = col(0.38f, 0.64f, 0.16f)
    for (k in 0 until 6) {
        val a = (PI * k / 3.0).toFloat(); val ox = cos(a * 1.7f) * 0.18f; val oz = sin(a * 1.7f) * 0.18f
        val dx = cos(a) * 0.14f; val dz = sin(a) * 0.14f
        val ht = 0.55f + 0.25f * ((k * 37) % 5) / 4f
        tuft.v(ox - dx, 0f, oz - dz, 0f, 1f, 0f, gb[0], gb[1], gb[2], 0f, -1f, -1f)
        tuft.v(ox + dx, 0f, oz + dz, 0f, 1f, 0f, gb[0], gb[1], gb[2], 0f, -1f, -1f)
        tuft.v(ox + dx * 0.2f + cos(a + 1.5f) * 0.1f, ht, oz + dz * 0.2f, 0f, 1f, 0f, gt[0], gt[1], gt[2], 0f, -1f, -1f)
    }
    rock.cylY(0f, 0f, 0f, 1.0f, 0.78f, 0.55f, 6, col(0.36f, 0.35f, 0.34f), col(0.50f, 0.49f, 0.47f), 0.3f)
    rock.cylY(0f, 0.55f, 0f, 0.78f, 0f, 0.5f, 6, col(0.50f, 0.49f, 0.47f), col(0.60f, 0.59f, 0.57f), 0.3f)
    return arrayOf(pine, oak, tuft, rock)
}
