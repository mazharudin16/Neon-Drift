package com.neondrift.game

import android.content.Context
import kotlin.math.*
import kotlin.random.Random

/** Admin access: sign in with this Google account, or use the PIN in the ADMIN tab. CHANGE BOTH. */
const val ADMIN_EMAIL = "CHANGE_ME@gmail.com"
const val ADMIN_PIN = "2580"

class CarSpec(val name: String, val price: Int, val level: Int, val mass: Float, val torque: Float,
              val muF: Float, val muR: Float, val style: Int, val desc: String)

val CARS = listOf(
    // Tier 1 - Beginner
    CarSpec("HACHI RS",     0,       1,  1250f, 410f, 1.15f, 1.08f, 0, "Balanced RWD · great for beginners"),
    CarSpec("TUNER Z",      5000,    2,  1150f, 430f, 1.18f, 1.10f, 2, "Light & nimble · easy to drift"),
    CarSpec("STREET S",     8000,    3,  1280f, 450f, 1.14f, 1.07f, 1, "Street muscle · smooth slides"),
    // Tier 2 - Amateur
    CarSpec("WOLF GT",      15000,   5,  1380f, 490f, 1.12f, 1.06f, 0, "GT coupe · smooth long slides"),
    CarSpec("BLAZE RX",     22000,   6,  1200f, 470f, 1.20f, 1.13f, 2, "Rotary power · wild oversteer"),
    CarSpec("VENOM S",      28000,   7,  1320f, 510f, 1.16f, 1.09f, 0, "Aggressive stance · wide slides"),
    // Tier 3 - Pro
    CarSpec("MUSTANG V8",   35000,   9,  1560f, 580f, 1.07f, 1.02f, 1, "Raw V8 · massive tail slides"),
    CarSpec("PHANTOM R",    45000,   10, 1420f, 545f, 1.18f, 1.12f, 2, "Sport coupe · balanced & fast"),
    CarSpec("ECLIPSE GT",   55000,   11, 1290f, 520f, 1.21f, 1.15f, 0, "JDM sport · precision control"),
    CarSpec("VIPER SRT",    68000,   12, 1480f, 620f, 1.09f, 1.05f, 1, "American legend · extreme power"),
    // Tier 4 - Expert
    CarSpec("SKYLINE R34",  85000,   14, 1320f, 535f, 1.22f, 1.17f, 0, "JDM icon · perfect drift angle"),
    CarSpec("SUPRA MK4",    100000,  15, 1350f, 560f, 1.20f, 1.15f, 2, "2JZ beast · fast & controllable"),
    CarSpec("COBRA KING",   115000,  16, 1500f, 600f, 1.10f, 1.06f, 1, "Classic muscle · brutal power"),
    CarSpec("NSX TYPE R",   130000,  17, 1260f, 540f, 1.24f, 1.18f, 2, "Honda legend · surgical precision"),
    // Tier 5 - Master
    CarSpec("GTR R35",      150000,  19, 1380f, 620f, 1.19f, 1.14f, 0, "Godzilla · all-round destroyer"),
    CarSpec("LAMBO V12",    180000,  20, 1480f, 680f, 1.13f, 1.09f, 1, "Italian exotic · top speed king"),
    CarSpec("FERRARI 488",  210000,  21, 1450f, 660f, 1.15f, 1.11f, 2, "Prancing horse · screaming V8"),
    CarSpec("McLAREN 720",  240000,  22, 1350f, 700f, 1.17f, 1.13f, 2, "British beast · insane grip"),
    // Tier 6 - Legend
    CarSpec("BUGATTI VR",   350000,  24, 1600f, 800f, 1.10f, 1.07f, 1, "Quad turbo W16 · 400+ km/h"),
    CarSpec("DRIFT KING",   500000,  25, 1180f, 750f, 1.28f, 1.22f, 0, "Ultimate drift machine · max angle"),
    // Secret
    CarSpec("GHOST X",      999999,  25, 1100f, 900f, 1.30f, 1.25f, 2, "SECRET · Admin unlock only")
)
val PAINTS = listOf(
    floatArrayOf(0.85f, 0.07f, 0.10f), floatArrayOf(0.08f, 0.30f, 0.95f), floatArrayOf(0.55f, 0.15f, 0.95f),
    floatArrayOf(0.30f, 0.90f, 0.15f), floatArrayOf(1.00f, 0.42f, 0.04f), floatArrayOf(0.90f, 0.92f, 0.96f),
    floatArrayOf(0.05f, 0.05f, 0.06f), floatArrayOf(1.00f, 0.20f, 0.60f)
)
val UPG_NAMES = arrayOf("ENGINE", "TIRES", "TURBO")
val UPG_COST = intArrayOf(2000, 1500, 1800)

class Challenge(val desc: String, val target: Int, val kind: Int, val reward: Int)
val CHALLENGES = listOf(
    Challenge("Drift 5,000 points in total", 5000, 0, 1500),
    Challenge("Reach 160 km/h", 160, 1, 800),
    Challenge("Score 2,000 in one drift", 2000, 2, 1500),
    Challenge("Drive 5 km", 5000, 3, 1000),
    Challenge("Use nitro for 20 seconds", 20, 4, 800),
    Challenge("Drive 2 km off-road", 2000, 5, 1500),
    Challenge("Reach a x4 drift combo", 4, 6, 1200),
    Challenge("Drift 20,000 points in total", 20000, 0, 4000),
    Challenge("Reach 220 km/h", 220, 1, 2500),
    Challenge("Score 8,000 in one drift", 8000, 2, 4000)
)

class Store(c: Context) {
    private val p = c.getSharedPreferences("neondrift", Context.MODE_PRIVATE)
    fun i(k: String, d: Int) = p.getInt(k, d)
    fun s(k: String, v: Int) { p.edit().putInt(k, v).apply() }
    fun l(k: String, d: Long) = p.getLong(k, d)
    fun sl(k: String, v: Long) { p.edit().putLong(k, v).apply() }
    fun str(k: String, d: String) = p.getString(k, d) ?: d
    fun sstr(k: String, v: String) { p.edit().putString(k, v).apply() }
}

/** Particles (smoke / flames / dust) + skid mark ring buffer. kind: 0 smoke 1 flame 2 dust 3 grass dust */
class Fx {
    val cap = 360
    val p = FloatArray(cap * 10)
    var cnt = 0
    private var rr = 0
    fun emit(x: Float, y: Float, z: Float, vx: Float, vy: Float, vz: Float, life: Float, size: Float, kind: Float) {
        val i = if (cnt < cap) cnt++ else (rr++ % cap)
        val o = i * 10
        p[o] = x; p[o + 1] = y; p[o + 2] = z; p[o + 3] = vx; p[o + 4] = vy; p[o + 5] = vz
        p[o + 6] = 0f; p[o + 7] = life; p[o + 8] = size; p[o + 9] = kind
    }
    fun update(dt: Float) {
        var i = 0
        while (i < cnt) {
            val o = i * 10
            p[o + 6] += dt
            if (p[o + 6] > p[o + 7]) {
                val l = (cnt - 1) * 10
                for (k in 0 until 10) p[o + k] = p[l + k]
                cnt--
                continue
            }
            p[o] += p[o + 3] * dt; p[o + 1] += p[o + 4] * dt; p[o + 2] += p[o + 5] * dt
            if (p[o + 9] != 1f) { val d = 1f - 1.8f * dt; p[o + 3] *= d; p[o + 5] *= d; p[o + 4] += 0.5f * dt }
            i++
        }
    }

    val skMax = 1500
    val sk = FloatArray(skMax * 54)
    var skHead = 0
    var skCount = 0
    val prevX = FloatArray(4); val prevZ = FloatArray(4); val prevOk = BooleanArray(4)
    fun skid(w: Int, x: Float, z: Float, alpha: Float, cr: Float, cg: Float, cb: Float) {
        if (prevOk[w]) {
            val dx = x - prevX[w]; val dz = z - prevZ[w]
            val l = sqrt(dx * dx + dz * dz)
            if (l < 0.35f) return
            val px = -dz / l * 0.14f; val pz = dx / l * 0.14f
            val o = skHead * 54
            fun v(i: Int, vx: Float, vz: Float) {
                val q = o + i * 9
                sk[q] = vx; sk[q + 1] = 0.09f; sk[q + 2] = vz; sk[q + 3] = 10f; sk[q + 4] = 10f
                sk[q + 5] = cr; sk[q + 6] = cg; sk[q + 7] = cb; sk[q + 8] = alpha
            }
            val ax = prevX[w] + px; val az = prevZ[w] + pz; val bx = prevX[w] - px; val bz = prevZ[w] - pz
            val cx = x - px; val cz = z - pz; val dxx = x + px; val dzz = z + pz
            v(0, ax, az); v(1, bx, bz); v(2, cx, cz); v(3, ax, az); v(4, cx, cz); v(5, dxx, dzz)
            skHead = (skHead + 1) % skMax
            if (skCount < skMax) skCount++
        }
        prevX[w] = x; prevZ[w] = z; prevOk[w] = true
    }
    fun skidEnd(w: Int) { prevOk[w] = false }
}

class Game(ctx: Context) {
    val store = Store(ctx)
    val car = CarPhysics()
    val fx = Fx()
    val net = Net(this)
    lateinit var world: World
    @Volatile var ready = false
    val vp = FloatArray(16)

    // ---- profile / progress
    var name = store.str("pname", "DRIVER" + (1000 + Random.nextInt(9000)))
    var avatar = store.i("avatar", 0)
    var email = store.str("gmail", "")
    var gname = store.str("gname", "")
    var pinAdmin = false
    var menuGiveCoinsIdx = 0
    var coins = store.i("coins", 5000)
    var carIdx = store.i("car", 0)
    var paintIdx = store.i("paint", 0)
    var owned = store.l("owned", 1L)
    private fun savOwned() = store.sl("owned", owned)
    var xp = store.i("xp", 0)
    var level = store.i("level", 1)
    var best = store.i("best", 0)
    var totalDrift = store.i("tdrift", 0)
    var topSpeed = store.i("topspd", 0)
    var distM = store.i("distm", 0)
    var races = store.i("races", 0)
    var playSecs = store.i("play", 0)
    var steerMode = store.i("steermode", 0)   // 0 wheel 1 buttons 2 tilt
    var tiltInv = store.i("tiltinv", 0) == 1
    var ctlSize = store.i("ctlsize", 0)       // 0 small 1 medium 2 large
    var volume = store.i("vol", 8)
    val isAdmin: Boolean get() = pinAdmin || (email.isNotEmpty() && email.equals(ADMIN_EMAIL, true))

    var menuTab = 0
    @Volatile var carVersion = 0
    @Volatile var state = 0
    var started = false
    var camMode = 0

    // ---- inputs
    @Volatile var touchSteer = 0f
    @Volatile var touchGasAmt = 0f
    @Volatile var touchBrkAmt = 0f
    @Volatile var touchHb = false
    @Volatile var touchNit = false
    @Volatile var keyL = false
    @Volatile var keyR = false
    @Volatile var keyGas = false
    @Volatile var keyBrk = false
    @Volatile var keyHb = false
    @Volatile var keyNit = false
    @Volatile var padSteer = 0f
    @Volatile var padGas = 0f
    @Volatile var padBrk = 0f
    @Volatile var tilt = 0f

    private var steerSm = 0f
    private var thrSm = 0f
    private var brkSm = 0f
    var steerShown = 0f

    // ---- gameplay
    var nitro = 1f
    var nitroActive = false
    var infiniteNitro = false
    var driftPts = 0f
    var driftT = 0f
    var graceT = 0f
    var mult = 1
    var totalScore = 0
    var toast = ""
    var toastT = 0f
    var shake = 0f
    var time = 0f
    var braking = false
    var driftAngleDeg = 0f
    var surf = 0
    var gripAdm = 1f
    private var saveT = 0f
    private var xpAcc = 0f

    // challenges
    val chId = IntArray(3) { store.i("cid$it", intArrayOf(0, 1, 3)[it]) }
    val chProg = FloatArray(3) { store.i("cp$it", 0).toFloat() }

    // race
    var raceOn = false
    val cps = FloatArray(16)
    var cpI = 0
    var raceT = 0f
    var raceLimit = 0f
    val cpN = 8

    // camera
    var camX = 0f; var camY = 3f; var camZ = -10f
    var lookX = 0f; var lookY = 1f; var lookZ = 0f
    var fov = 60f
    private var camAng = 0f
    private var menuAng = 0.6f

    init {
        applySpec()
        Thread {
            val w = World()
            world = w
            car.place(0f, -30f, 0f)
            ready = true
        }.also { it.priority = Thread.NORM_PRIORITY - 1 }.start()
    }

    fun spec() = CARS[carIdx]
    fun upg(k: Int) = store.i("u${carIdx}_$k", 0)
    fun need(l: Int) = 400 + 300 * (l - 1)
    fun speedKmh() = (car.u.coerceAtLeast(0f) * 3.6f).toInt()

    fun applySpec() {
        val s = spec()
        car.mass = s.mass
        car.torque = s.torque * (1f + 0.07f * upg(0))
        car.muF = s.muF * (1f + 0.035f * upg(1))
        car.muR = s.muR * (1f + 0.035f * upg(1))
        car.nitroPower = 0.35f + 0.08f * upg(2)
    }

    fun saveAll() {
        store.s("coins", coins); store.s("xp", xp); store.s("level", level); store.s("best", best)
        store.s("tdrift", totalDrift); store.s("topspd", topSpeed); store.s("distm", distM)
        store.s("races", races); store.s("play", playSecs)
        for (i in 0..2) { store.s("cid$i", chId[i]); store.s("cp$i", chProg[i].toInt()) }
    }

    fun toast(t: String) { toast = t; toastT = 2.4f }

    fun addXp(n: Int) {
        xp += n
        while (xp >= need(level)) {
            xp -= need(level); level++
            coins += level * 500
            toast("LEVEL UP!  LV $level   +$${level * 500}")
        }
    }

    private fun chProgress(kind: Int, v: Float, add: Boolean) {
        for (s in 0..2) {
            val ch = CHALLENGES[chId[s]]
            if (ch.kind != kind) continue
            chProg[s] = if (add) chProg[s] + v else max(chProg[s], v)
            if (chProg[s] >= ch.target) {
                coins += ch.reward; addXp(ch.reward / 4)
                toast("MISSION DONE!  +$${ch.reward}")
                var nid = (chId.max() + 1) % CHALLENGES.size
                while (chId.contains(nid)) nid = (nid + 1) % CHALLENGES.size
                chId[s] = nid; chProg[s] = 0f
                saveAll()
            }
        }
    }

    // ------------------------------------------------------------ menu
    fun menuAction(id: Int) {
        when {
            id == 1 || id == 2 -> {
                carIdx = (carIdx + (if (id == 1) CARS.size - 1 else 1)) % CARS.size
                store.s("car", carIdx); applySpec(); carVersion++
            }
            id in 10..17 -> { paintIdx = id - 10; store.s("paint", paintIdx); carVersion++ }
            id in 20..22 -> {
                val k = id - 20; val lv = upg(k); val cost = (lv + 1) * UPG_COST[k]
                if (lv < 5 && coins >= cost) { coins -= cost; store.s("u${carIdx}_$k", lv + 1); applySpec(); saveAll() }
                else if (lv < 5) toast("Not enough coins")
            }
            id == 30 -> {
                if (owned and (1L shl carIdx) != 0L) {
                    if (!started) { car.place(0f, -30f, 0f); started = true }
                    state = 1
                } else if (level < spec().level) toast("Reach level ${spec().level} to unlock")
                else if (coins >= spec().price) { coins -= spec().price; owned = owned or (1L shl carIdx); savOwned(); saveAll() }
                else toast("Not enough coins")
            }
            id == 32 -> { tiltInv = !tiltInv; store.s("tiltinv", if (tiltInv) 1 else 0) }
            id == 33 -> { steerMode = (steerMode + 1) % 3; store.s("steermode", steerMode) }
            id == 34 -> { ctlSize = (ctlSize + 1) % 3; store.s("ctlsize", ctlSize) }
            id == 35 -> { volume = max(0, volume - 1); store.s("vol", volume) }
            id == 36 -> { volume = min(10, volume + 1); store.s("vol", volume) }
            id == 37 -> { avatar = (avatar + 1) % 8; store.s("avatar", avatar) }
            id == 40 -> net.host()
            id == 42 -> net.stop()
            id in 50..55 -> menuTab = id - 50
            id == 60 -> startRace()
            id in 200..209 -> net.kick(net.remotes.keys.toList().getOrNull(id - 200) ?: 0)
            id in 210..219 -> {
                val r = net.remotes.values.toList().getOrNull(id - 210)
                if (r != null) giveCoinsToPlayer(r.email.ifEmpty { r.name }, 5000)
            }
            id in 95..98 -> { menuGiveCoinsIdx = id - 95 }
            id in 70..95 -> adminAction(id)
        }
    }

    // player registry: email -> coins granted
    val playerRegistry = HashMap<String, Int>()

    fun registerPlayer(email: String, displayName: String, coins: Int) {
        playerRegistry[email] = coins
        store.sstr("preg_${email.replace('@','_')}", "$displayName|$coins")
    }

    fun giveCoinsToPlayer(email: String, amount: Int) {
        if (!isAdmin) return
        val key = "preg_${email.replace('@','_')}"
        val existing = store.str(key, "")
        if (existing.isNotEmpty()) {
            val parts = existing.split("|")
            val name = parts[0]
            val cur = parts.getOrNull(1)?.toIntOrNull() ?: 0
            store.sstr(key, "$name|${cur + amount}")
            toast("SENT +$$amount to $name")
        } else {
            toast("Player not found: $email")
        }
    }

    fun getPlayerList(): List<Triple<String,String,Int>> {
        val list = ArrayList<Triple<String,String,Int>>()
        // from connected remote players
        for (r in net.remotes.values) {
            list.add(Triple(r.name, r.email.ifEmpty { "?" }, 0))
        }
        return list
    }

    private fun adminAction(id: Int) {
        if (!isAdmin) return
        when (id) {
            70 -> coins += 10000
            71 -> coins += 100000
            72 -> { xp = 0; level++ }
            73 -> { owned = (1L shl CARS.size) - 1L; toast("All cars unlocked") }
            74 -> {
                coins = 5000; xp = 0; level = 1; owned = 1; best = 0; totalDrift = 0; topSpeed = 0; distM = 0; races = 0
                for (c in 0..2) for (k in 0..2) store.s("u${c}_$k", 0)
                applySpec(); toast("Progress reset")
            }
            75 -> car.powerMul = max(0.4f, car.powerMul - 0.1f)
            76 -> car.powerMul = min(3f, car.powerMul + 0.1f)
            77 -> gripAdm = max(0.4f, gripAdm - 0.1f)
            78 -> gripAdm = min(2f, gripAdm + 0.1f)
            79 -> car.assist = max(0f, car.assist - 0.2f)
            80 -> car.assist = min(2.5f, car.assist + 0.2f)
            81 -> car.ydamp = max(0f, car.ydamp - 0.4f)
            82 -> car.ydamp = min(6f, car.ydamp + 0.4f)
            83 -> infiniteNitro = !infiniteNitro
            84 -> tp(0f, -30f, 0f)
            85 -> { val p = world.ring.pts; tp(p[0], p[1], atan2(p[2] - p[0], p[3] - p[1])) }
            86 -> tp(700f, 75f, (PI / 2).toFloat())
            87 -> tp(75f, 1000f, atan2(-135f, 90f))
            88 -> tp(1000f, 75f, atan2(110f, -175f))
            89 -> tp(1150f, 680f, 0f)
            94 -> tp(350f, -1300f, 0f)
            90 -> nitro = 1f
            93 -> { car.powerMul = 1f; car.assist = 1.05f; car.ydamp = 2.2f; gripAdm = 1f; toast("Physics reset") }
        }
        saveAll()
    }

    private fun tp(x: Float, z: Float, psi: Float) {
        car.place(x, z, psi); camAng = psi; started = true; state = 1
    }

    fun onSignedIn(mail: String, display: String) {
        email = mail; gname = display; store.sstr("gmail", mail); store.sstr("gname", display)
        if (display.isNotEmpty() && name.startsWith("DRIVER")) { name = display.take(12).uppercase(); store.sstr("pname", name) }
        toast("Signed in: $mail")
    }
    fun onSignedOut() { email = ""; gname = ""; store.sstr("gmail", ""); store.sstr("gname", "") }
    fun updateName(n: String) { name = n.trim().take(12).ifEmpty { name }; store.sstr("pname", name) }

    fun cycleCam() { camMode = (camMode + 1) % 3 }
    fun toGarage() { bank(); saveAll(); state = 0 }

    fun resetCar() {
        val i = world.nearest(car.x, car.z)
        val p = world.ring.pts
        car.place(p[i*2], p[i*2+1], atan2(p[((i+1)%(p.size/2))*2]-p[i*2], p[((i+1)%(p.size/2))*2+1]-p[i*2+1]))
        driftPts = 0f; driftT = 0f
    }

    private fun startRace() {
        val p = world.raceTrack.pts
        val n = p.size / 2
        val step = n / cpN
        car.place(p[0], p[1], atan2(p[2] - p[0], p[3] - p[1]))
        camAng = car.psi
        for (k in 0 until cpN) {
            val idx = ((k + 1) * step) % n
            cps[k * 2] = p[idx * 2]; cps[k * 2 + 1] = p[idx * 2 + 1]
        }
        raceOn = true; cpI = 0; raceT = 0f; raceLimit = 180f
        started = true; state = 1
        toast("RACE START! Hit all $cpN checkpoints")
    }

    private fun bank() {
        if (driftPts > 20f) {
            val pts = driftPts.toInt()
            totalScore += pts; totalDrift += pts
            coins += pts / 8
            addXp(pts / 12)
            if (pts > best) best = pts
            chProgress(0, pts.toFloat(), true); chProgress(2, pts.toFloat(), false)
            toast("DRIFT +$pts   +$${pts / 8}")
        }
        driftPts = 0f; driftT = 0f; mult = 1
    }

    // ------------------------------------------------------------ update
    private fun axisSteer(): Float {
        var s = (if (keyL) 1f else 0f) - (if (keyR) 1f else 0f)
        s += touchSteer + padSteer
        if (steerMode == 2) s += tilt * (if (tiltInv) -1f else 1f)
        return s.coerceIn(-1f, 1f)
    }

    fun update(dt: Float) {
        time += dt
        if (toastT > 0f) toastT -= dt
        if (!ready) return
        if (state == 1) drive(dt)
        fx.update(dt)
        updateCamera(dt)
    }

    private fun drive(dt: Float) {
        val c = car
        val target = axisSteer()
        val rate = if (steerMode == 0 && abs(touchSteer) > 0.001f) 30f
        else if (target == 0f || target * steerSm < 0f) 14f else 7f / (1f + c.speed / 45f) + 2.5f
        steerSm += (target - steerSm) * min(1f, dt * rate)
        steerShown = steerSm
        val gasT = maxOf(touchGasAmt, if (keyGas) 1f else 0f, padGas)
        thrSm += (gasT - thrSm) * min(1f, dt * (if (keyGas && touchGasAmt < 0.01f) 8f else 22f))
        val brkT = maxOf(touchBrkAmt, if (keyBrk) 1f else 0f, padBrk)
        brkSm += (brkT - brkSm) * min(1f, dt * 22f)
        braking = brkSm > 0.1f
        val hb = touchHb || keyHb
        val wantNitro = touchNit || keyNit
        nitroActive = wantNitro && (nitro > 0.02f || infiniteNitro) && c.u > 3f
        if (nitroActive) {
            if (!infiniteNitro) nitro = max(0f, nitro - dt * (0.30f - 0.03f * upg(2)))
            chProgress(4, dt, true)
        } else nitro = min(1f, nitro + dt * (if (driftT > 0f) 0.10f else 0.025f))

        surf = world.surfaceAt(c.x, c.z)
        val gt = (if (surf == 0) 1.0f else if (surf == 1) 0.74f else 0.52f) * gripAdm
        c.gripMul += (gt - c.gripMul) * min(1f, dt * 6f)
        c.rollRes = if (surf == 0) 0f else if (surf == 1) 0.25f else 1.0f

        val n = ceil(dt / (1f / 240f)).toInt().coerceIn(1, 12)
        val h = dt / n
        for (i in 0 until n) c.step(h, steerSm, thrSm, brkSm, hb, nitroActive)

        val imp = world.collide(c)
        if (imp > 3f) {
            shake = max(shake, (imp / 14f).coerceAtMost(1f))
            if (driftPts > 0f) { driftPts = 0f; driftT = 0f; mult = 1; toast("CRASH! combo lost") }
        }

        val sn = sin(c.psi); val cs = cos(c.psi)
        val b = abs(c.beta)
        driftAngleDeg = Math.toDegrees(b.toDouble()).toFloat()
        if (c.speed > 9f && b > 0.2f && c.u > 3f) {
            driftT += dt; graceT = 0f
            mult = 1 + (driftT / 2.5f).toInt().coerceAtMost(4)
            driftPts += c.speed * 3.6f * b * 4f * mult * dt * 0.35f
            chProgress(6, mult.toFloat(), false)
        } else if (driftPts > 0f) {
            graceT += dt
            if (graceT > 1.1f) bank()
        }
        val kmh = speedKmh()
        if (kmh > topSpeed) topSpeed = kmh
        chProgress(1, kmh.toFloat(), false)
        val dm = c.speed * dt
        xpAcc += dm
        if (surf != 0) chProgress(5, dm, true)
        chProgress(3, dm, true)
        if (xpAcc >= 100f) { distM += xpAcc.toInt(); addXp(5); xpAcc = 0f }
        saveT += dt
        if (saveT > 6f) { saveT = 0f; playSecs += 6; saveAll() }

        spawnWheelFx(dt, sn, cs)
        if (raceOn) updateRace(dt)
    }

    private fun updateRace(dt: Float) {
        raceT += dt
        val tx = cps[cpI * 2]; val tz = cps[cpI * 2 + 1]
        if (hypot(car.x - tx, car.z - tz) < 22f) {
            cpI++
            if (cpI >= cpN) {
                raceOn = false
                val left = max(0f, raceLimit - raceT)
                val reward = 2000 + (left * 60f).toInt()
                coins += reward; races++; addXp(400)
                toast("RACE COMPLETE!  +$$reward")
                saveAll()
            } else toast("CHECKPOINT $cpI / $cpN")
        } else if (raceT > raceLimit) { raceOn = false; toast("TIME UP - race failed") }
    }

    private fun spawnWheelFx(dt: Float, sn: Float, cs: Float) {
        val c = car
        for (i in 0..3) {
            val xl = if (i % 2 == 0) 0.84f else -0.84f
            val zl = if (i < 2) -1.3f else 1.3f
            val wx = c.x + sn * zl + cs * xl; val wz = c.z + cs * zl - sn * xl
            val slip = if (i < 2) c.rearSlip else c.frontSlip * 0.6f
            if (slip > 0.3f && c.speed > 3f) {
                when (surf) {
                    0 -> fx.skid(i, wx, wz, (0.15f + slip * 0.35f).coerceAtMost(0.5f), 0.01f, 0.01f, 0.01f)
                    1 -> fx.skid(i, wx, wz, 0.25f, 0.25f, 0.17f, 0.10f)
                    else -> fx.skid(i, wx, wz, 0.22f, 0.12f, 0.20f, 0.07f)
                }
                if (i < 2 && Random.nextFloat() < dt * 70f * slip) {
                    fx.emit(wx, 0.3f, wz, (Random.nextFloat() - 0.5f) * 1.5f, 0.8f + Random.nextFloat(), (Random.nextFloat() - 0.5f) * 1.5f,
                        1.1f + Random.nextFloat() * 0.8f, 0.9f + c.speed * 0.02f, if (surf == 0) 0f else if (surf == 1) 2f else 3f)
                }
            } else fx.skidEnd(i)
        }
        if (nitroActive) for (s in 0..1) {
            val xl = if (s == 0) 0.45f else -0.45f
            val wx = c.x + sn * -2.25f + cs * xl; val wz = c.z + cs * -2.25f - sn * xl
            fx.emit(wx, 0.42f, wz, -sn * 8f, 0f, -cs * 8f, 0.16f, 0.5f, 1f)
        }
    }

    private fun updateCamera(dt: Float) {
        val c = car
        shake = max(0f, shake - dt * 2.2f)
        if (state == 0) {
            menuAng += dt * 0.35f
            val r = 7.4f
            camX = c.x + sin(menuAng) * r; camZ = c.z + cos(menuAng) * r; camY = 2.1f
            lookX = c.x; lookY = 0.75f; lookZ = c.z
            fov += (52f - fov) * min(1f, dt * 4f)
            return
        }
        val tgt = c.psi + (if (camMode == 2) 0.25f else 0.55f) * c.beta.coerceIn(-1f, 1f)
        var da = tgt - camAng
        while (da > PI) da -= (2 * PI).toFloat()
        while (da < -PI) da += (2 * PI).toFloat()
        camAng += da * min(1f, dt * 5f)
        val sp = c.speed
        val fx0 = sin(camAng); val fz0 = cos(camAng)
        when (camMode) {
            0 -> { val d = 6.8f + sp * 0.03f; camX = c.x - fx0 * d; camZ = c.z - fz0 * d; camY = 2.3f
                lookX = c.x + fx0 * 4f; lookZ = c.z + fz0 * 4f; lookY = 1.0f }
            1 -> { val d = 11f + sp * 0.05f; camX = c.x - fx0 * d; camZ = c.z - fz0 * d; camY = 4.6f
                lookX = c.x + fx0 * 6f; lookZ = c.z + fz0 * 6f; lookY = 0.8f }
            else -> { camX = c.x + sin(c.psi) * 0.5f; camZ = c.z + cos(c.psi) * 0.5f; camY = 1.18f
                lookX = camX + fx0 * 30f; lookZ = camZ + fz0 * 30f; lookY = 1.0f }
        }
        if (shake > 0f) {
            camX += (Random.nextFloat() - 0.5f) * shake * 0.8f
            camY += (Random.nextFloat() - 0.5f) * shake * 0.5f
            camZ += (Random.nextFloat() - 0.5f) * shake * 0.8f
        }
        val tf = 60f + sp * 0.22f + (if (nitroActive) 12f else 0f)
        fov += (tf - fov) * min(1f, dt * 3f)
    }
}
