package com.neondrift.game

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.*
import android.text.InputType
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import kotlin.math.*

class HudView(ctx: Context, private val g: Game) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
    private var W = 1f; private var H = 1f
    private val cyan = Color.rgb(0, 229, 255)
    private val mag = Color.rgb(255, 43, 214)
    private val gold = Color.rgb(255, 214, 70)
    private val panel = Color.argb(185, 10, 14, 34)

    // play-control geometry (recomputed each frame so size option applies instantly)
    private val zGas = RectF(); private val zBrk = RectF(); private val zL = RectF(); private val zR = RectF()
    private val zMenu = RectF(); private val zCam = RectF(); private val zReset = RectF()
    private var wcx = 0f; private var wcy = 0f; private var wr = 1f
    private var hbx = 0f; private var hby = 0f; private var ntx = 0f; private var nty = 0f; private var br = 1f
    private var wheelAng = 0f; private var wheelPid = -1; private var lastAng = 0f
    private val maxW = 4.2f
    private var lastT = 0L

    private class Btn(val r: RectF, val id: Int)
    private val btns = ArrayList<Btn>()
    private var roadA: Path? = null
    private var roadD: Path? = null

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { W = w.toFloat(); H = h.toFloat() }

    private fun lay() {
        val k = floatArrayOf(0.72f, 0.9f, 1.1f)[g.ctlSize.coerceIn(0, 2)]
        wr = 0.17f * H * k; br = 0.062f * H * k
        val pw = 0.14f * H * k; val ph = 0.34f * H * k
        zGas.set(W * 0.975f - pw, H * 0.96f - ph, W * 0.975f, H * 0.96f)
        zBrk.set(zGas.left - 0.02f * W - pw, H * 0.96f - ph * 0.8f, zGas.left - 0.02f * W, H * 0.96f)
        hbx = zBrk.left - 0.03f * W - br; hby = H * 0.95f - br
        ntx = hbx; nty = hby - br * 2.5f
        wcx = 0.03f * W + wr * 1.15f; wcy = H * 0.97f - wr * 1.1f
        val bs = 0.2f * H * k
        zL.set(0.03f * W, H * 0.96f - bs, 0.03f * W + bs, H * 0.96f)
        zR.set(zL.right + 0.015f * W, zL.top, zL.right + 0.015f * W + bs, zL.bottom)
        val tb = 0.075f * H
        zMenu.set(W * 0.985f - tb, H * 0.03f, W * 0.985f, H * 0.03f + tb)
        zCam.set(zMenu.left - 0.012f * W - tb, zMenu.top, zMenu.left - 0.012f * W, zMenu.bottom)
        zReset.set(zCam.left - 0.012f * W - tb, zMenu.top, zCam.left - 0.012f * W, zMenu.bottom)
    }

    // ------------------------------------------------------------------ dialogs
    private fun ask(title: String, hint: String, init: String, numeric: Boolean, ok: String, cb: (String) -> Unit) {
        val a = context as Activity
        a.runOnUiThread {
            val et = EditText(a)
            et.setText(init); et.hint = hint
            et.inputType = if (numeric) InputType.TYPE_CLASS_PHONE else InputType.TYPE_CLASS_TEXT
            AlertDialog.Builder(a).setTitle(title).setView(et)
                .setPositiveButton(ok) { _, _ -> cb(et.text.toString().trim()) }
                .setNegativeButton("Cancel", null).show()
        }
    }

    private fun menuTap(id: Int) {
        when (id) {
            41 -> ask("JOIN GAME", "Host IP e.g. 192.168.43.1", g.store.str("ip", "192.168."), true, "JOIN") { g.store.sstr("ip", it); g.net.join(it) }
            45 -> ask("PLAYER NAME", "Name", g.name, false, "SAVE") { g.setName(it) }
            46 -> ask("ADMIN PIN", "PIN", "", true, "UNLOCK") { if (it == ADMIN_PIN) { g.pinAdmin = true; g.toast("Admin unlocked") } else g.toast("Wrong PIN") }
            47 -> (context as MainActivity).googleSignIn()
            48 -> (context as MainActivity).googleSignOut()
            91 -> ask("MESSAGE TO PLAYERS", "Message", "", false, "SEND") { if (g.net.mode == 1) g.net.broadcast(it) else g.toast("Host a game first") }
            else -> g.menuAction(id)
        }
    }

    // ------------------------------------------------------------------ touch
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val act = e.actionMasked
        if (!g.ready) return true
        if (g.state == 0) {
            if (act == MotionEvent.ACTION_DOWN || act == MotionEvent.ACTION_POINTER_DOWN) {
                val i = e.actionIndex
                for (b in btns) if (b.r.contains(e.getX(i), e.getY(i))) { menuTap(b.id); break }
            }
            return true
        }
        lay()
        val up = act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL
        when (act) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex; val x = e.getX(i); val y = e.getY(i)
                if (zMenu.contains(x, y)) g.toGarage()
                if (zCam.contains(x, y)) g.cycleCam()
                if (zReset.contains(x, y)) g.resetCar()
                if (g.steerMode == 0 && wheelPid == -1 && hypot(x - wcx, y - wcy) < wr * 1.35f) {
                    wheelPid = e.getPointerId(i); lastAng = atan2(y - wcy, x - wcx)
                }
            }
            MotionEvent.ACTION_MOVE -> if (wheelPid != -1) {
                val idx = e.findPointerIndex(wheelPid)
                if (idx >= 0) {
                    val a = atan2(e.getY(idx) - wcy, e.getX(idx) - wcx)
                    var d = a - lastAng
                    while (d > PI) d -= (2 * PI).toFloat()
                    while (d < -PI) d += (2 * PI).toFloat()
                    wheelAng = (wheelAng + d).coerceIn(-maxW, maxW); lastAng = a
                }
            }
            MotionEvent.ACTION_POINTER_UP -> if (e.getPointerId(e.actionIndex) == wheelPid) wheelPid = -1
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> wheelPid = -1
        }
        var gas = 0f; var brk = 0f; var hb = false; var nit = false; var l = false; var r = false
        if (!up) for (i in 0 until e.pointerCount) {
            if (act == MotionEvent.ACTION_POINTER_UP && i == e.actionIndex) continue
            val x = e.getX(i); val y = e.getY(i)
            if (zGas.contains(x, y)) gas = max(gas, ((y - zGas.top) / zGas.height()).coerceIn(0f, 1f))
            if (zBrk.contains(x, y)) brk = max(brk, ((y - zBrk.top) / zBrk.height()).coerceIn(0f, 1f))
            if (hypot(x - hbx, y - hby) < br * 1.35f) hb = true
            if (hypot(x - ntx, y - nty) < br * 1.35f) nit = true
            if (g.steerMode == 1) { if (zL.contains(x, y)) l = true; if (zR.contains(x, y)) r = true }
        }
        g.touchGasAmt = if (gas < 0.06f) 0f else gas
        g.touchBrkAmt = if (brk < 0.06f) 0f else brk
        g.touchHb = hb; g.touchNit = nit
        if (g.steerMode == 1) g.touchSteer = (if (l) 1f else 0f) - (if (r) 1f else 0f)
        return true
    }

    // ------------------------------------------------------------------ draw
    override fun onDraw(c: Canvas) {
        btns.clear()
        val now = System.nanoTime()
        val dt = if (lastT == 0L) 0.016f else ((now - lastT) / 1e9f).coerceIn(0.001f, 0.05f)
        lastT = now
        if (!g.ready) { drawLoading(c) }
        else if (g.state == 0) { wheelAng = 0f; wheelPid = -1; g.touchSteer = 0f; drawMenu(c) }
        else {
            lay()
            if (wheelPid == -1 && wheelAng != 0f) {
                val step = dt * 7f
                wheelAng = if (abs(wheelAng) <= step) 0f else wheelAng - sign(wheelAng) * step
            }
            if (g.steerMode == 0) g.touchSteer = -(wheelAng / maxW)
            else if (g.steerMode == 2) g.touchSteer = 0f
            drawPlay(c)
        }
        if (g.toastT > 0f && g.ready) text(c, g.toast, W / 2f, H * 0.30f, H * 0.05f, Color.argb(min(255, (g.toastT * 400).toInt()), 255, 230, 80), Paint.Align.CENTER)
        postInvalidateOnAnimation()
    }

    private fun drawLoading(c: Canvas) {
        c.drawColor(Color.rgb(8, 12, 30))
        text(c, "NEON DRIFT", W / 2f, H * 0.42f, H * 0.12f, mag, Paint.Align.CENTER)
        text(c, "GENERATING OPEN WORLD" + ".".repeat(((g.time * 2).toInt() % 4) + 0), W / 2f, H * 0.56f, H * 0.045f, cyan, Paint.Align.CENTER)
        g.time += 0.016f
    }

    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, align: Paint.Align = Paint.Align.LEFT) {
        tp.textSize = size; tp.color = color; tp.textAlign = align
        c.drawText(s, x, y, tp)
    }

    private fun rbox(c: Canvas, r: RectF, fill: Int, stroke: Int = 0, sw: Float = 3f) {
        p.style = Paint.Style.FILL; p.color = fill
        c.drawRoundRect(r, H * 0.02f, H * 0.02f, p)
        if (stroke != 0) { p.style = Paint.Style.STROKE; p.strokeWidth = sw; p.color = stroke; c.drawRoundRect(r, H * 0.02f, H * 0.02f, p) }
    }

    private fun roundBtn(c: Canvas, cx: Float, cy: Float, r: Float, label: String, on: Boolean, col: Int) {
        p.style = Paint.Style.FILL; p.color = if (on) col else Color.argb(110, 10, 12, 30)
        c.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = col; c.drawCircle(cx, cy, r, p)
        text(c, label, cx, cy + r * 0.2f, r * 0.55f, if (on) Color.BLACK else Color.WHITE, Paint.Align.CENTER)
    }

    private fun pedal(c: Canvas, r: RectF, label: String, v: Float, col: Int) {
        rbox(c, r, Color.argb(110, 10, 12, 30), col, 4f)
        if (v > 0f) { p.style = Paint.Style.FILL; p.color = Color.argb(200, Color.red(col), Color.green(col), Color.blue(col))
            c.drawRoundRect(RectF(r.left, r.top, r.right, r.top + r.height() * v), H * 0.02f, H * 0.02f, p) }
        text(c, label, r.centerX(), r.top + H * 0.04f, H * 0.026f, Color.WHITE, Paint.Align.CENTER)
        text(c, "${(v * 100).toInt()}%", r.centerX(), r.bottom - H * 0.015f, H * 0.03f, Color.WHITE, Paint.Align.CENTER)
    }

    private fun drawWheel(c: Canvas) {
        p.style = Paint.Style.FILL; p.color = Color.argb(70, 10, 12, 30); c.drawCircle(wcx, wcy, wr * 1.05f, p)
        c.save(); c.rotate(Math.toDegrees(wheelAng.toDouble()).toFloat(), wcx, wcy)
        p.style = Paint.Style.STROKE; p.strokeWidth = wr * 0.17f; p.color = Color.argb(235, 40, 44, 60); c.drawCircle(wcx, wcy, wr * 0.88f, p)
        p.strokeWidth = wr * 0.05f; p.color = cyan; c.drawCircle(wcx, wcy, wr * 0.88f, p)
        p.strokeWidth = wr * 0.11f; p.color = Color.argb(235, 55, 60, 80)
        for (a in intArrayOf(180, 300, 60)) {
            val ra = Math.toRadians(a.toDouble()).toFloat()
            c.drawLine(wcx, wcy, wcx + cos(ra) * wr * 0.85f, wcy + sin(ra) * wr * 0.85f, p)
        }
        p.style = Paint.Style.FILL; p.color = Color.argb(240, 30, 34, 50); c.drawCircle(wcx, wcy, wr * 0.26f, p)
        p.color = mag; c.drawRoundRect(RectF(wcx - wr * 0.05f, wcy - wr * 0.98f, wcx + wr * 0.05f, wcy - wr * 0.78f), 6f, 6f, p)
        c.restore()
    }

    private fun buildMap() {
        val a = Path(); val d = Path()
        for (r in g.world.roads) {
            val path = if (r.kind == 1) d else a
            val n = r.pts.size / 2
            for (i in 0 until n) { val x = r.pts[i * 2]; val y = -r.pts[i * 2 + 1]; if (i == 0) path.moveTo(x, y) else path.lineTo(x, y) }
            if (r.closed) path.close()
        }
        roadA = a; roadD = d
    }

    private fun project(x: Float, y: Float, z: Float, out: FloatArray): Boolean {
        val m = g.vp
        val cw = m[3] * x + m[7] * y + m[11] * z + m[15]
        if (cw < 0.5f) return false
        val cx = m[0] * x + m[4] * y + m[8] * z + m[12]; val cy = m[1] * x + m[5] * y + m[9] * z + m[13]
        out[0] = (cx / cw * 0.5f + 0.5f) * W; out[1] = (1f - (cy / cw * 0.5f + 0.5f)) * H
        return true
    }

    private val pt = FloatArray(2)

    private fun drawPlay(c: Canvas) {
        val car = g.car
        if (roadA == null) buildMap()
        // rotating minimap
        val ms = 0.27f * H
        val mp = RectF(W * 0.015f, H * 0.03f, W * 0.015f + ms, H * 0.03f + ms)
        rbox(c, mp, panel, cyan, 2f)
        c.save(); c.clipRect(mp)
        c.translate(mp.centerX(), mp.centerY())
        c.rotate(-Math.toDegrees(car.psi.toDouble()).toFloat())
        val sc = ms / 650f
        c.scale(sc, sc); c.translate(-car.x, car.z)
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 11f / sc * 0.45f; p.color = Color.argb(230, 235, 235, 240); roadA?.let { c.drawPath(it, p) }
        p.color = Color.argb(230, 205, 160, 100); roadD?.let { c.drawPath(it, p) }
        p.style = Paint.Style.FILL
        for (r in g.net.remotes.values) { p.color = Color.rgb(80, 255, 120); c.drawCircle(r.x, -r.z, 14f / sc * 0.45f, p) }
        if (g.raceOn && g.cpI < g.cpN) { p.color = gold; c.drawCircle(g.cps[g.cpI * 2], -g.cps[g.cpI * 2 + 1], 18f / sc * 0.45f, p) }
        c.restore()
        p.style = Paint.Style.FILL; p.color = mag
        val tri = Path(); tri.moveTo(mp.centerX(), mp.centerY() - ms * 0.045f); tri.lineTo(mp.centerX() - ms * 0.03f, mp.centerY() + ms * 0.03f); tri.lineTo(mp.centerX() + ms * 0.03f, mp.centerY() + ms * 0.03f); tri.close()
        c.drawPath(tri, p)

        // name tags
        for (r in g.net.remotes.values) if (project(r.x, 2.8f, r.z, pt)) {
            val d = hypot(r.x - car.x, r.z - car.z).toInt()
            text(c, "${r.name}  ${d}m", pt[0], pt[1], H * 0.03f, Color.rgb(120, 255, 150), Paint.Align.CENTER)
        }

        // drift panel
        val cx = W / 2f
        if (g.driftPts > 0f) {
            val r = RectF(cx - W * 0.12f, H * 0.02f, cx + W * 0.12f, H * 0.15f)
            rbox(c, r, panel, mag)
            text(c, "DRIFT  ${g.driftAngleDeg.toInt()}°", cx, H * 0.055f, H * 0.03f, cyan, Paint.Align.CENTER)
            text(c, "${g.driftPts.toInt()}", cx - W * 0.02f, H * 0.12f, H * 0.06f, Color.WHITE, Paint.Align.CENTER)
            text(c, "x${g.mult}", cx + W * 0.075f, H * 0.12f, H * 0.05f, mag, Paint.Align.CENTER)
        } else text(c, "LV ${g.level}   \$${g.coins}", cx, H * 0.05f, H * 0.035f, Color.WHITE, Paint.Align.CENTER)

        if (g.raceOn) {
            val left = max(0f, g.raceLimit - g.raceT)
            text(c, "RACE  ${left.toInt() / 60}:${"%02d".format(left.toInt() % 60)}    CP ${g.cpI}/${g.cpN}", cx, H * 0.205f, H * 0.04f, gold, Paint.Align.CENTER)
            if (g.cpI < g.cpN) {
                val dx = g.cps[g.cpI * 2] - car.x; val dz = g.cps[g.cpI * 2 + 1] - car.z
                val rel = Math.toDegrees((atan2(dx, dz) - car.psi).toDouble()).toFloat()
                c.save(); c.translate(cx, H * 0.285f); c.rotate(-rel)
                p.style = Paint.Style.FILL; p.color = gold
                val ar = Path(); ar.moveTo(0f, -H * 0.04f); ar.lineTo(-H * 0.03f, H * 0.025f); ar.lineTo(0f, H * 0.01f); ar.lineTo(H * 0.03f, H * 0.025f); ar.close()
                c.drawPath(ar, p); c.restore()
                text(c, "${hypot(dx, dz).toInt()} m", cx, H * 0.34f, H * 0.03f, Color.WHITE, Paint.Align.CENTER)
            }
        }

        // top-right buttons
        for ((r, lab) in listOf(zMenu to "II", zCam to "CAM", zReset to "RST")) {
            rbox(c, r, Color.argb(120, 10, 12, 30), cyan, 2f)
            text(c, lab, r.centerX(), r.centerY() + H * 0.012f, H * 0.026f, Color.WHITE, Paint.Align.CENTER)
        }

        // speedo (small)
        val sx = W * 0.50f; val sy = H * 0.89f; val rad = H * 0.085f
        val oval = RectF(sx - rad, sy - rad, sx + rad, sy + rad)
        p.style = Paint.Style.STROKE; p.strokeWidth = H * 0.016f; p.strokeCap = Paint.Cap.BUTT; p.color = Color.argb(110, 255, 255, 255)
        c.drawArc(oval, 150f, 240f, false, p)
        val rp = (car.rpm / 8000f).coerceIn(0f, 1f)
        p.color = if (rp > 0.88f) Color.rgb(255, 60, 60) else cyan
        c.drawArc(oval, 150f, 240f * rp, false, p)
        text(c, "${g.speedKmh()}", sx, sy + H * 0.015f, H * 0.065f, Color.WHITE, Paint.Align.CENTER)
        text(c, "KM/H", sx, sy + H * 0.052f, H * 0.022f, cyan, Paint.Align.CENTER)
        text(c, if (car.u < -0.5f) "R" else "${car.gear + 1}", sx, sy - H * 0.045f, H * 0.04f, mag, Paint.Align.CENTER)
        val nb = RectF(sx - W * 0.07f, H * 0.972f, sx + W * 0.07f, H * 0.988f)
        rbox(c, nb, Color.argb(120, 0, 0, 0), cyan, 2f)
        p.style = Paint.Style.FILL; p.color = if (g.nitroActive) Color.rgb(255, 160, 40) else mag
        c.drawRoundRect(RectF(nb.left, nb.top, nb.left + nb.width() * g.nitro, nb.bottom), 6f, 6f, p)

        // controls
        when (g.steerMode) {
            0 -> drawWheel(c)
            1 -> for ((r, lab, on) in listOf(Triple(zL, "<", g.touchSteer > 0.5f), Triple(zR, ">", g.touchSteer < -0.5f))) {
                rbox(c, r, if (on) cyan else Color.argb(110, 10, 12, 30), cyan, 3f)
                text(c, lab, r.centerX(), r.centerY() + H * 0.025f, H * 0.07f, if (on) Color.BLACK else Color.WHITE, Paint.Align.CENTER)
            }
            else -> text(c, "TILT TO STEER", W * 0.17f, H * 0.93f, H * 0.035f, cyan, Paint.Align.CENTER)
        }
        pedal(c, zGas, "GAS", g.touchGasAmt, Color.rgb(60, 255, 120))
        pedal(c, zBrk, "BRAKE", g.touchBrkAmt, Color.rgb(255, 70, 70))
        roundBtn(c, hbx, hby, br, "DRIFT", g.touchHb, mag)
        roundBtn(c, ntx, nty, br, "N2O", g.touchNit || g.nitroActive, Color.rgb(255, 160, 40))
    }

    // ------------------------------------------------------------------ menu
    private fun btn(c: Canvas, r: RectF, id: Int, label: String, sel: Boolean = false, col: Int = cyan, enabled: Boolean = true, size: Float = 0.032f) {
        rbox(c, r, if (sel) Color.argb(225, Color.red(col), Color.green(col), Color.blue(col)) else panel, if (enabled) col else Color.GRAY, 3f)
        text(c, label, r.centerX(), r.centerY() + H * size * 0.38f, H * size, if (sel) Color.BLACK else if (enabled) Color.WHITE else Color.GRAY, Paint.Align.CENTER)
        if (enabled || id == 30) btns.add(Btn(r, id))
    }

    private fun bar(c: Canvas, x: Float, y: Float, w: Float, label: String, v: Float) {
        text(c, label, x, y, H * 0.024f, Color.WHITE)
        p.style = Paint.Style.FILL; p.color = Color.argb(90, 255, 255, 255)
        c.drawRoundRect(RectF(x, y + H * 0.008f, x + w, y + H * 0.026f), 6f, 6f, p)
        p.color = cyan
        c.drawRoundRect(RectF(x, y + H * 0.008f, x + w * v.coerceIn(0f, 1f), y + H * 0.026f), 6f, 6f, p)
    }

    private fun rect(l: Float, t: Float, r: Float, b: Float) = RectF(l * W, t * H, r * W, b * H)

    private fun drawMenu(c: Canvas) {
        c.drawColor(Color.argb(120, 4, 6, 20))
        val tabs = arrayOf("GARAGE", "MISSIONS", "PROFILE", "ONLINE", "OPTIONS", "ADMIN")
        for (i in tabs.indices) btn(c, rect(0.02f + i * 0.108f, 0.025f, 0.02f + i * 0.108f + 0.1f, 0.105f), 50 + i, tabs[i], g.menuTab == i, if (i == 5) gold else cyan, true, 0.028f)
        text(c, "LV ${g.level}   \$${g.coins}", W * 0.975f, H * 0.075f, H * 0.04f, gold, Paint.Align.RIGHT)
        when (g.menuTab) {
            0 -> pageGarage(c); 1 -> pageMissions(c); 2 -> pageProfile(c); 3 -> pageOnline(c); 4 -> pageOptions(c); else -> pageAdmin(c)
        }
        val s = g.spec()
        val own = g.owned and (1 shl g.carIdx) != 0
        val can = own || (g.level >= s.level && g.coins >= s.price)
        val label = if (own) (if (g.started) "RESUME" else "DRIVE") else if (g.level < s.level) "LOCKED  LV ${s.level}" else "BUY  \$${s.price}"
        btn(c, rect(0.66f, 0.87f, 0.97f, 0.97f), 30, label, true, if (can) mag else Color.GRAY, true, 0.05f)
    }

    private fun pageGarage(c: Canvas) {
        val s = g.spec()
        val own = g.owned and (1 shl g.carIdx) != 0
        btn(c, rect(0.03f, 0.40f, 0.10f, 0.50f), 1, "<")
        btn(c, rect(0.39f, 0.40f, 0.46f, 0.50f), 2, ">")
        val info = rect(0.03f, 0.14f, 0.46f, 0.38f)
        rbox(c, info, panel, mag)
        text(c, s.name, info.left + W * 0.015f, info.top + H * 0.075f, H * 0.065f, Color.WHITE)
        text(c, s.desc + (if (own) "" else "   [LOCKED]"), info.left + W * 0.015f, info.top + H * 0.125f, H * 0.032f, cyan)
        bar(c, info.left + W * 0.015f, info.bottom - H * 0.055f, W * 0.12f, "POWER", (s.torque / 600f))
        bar(c, info.left + W * 0.16f, info.bottom - H * 0.055f, W * 0.12f, "GRIP", (s.muR - 0.8f) / 0.5f)
        bar(c, info.left + W * 0.30f, info.bottom - H * 0.055f, W * 0.11f, "AGILITY", 1f - (s.mass - 1000f) / 700f)
        text(c, "PAINT", W * 0.03f, H * 0.555f, H * 0.03f, Color.WHITE)
        for (i in PAINTS.indices) {
            val pc = PAINTS[i]
            val x = W * (0.03f + i * 0.0545f); val r = RectF(x, H * 0.575f, x + W * 0.047f, H * 0.575f + W * 0.047f)
            p.style = Paint.Style.FILL; p.color = Color.rgb((pc[0] * 255).toInt(), (pc[1] * 255).toInt(), (pc[2] * 255).toInt())
            c.drawRoundRect(r, 8f, 8f, p)
            if (i == g.paintIdx) { p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.color = Color.WHITE; c.drawRoundRect(r, 8f, 8f, p) }
            btns.add(Btn(r, 10 + i))
        }
        text(c, "UPGRADES  (${s.name})", W * 0.52f, H * 0.17f, H * 0.035f, cyan)
        for (k in 0..2) {
            val lv = g.upg(k)
            val y = 0.20f + k * 0.145f
            val r = rect(0.52f, y, 0.97f, y + 0.125f)
            rbox(c, r, panel, cyan, 2f)
            text(c, UPG_NAMES[k], r.left + W * 0.012f, r.centerY() + H * 0.014f, H * 0.036f, Color.WHITE)
            for (i in 0 until 5) {
                p.style = Paint.Style.FILL; p.color = if (i < lv) mag else Color.argb(90, 255, 255, 255)
                val px = r.left + W * (0.125f + i * 0.03f)
                c.drawRoundRect(RectF(px, r.centerY() - H * 0.02f, px + W * 0.022f, r.centerY() + H * 0.02f), 4f, 4f, p)
            }
            val cost = (lv + 1) * UPG_COST[k]
            val br2 = RectF(r.right - W * 0.125f, r.top + H * 0.018f, r.right - W * 0.01f, r.bottom - H * 0.018f)
            if (lv >= 5) btn(c, br2, -1, "MAX", false, Color.GRAY, false) else btn(c, br2, 20 + k, "\$$cost", false, gold, g.coins >= cost)
        }
    }

    private fun pageMissions(c: Canvas) {
        val need = g.need(g.level)
        text(c, "LEVEL ${g.level}", W * 0.03f, H * 0.19f, H * 0.05f, Color.WHITE)
        bar(c, W * 0.20f, H * 0.17f, W * 0.77f, "XP  ${g.xp} / $need", g.xp.toFloat() / need)
        for (s in 0..2) {
            val ch = CHALLENGES[g.chId[s]]
            val y = 0.25f + s * 0.15f
            val r = rect(0.03f, y, 0.97f, y + 0.13f)
            rbox(c, r, panel, cyan, 2f)
            text(c, ch.desc, r.left + W * 0.015f, r.top + H * 0.05f, H * 0.036f, Color.WHITE)
            text(c, "REWARD \$${ch.reward}", r.right - W * 0.015f, r.top + H * 0.05f, H * 0.032f, gold, Paint.Align.RIGHT)
            bar(c, r.left + W * 0.015f, r.top + H * 0.075f, W * 0.9f, "${g.chProg[s].toInt()} / ${ch.target}", g.chProg[s] / ch.target)
        }
        btn(c, rect(0.03f, 0.71f, 0.62f, 0.81f), 60, "START CHECKPOINT RACE", false, gold, true, 0.038f)
        text(c, "Race the ring road through 8 checkpoints against the clock.", W * 0.03f, H * 0.855f, H * 0.026f, Color.argb(200, 255, 255, 255))
    }

    private fun pageProfile(c: Canvas) {
        val ac = intArrayOf(Color.rgb(255, 80, 90), Color.rgb(70, 140, 255), Color.rgb(170, 90, 255), Color.rgb(90, 220, 90),
            Color.rgb(255, 150, 40), Color.rgb(230, 230, 240), Color.rgb(60, 60, 70), Color.rgb(255, 80, 170))
        val ar = H * 0.10f; val ax = W * 0.12f; val ay = H * 0.30f
        p.style = Paint.Style.FILL; p.color = ac[g.avatar % 8]; c.drawCircle(ax, ay, ar, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.color = Color.WHITE; c.drawCircle(ax, ay, ar, p)
        text(c, g.name.take(1).uppercase(), ax, ay + ar * 0.38f, ar * 1.1f, Color.WHITE, Paint.Align.CENTER)
        btns.add(Btn(RectF(ax - ar, ay - ar, ax + ar, ay + ar), 37))
        text(c, g.name, W * 0.24f, H * 0.26f, H * 0.06f, Color.WHITE)
        text(c, "LEVEL ${g.level}", W * 0.24f, H * 0.33f, H * 0.04f, cyan)
        btn(c, rect(0.03f, 0.44f, 0.20f, 0.52f), 45, "EDIT NAME", false, cyan, true, 0.028f)
        text(c, "tap avatar to change colour", W * 0.03f, H * 0.575f, H * 0.024f, Color.argb(180, 255, 255, 255))
        val signed = g.email.isNotEmpty()
        text(c, if (signed) "GOOGLE: ${g.email}" else "GUEST  (not signed in)", W * 0.03f, H * 0.65f, H * 0.03f, if (signed) Color.rgb(120, 255, 150) else Color.LTGRAY)
        if (signed) btn(c, rect(0.03f, 0.69f, 0.30f, 0.77f), 48, "SIGN OUT", false, Color.rgb(255, 90, 90), true, 0.028f)
        else btn(c, rect(0.03f, 0.69f, 0.30f, 0.77f), 47, "SIGN IN WITH GOOGLE", false, Color.rgb(120, 255, 150), true, 0.026f)
        val stats = listOf("BEST DRIFT" to "${g.best}", "TOTAL DRIFT" to "${g.totalDrift}", "TOP SPEED" to "${g.topSpeed} km/h",
            "DISTANCE" to "%.1f km".format(g.distM / 1000f), "RACES WON" to "${g.races}", "PLAY TIME" to "${g.playSecs / 60} min",
            "COINS" to "\$${g.coins}", "CARS OWNED" to "${Integer.bitCount(g.owned)} / ${CARS.size}")
        for ((i, st) in stats.withIndex()) {
            val col = i % 2; val row = i / 2
            val r = rect(0.52f + col * 0.235f, 0.16f + row * 0.15f, 0.745f + col * 0.235f, 0.285f + row * 0.15f)
            rbox(c, r, panel, cyan, 2f)
            text(c, st.first, r.left + W * 0.01f, r.top + H * 0.045f, H * 0.026f, cyan)
            text(c, st.second, r.left + W * 0.01f, r.top + H * 0.10f, H * 0.04f, Color.WHITE)
        }
    }

    private fun pageOnline(c: Canvas) {
        text(c, "LAN MULTIPLAYER", W * 0.03f, H * 0.19f, H * 0.05f, Color.WHITE)
        text(c, g.net.status, W * 0.03f, H * 0.255f, H * 0.036f, if (g.net.mode == 0) Color.LTGRAY else Color.rgb(120, 255, 150))
        btn(c, rect(0.03f, 0.29f, 0.20f, 0.38f), 40, "HOST", g.net.mode == 1, cyan, true, 0.034f)
        btn(c, rect(0.22f, 0.29f, 0.39f, 0.38f), 41, "JOIN", g.net.mode == 2, cyan, true, 0.034f)
        btn(c, rect(0.41f, 0.29f, 0.58f, 0.38f), 42, "LEAVE", false, Color.rgb(255, 90, 90), true, 0.034f)
        text(c, "Same Wi-Fi or hotspot: one friend taps HOST,", W * 0.03f, H * 0.46f, H * 0.026f, Color.argb(210, 255, 255, 255))
        text(c, "others tap JOIN and type the IP shown above.", W * 0.03f, H * 0.50f, H * 0.026f, Color.argb(210, 255, 255, 255))
        text(c, "Then press DRIVE - everyone appears in the same world.", W * 0.03f, H * 0.54f, H * 0.026f, Color.argb(210, 255, 255, 255))
        text(c, "PLAYERS", W * 0.62f, H * 0.19f, H * 0.04f, cyan)
        var y = 0.23f
        rbox(c, rect(0.62f, y, 0.97f, y + 0.07f), panel, mag)
        text(c, "${g.name}  (you)", W * 0.635f, (y + 0.047f) * H, H * 0.03f, Color.WHITE); y += 0.08f
        for ((i, r) in g.net.remotes.values.withIndex()) {
            if (y > 0.80f) break
            rbox(c, rect(0.62f, y, 0.97f, y + 0.07f), panel, cyan)
            text(c, "${r.name}  ${CARS[r.car].name}", W * 0.635f, (y + 0.047f) * H, H * 0.028f, Color.WHITE)
            if (g.isAdmin && g.net.mode == 1) btn(c, rect(0.90f, y + 0.008f, 0.965f, y + 0.062f), 200 + i, "KICK", false, Color.rgb(255, 90, 90), true, 0.022f)
            y += 0.08f
        }
    }

    private fun pageOptions(c: Canvas) {
        val modes = arrayOf("WHEEL", "BUTTONS", "TILT")
        btn(c, rect(0.03f, 0.16f, 0.48f, 0.26f), 33, "STEERING: ${modes[g.steerMode]}", false, cyan, true, 0.034f)
        btn(c, rect(0.52f, 0.16f, 0.97f, 0.26f), 32, "TILT INVERT: ${if (g.tiltInv) "ON" else "OFF"}", g.tiltInv, cyan, true, 0.034f)
        btn(c, rect(0.03f, 0.30f, 0.48f, 0.40f), 34, "CONTROL SIZE: ${arrayOf("SMALL", "MEDIUM", "LARGE")[g.ctlSize]}", false, cyan, true, 0.034f)
        text(c, "VOLUME", W * 0.52f, H * 0.345f, H * 0.032f, Color.WHITE)
        btn(c, rect(0.64f, 0.30f, 0.70f, 0.40f), 35, "-", false, cyan, true, 0.05f)
        bar(c, W * 0.72f, H * 0.34f, W * 0.17f, "${g.volume * 10}%", g.volume / 10f)
        btn(c, rect(0.91f, 0.30f, 0.97f, 0.40f), 36, "+", false, cyan, true, 0.05f)
        val lines = listOf("Wheel: drag in a circle. It returns to centre when released.",
            "Pedals: slide your thumb - lower on the pedal = more power / brake.",
            "Keyboard: W/S gas+brake, A/D steer, SPACE drift, SHIFT nitro, C camera, R reset.",
            "Gamepad: left stick steer, triggers gas/brake, A drift, B nitro.")
        for ((i, l) in lines.withIndex()) text(c, l, W * 0.03f, (0.50f + i * 0.07f) * H, H * 0.028f, Color.argb(215, 255, 255, 255))
    }

    private fun pageAdmin(c: Canvas) {
        if (!g.isAdmin) {
            text(c, "ADMIN PANEL  (locked)", W * 0.03f, H * 0.20f, H * 0.05f, gold)
            text(c, "Sign in with the admin Google account (set in Game.kt),", W * 0.03f, H * 0.30f, H * 0.03f, Color.WHITE)
            text(c, "or enter the admin PIN.", W * 0.03f, H * 0.35f, H * 0.03f, Color.WHITE)
            btn(c, rect(0.03f, 0.42f, 0.30f, 0.52f), 46, "ENTER PIN", false, gold, true, 0.036f)
            return
        }
        text(c, "ADMIN PANEL", W * 0.03f, H * 0.17f, H * 0.04f, gold)
        val items = listOf(70 to "+10K COINS", 71 to "+100K COINS", 72 to "LEVEL +1", 73 to "UNLOCK CARS", 74 to "RESET DATA", 90 to "REFILL NITRO",
            83 to "INF NITRO: ${if (g.infiniteNitro) "ON" else "OFF"}", 91 to "BROADCAST MSG", 93 to "RESET PHYSICS",
            84 to "TP PLAZA", 85 to "TP RING ROAD", 86 to "TP HIGHWAY", 87 to "TP MOUNTAIN", 88 to "TP DIRT TRACK", 89 to "TP DRIFT PARK")
        for ((i, it) in items.withIndex()) {
            val col = i % 5; val row = i / 5
            btn(c, rect(0.03f + col * 0.19f, 0.20f + row * 0.115f, 0.03f + col * 0.19f + 0.175f, 0.20f + row * 0.115f + 0.095f), it.first, it.second, false, gold, true, 0.024f)
        }
        val ph = listOf(Triple("POWER", g.car.powerMul, 75), Triple("GRIP", g.gripAdm, 77), Triple("DRIFT ASSIST", g.car.assist, 79), Triple("YAW DAMP", g.car.ydamp / 2.6f, 81))
        for ((i, t) in ph.withIndex()) {
            val x = 0.03f + (i % 2) * 0.48f; val y = 0.57f + (i / 2) * 0.13f
            text(c, "${t.first}  x${"%.1f".format(t.second)}", x * W, (y + 0.07f) * H, H * 0.03f, Color.WHITE)
            btn(c, rect(x + 0.24f, y, x + 0.30f, y + 0.095f), t.third, "-", false, cyan, true, 0.05f)
            btn(c, rect(x + 0.32f, y, x + 0.38f, y + 0.095f), t.third + 1, "+", false, cyan, true, 0.05f)
        }
    }
}
