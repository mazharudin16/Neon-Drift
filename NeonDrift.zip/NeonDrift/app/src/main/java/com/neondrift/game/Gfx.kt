package com.neondrift.game

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.*

private const val NOISE = """
float hh(vec2 p){ vec3 p3 = fract(vec3(p.xyx)*0.1031); p3 += dot(p3, p3.yzx+33.33); return fract((p3.x+p3.y)*p3.z); }
float vn(vec2 p){ vec2 i=floor(p); vec2 f=fract(p); f=f*f*(3.0-2.0*f);
  return mix(mix(hh(i),hh(i+vec2(1.0,0.0)),f.x), mix(hh(i+vec2(0.0,1.0)),hh(i+vec2(1.0,1.0)),f.x), f.y); }
"""

private const val MAIN_VS = """#version 300 es
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aNrm;
layout(location=2) in vec4 aCol;
layout(location=3) in vec2 aUV;
uniform mat4 uVP;
uniform mat4 uModel;
out vec3 vW; out vec3 vN; out vec4 vC; out vec2 vUV;
void main(){
  vec4 w = uModel*vec4(aPos,1.0);
  vW = w.xyz; vN = mat3(uModel)*aNrm; vC = aCol; vUV = aUV;
  gl_Position = uVP*w;
}"""

private const val TREE_VS = """#version 300 es
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aNrm;
layout(location=2) in vec4 aCol;
layout(location=3) in vec2 aUV;
layout(location=4) in vec4 aInst;
uniform mat4 uVP;
out vec3 vW; out vec3 vN; out vec4 vC; out vec2 vUV;
void main(){
  float ang = aInst.w*6.2831;
  float c = cos(ang); float s = sin(ang);
  vec3 p = vec3(aPos.x*c - aPos.z*s, aPos.y, aPos.x*s + aPos.z*c)*aInst.z;
  vW = p + vec3(aInst.x, 0.0, aInst.y);
  vN = vec3(aNrm.x*c - aNrm.z*s, aNrm.y, aNrm.x*s + aNrm.z*c);
  vC = vec4(aCol.rgb*(0.78 + 0.44*fract(aInst.w*13.7)), aCol.a);
  vUV = vec2(-1.0, -1.0);
  gl_Position = uVP*vec4(vW,1.0);
}"""

private const val MAIN_FS = """#version 300 es
precision highp float;
in vec3 vW; in vec3 vN; in vec4 vC; in vec2 vUV;
uniform vec3 uCam; uniform vec3 uSun; uniform vec3 uSunCol; uniform vec3 uAmbS; uniform vec3 uAmbG;
uniform vec3 uTint; uniform float uGloss; uniform sampler2D uTex;
uniform vec3 uFogC; uniform float uFogD; uniform vec3 uHor; uniform vec3 uZen;
out vec4 o;
$NOISE
void main(){
  vec3 N = normalize(vN); vec3 V = normalize(uCam - vW);
  if (dot(N,V) < 0.0) N = -N;
  vec3 base = vC.rgb * uTint;
  float gl = uGloss;
  float em = vC.a;
  if (vUV.x >= 0.0) {
    vec3 t = texture(uTex, vUV).rgb;
    float wnd = step(0.06, t.b - t.r);
    base *= t * 1.75; gl += wnd * 0.55;
    base *= 0.7 + 0.3*clamp(vW.y/12.0, 0.0, 1.0);
  } else if (vUV.x < -1.5) {
    float n1 = vn(vW.xz*0.3); float n2 = vn(vW.xz*2.7); float n3 = vn(vec2(vW.x*11.0, vW.z*1.7));
    base *= 0.70 + 0.55*n1 + 0.30*(n2-0.5) + 0.12*(n3-0.5);
  }
  vec3 L = normalize(uSun);
  float dif = max(dot(N,L), 0.0);
  vec3 amb = mix(uAmbG, uAmbS, N.y*0.5 + 0.5);
  vec3 col = base * (amb + dif*uSunCol);
  float fr = pow(1.0 - max(dot(N,V),0.0), 4.0);
  vec3 R = reflect(-V,N);
  vec3 sk = mix(uHor, uZen, clamp(R.y*1.4, 0.0, 1.0));
  col += sk * (fr*0.9 + 0.06) * gl;
  vec3 H = normalize(L+V);
  col += uSunCol * pow(max(dot(N,H),0.0), 90.0) * gl;
  col = mix(col, base*2.0 + vec3(0.1), em);
  float d = length(uCam - vW);
  float f = clamp(1.0 - exp(-d*uFogD), 0.0, 1.0);
  col = mix(col, uFogC, f);
  col *= 0.95;
  col = (col*(2.51*col+0.03))/(col*(2.43*col+0.59)+0.14);
  col = pow(col, vec3(0.4545));
  o = vec4(col, 1.0);
}"""

private const val SKY_VS = """#version 300 es
layout(location=0) in vec2 aP;
out vec2 vP;
void main(){ vP = aP; gl_Position = vec4(aP, 0.9999, 1.0); }"""

private const val SKY_FS = """#version 300 es
precision highp float;
in vec2 vP;
uniform vec3 uF; uniform vec3 uR; uniform vec3 uU; uniform vec2 uT;
uniform vec3 uHor; uniform vec3 uZen; uniform vec3 uSun; uniform float uTime;
out vec4 o;
$NOISE
float fbm(vec2 p){ float a = 0.5; float s = 0.0; for (int i=0;i<4;i++){ s += a*vn(p); p *= 2.03; a *= 0.5; } return s; }
void main(){
  vec3 d = normalize(uF + vP.x*uT.x*uR + vP.y*uT.y*uU);
  float t = clamp(d.y, 0.0, 1.0);
  vec3 col = mix(uHor, uZen, pow(t, 0.5));
  if (d.y < 0.0) col = uHor;
  vec3 sd = normalize(uSun);
  float s = dot(d, sd);
  col += vec3(1.0,0.85,0.6) * (pow(max(s,0.0), 6.0)*0.10 + pow(max(s,0.0), 80.0)*0.5);
  col += vec3(1.0,0.95,0.85) * smoothstep(0.9994, 0.9998, s) * 5.0;
  if (d.y > 0.0) {
    vec2 uv = d.xz/(d.y + 0.18)*1.4 + vec2(uTime*0.012, 0.0);
    float c = smoothstep(0.50, 0.78, fbm(uv));
    float lit = 0.80 + 0.35*clamp(dot(normalize(vec3(d.x,0.3,d.z)), normalize(vec3(sd.x,0.3,sd.z))), 0.0, 1.0);
    col = mix(col, vec3(1.0,1.0,1.04)*lit, c*0.9*smoothstep(0.0, 0.14, d.y));
  }
  col *= 0.95;
  col = (col*(2.51*col+0.03))/(col*(2.43*col+0.59)+0.14);
  col = pow(col, vec3(0.4545));
  o = vec4(col, 1.0);
}"""

private const val SPR_VS = """#version 300 es
layout(location=0) in vec3 aC;
layout(location=1) in vec2 aK;
layout(location=2) in float aS;
layout(location=3) in vec4 aCol;
uniform mat4 uVP; uniform vec3 uRt; uniform vec3 uUp;
out vec2 vK; out vec4 vCol;
void main(){
  vec3 p = aC + (uRt*aK.x + uUp*aK.y)*aS;
  vK = aK; vCol = aCol;
  gl_Position = uVP*vec4(p,1.0);
}"""

private const val SPR_FS = """#version 300 es
precision mediump float;
in vec2 vK; in vec4 vCol;
uniform float uMode; uniform float uPow;
out vec4 o;
void main(){
  float r = length(vK);
  if (r > 1.0) discard;
  float a = pow(1.0 - r, uPow) * vCol.a;
  if (uMode > 0.5) o = vec4(vCol.rgb, a); else o = vec4(vCol.rgb*a, 1.0);
}"""

private const val DEC_VS = """#version 300 es
layout(location=0) in vec3 aP;
layout(location=1) in vec2 aUV;
layout(location=2) in vec4 aCol;
uniform mat4 uVP;
out vec2 vUV; out vec4 vCol;
void main(){ vUV = aUV; vCol = aCol; gl_Position = uVP*vec4(aP,1.0); }"""

private const val DEC_FS = """#version 300 es
precision mediump float;
in vec2 vUV; in vec4 vCol;
out vec4 o;
void main(){
  float a = vUV.x > 5.0 ? 1.0 : smoothstep(1.0, 0.15, length(vUV));
  o = vec4(vCol.rgb, vCol.a*a);
}"""

private fun compile(type: Int, src: String): Int {
    val s = GLES30.glCreateShader(type)
    GLES30.glShaderSource(s, src)
    GLES30.glCompileShader(s)
    val st = IntArray(1)
    GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, st, 0)
    if (st[0] == 0) throw RuntimeException("Shader error: " + GLES30.glGetShaderInfoLog(s))
    return s
}

class Prog(vs: String, fs: String) {
    val id: Int = GLES30.glCreateProgram()
    private val locs = HashMap<String, Int>()
    init {
        GLES30.glAttachShader(id, compile(GLES30.GL_VERTEX_SHADER, vs))
        GLES30.glAttachShader(id, compile(GLES30.GL_FRAGMENT_SHADER, fs))
        GLES30.glLinkProgram(id)
        val st = IntArray(1)
        GLES30.glGetProgramiv(id, GLES30.GL_LINK_STATUS, st, 0)
        if (st[0] == 0) throw RuntimeException("Link error: " + GLES30.glGetProgramInfoLog(id))
    }
    fun u(n: String): Int = locs.getOrPut(n) { GLES30.glGetUniformLocation(id, n) }
}

class Gpu(val id: Int, val count: Int)
class ChunkGpu {
    var ground: Gpu? = null; var road: Gpu? = null; var marks: Gpu? = null
    val inst = arrayOfNulls<Gpu>(4)
}

private fun fbuf(len: Int): FloatBuffer = ByteBuffer.allocateDirect(len * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
private fun newBuf(): Int { val a = IntArray(1); GLES30.glGenBuffers(1, a, 0); return a[0] }

private fun uploadFloats(a: FloatArray, n: Int, count: Int): Gpu {
    val id = newBuf()
    val b = fbuf(n); b.put(a, 0, n); b.position(0)
    GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, id)
    GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, n * 4, b, GLES30.GL_STATIC_DRAW)
    return Gpu(id, count)
}
private fun uploadMesh(mb: MB): Gpu = uploadFloats(mb.d, mb.n, mb.verts)
private fun upMesh(mb: MB?): Gpu? = if (mb == null || mb.n == 0) null else uploadMesh(mb)
private fun upInst(fl: FL): Gpu? = if (fl.n == 0) null else uploadFloats(fl.a, fl.n, fl.count)

private fun enableAttribs(n: Int) {
    for (i in 0 until 4) if (i < n) GLES30.glEnableVertexAttribArray(i) else GLES30.glDisableVertexAttribArray(i)
}

class Renderer(private val g: Game) : GLSurfaceView.Renderer {
    private lateinit var main: Prog
    private lateinit var treeP: Prog
    private lateinit var skyP: Prog
    private lateinit var sprP: Prog
    private lateinit var decP: Prog
    private var props: Array<Gpu>? = null
    private var chunkGpu: Array<ChunkGpu>? = null
    private var outerGpu: Gpu? = null
    private var mountGpu: Gpu? = null
    private var uploaded = false
    private val carCache = HashMap<Int, Array<Gpu>>()
    private var tex = 0
    private var skyBuf = 0; private var sprBuf = 0; private var decBuf = 0; private var skidBuf = 0
    private val sprA = FloatArray(11 * 6 * 700)
    private val sprB = FloatArray(11 * 6 * 500)
    private val sprFB = fbuf(11 * 6 * 700)
    private val decA = FloatArray(9 * 6 * 24)
    private val decFB = fbuf(9 * 6 * 24)
    private val skFB = fbuf(1500 * 54)
    private val proj = FloatArray(16); private val view = FloatArray(16); private val vp = FloatArray(16)
    private val mBody = FloatArray(16); private val mYaw = FloatArray(16); private val mTmp = FloatArray(16); private val mId = FloatArray(16)
    private val vis = IntArray(NC * NC); private val visD = FloatArray(NC * NC); private var visN = 0
    private var aspect = 1.78f
    private var last = 0L

    private val hor = floatArrayOf(0.62f, 0.76f, 0.94f)
    private val zen = floatArrayOf(0.14f, 0.30f, 0.75f)
    private val sun = floatArrayOf(0.40f, 0.78f, 0.48f)

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        main = Prog(MAIN_VS, MAIN_FS); treeP = Prog(TREE_VS, MAIN_FS); skyP = Prog(SKY_VS, SKY_FS)
        sprP = Prog(SPR_VS, SPR_FS); decP = Prog(DEC_VS, DEC_FS)
        val pm = buildProps()
        props = Array(4) { uploadMesh(pm[it]) }
        skyBuf = newBuf(); sprBuf = newBuf(); decBuf = newBuf(); skidBuf = newBuf()
        val qb = fbuf(8); qb.put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)); qb.position(0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, skyBuf)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, 32, qb, GLES30.GL_STATIC_DRAW)
        makeTexture()
        carCache.clear(); uploaded = false; chunkGpu = null
        Matrix.setIdentityM(mId, 0)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        last = 0L
    }

    private fun makeTexture() {
        val bmp = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp); cv.drawColor(Color.rgb(150, 152, 157))
        val p = Paint(); val rnd = java.util.Random(3)
        for (cy in 0 until 8) for (cx in 0 until 8) {
            val x = cx * 32f; val y = cy * 32f
            val k = rnd.nextFloat()
            p.color = when {
                k < 0.35f -> Color.rgb(30, 62, 105)
                k < 0.65f -> Color.rgb(42, 78, 125)
                k < 0.90f -> Color.rgb(26, 48, 84)
                else -> Color.rgb(95, 150, 200)
            }
            cv.drawRect(x + 6, y + 7, x + 26, y + 25, p)
            p.color = Color.rgb(120, 122, 128); cv.drawRect(x + 6, y + 25, x + 26, y + 27, p)
        }
        val id = IntArray(1); GLES30.glGenTextures(1, id, 0); tex = id[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tex)
        GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0)
        GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR_MIPMAP_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_REPEAT)
        bmp.recycle()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES30.glViewport(0, 0, width, height)
        aspect = width.toFloat() / max(1, height)
    }

    private fun uploadWorld() {
        val w = g.world
        outerGpu = uploadMesh(w.outer!!); mountGpu = uploadMesh(w.mountains!!)
        chunkGpu = Array(NC * NC) { i ->
            val cd = w.chunks[i]
            val cg = ChunkGpu()
            cg.ground = upMesh(cd.ground); cg.road = upMesh(cd.road); cg.marks = upMesh(cd.marks)
            for (k in 0..3) cg.inst[k] = upInst(cd.inst[k])
            cg
        }
        w.releaseMeshes()
        uploaded = true
    }

    private fun partsFor(style: Int): Array<Gpu> = carCache.getOrPut(style) {
        val m = buildCar(style)
        arrayOf(uploadMesh(m.paint), uploadMesh(m.trim), uploadMesh(m.glass), uploadMesh(m.head), uploadMesh(m.tail), uploadMesh(m.wheel))
    }

    private fun bindMesh(m: Gpu) {
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, m.id)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 48, 0)
        GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, 48, 12)
        GLES30.glVertexAttribPointer(2, 4, GLES30.GL_FLOAT, false, 48, 24)
        GLES30.glVertexAttribPointer(3, 2, GLES30.GL_FLOAT, false, 48, 40)
    }

    private fun drawGpu(m: Gpu) { bindMesh(m); GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, m.count) }

    private fun obj(model: FloatArray, tr: Float, tg: Float, tb: Float, gloss: Float) {
        GLES30.glUniformMatrix4fv(main.u("uModel"), 1, false, model, 0)
        GLES30.glUniform3f(main.u("uTint"), tr, tg, tb)
        GLES30.glUniform1f(main.u("uGloss"), gloss)
    }

    private fun scene(p: Prog, fog: Float) {
        GLES30.glUniformMatrix4fv(p.u("uVP"), 1, false, vp, 0)
        GLES30.glUniform3f(p.u("uCam"), g.camX, g.camY, g.camZ)
        GLES30.glUniform3f(p.u("uSun"), sun[0], sun[1], sun[2])
        GLES30.glUniform3f(p.u("uSunCol"), 1.08f, 0.95f, 0.80f)
        GLES30.glUniform3f(p.u("uAmbS"), 0.38f, 0.46f, 0.68f)
        GLES30.glUniform3f(p.u("uAmbG"), 0.20f, 0.19f, 0.16f)
        GLES30.glUniform3f(p.u("uHor"), hor[0], hor[1], hor[2]); GLES30.glUniform3f(p.u("uZen"), zen[0], zen[1], zen[2])
        GLES30.glUniform3f(p.u("uFogC"), hor[0], hor[1], hor[2])
        GLES30.glUniform1f(p.u("uFogD"), fog)
        GLES30.glUniform1i(p.u("uTex"), 0)
    }

    private fun sprite(a: FloatArray, idx: Int, x: Float, y: Float, z: Float, s: Float, r: Float, gg: Float, b: Float, al: Float): Int {
        var i = idx
        if (i + 66 > a.size) return i
        for (k in 0 until 6) {
            a[i++] = x; a[i++] = y; a[i++] = z
            a[i++] = SPR_K[k * 2]; a[i++] = SPR_K[k * 2 + 1]
            a[i++] = s
            a[i++] = r; a[i++] = gg; a[i++] = b; a[i++] = al
            a[i++] = 0f
        }
        return i
    }

    private fun drawCar(parts: Array<Gpu>, x: Float, z: Float, psi: Float, pitch: Float, roll: Float,
                        steerDeg: Float, spinDeg: Float, paint: FloatArray, brake: Boolean, hasGlass: Boolean = true) {
        Matrix.setIdentityM(mYaw, 0)
        Matrix.translateM(mYaw, 0, x, 0f, z)
        Matrix.rotateM(mYaw, 0, Math.toDegrees(psi.toDouble()).toFloat(), 0f, 1f, 0f)
        System.arraycopy(mYaw, 0, mBody, 0, 16)
        Matrix.translateM(mBody, 0, 0f, 0.45f, 0f)
        Matrix.rotateM(mBody, 0, pitch, 1f, 0f, 0f)
        Matrix.rotateM(mBody, 0, roll, 0f, 0f, 1f)
        Matrix.translateM(mBody, 0, 0f, -0.45f, 0f)
        bindMesh(parts[0]); obj(mBody, paint[0], paint[1], paint[2], 1.0f); GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, parts[0].count)
        obj(mBody, 1f, 1f, 1f, 0.55f); drawGpu(parts[1])
        // Glass (semi-transparent - drawn last with blend)
        obj(mBody, 0.15f, 0.22f, 0.30f, 0.0f); drawGpu(parts[2])
        obj(mBody, 1f, 1f, 1f, 0f); drawGpu(parts[3])
        val tl = if (brake) 1.9f else 0.7f
        obj(mBody, tl, tl, tl, 0f); drawGpu(parts[4])
        bindMesh(parts[5])
        for (i in 0..3) {
            val xl = if (i % 2 == 0) 0.84f else -0.84f
            val zl = if (i < 2) -1.3f else 1.3f
            System.arraycopy(mYaw, 0, mTmp, 0, 16)
            Matrix.translateM(mTmp, 0, xl, 0.34f, zl)
            if (i >= 2) Matrix.rotateM(mTmp, 0, steerDeg, 0f, 1f, 0f)
            Matrix.rotateM(mTmp, 0, spinDeg, 1f, 0f, 0f)
            obj(mTmp, 1f, 1f, 1f, 0.3f)
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, parts[5].count)
        }
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        var dt = if (last == 0L) 0.016f else (now - last) / 1e9f
        last = now
        dt = dt.coerceIn(0.001f, 0.05f)
        g.update(dt)

        GLES30.glClearColor(hor[0], hor[1], hor[2], 1f)
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)
        if (!g.ready) return
        if (!uploaded) { uploadWorld(); return }

        val car = g.car
        Matrix.perspectiveM(proj, 0, g.fov, aspect, 1.0f, 4500f)
        Matrix.setLookAtM(view, 0, g.camX, g.camY, g.camZ, g.lookX, g.lookY, g.lookZ, 0f, 1f, 0f)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)
        System.arraycopy(vp, 0, g.vp, 0, 16)

        var fX = g.lookX - g.camX; var fY = g.lookY - g.camY; var fZ = g.lookZ - g.camZ
        val fl = sqrt(fX * fX + fY * fY + fZ * fZ); fX /= fl; fY /= fl; fZ /= fl
        var rX = -fZ; val rY = 0f; var rZ = fX
        val rl = sqrt(rX * rX + rZ * rZ).coerceAtLeast(0.0001f); rX /= rl; rZ /= rl
        val uX = rY * fZ - rZ * fY; val uY = rZ * fX - rX * fZ; val uZ = rX * fY - rY * fX

        // visible chunks
        visN = 0
        for (i in 0 until NC * NC) {
            val dx = -HALF + (i % NC + 0.5f) * CH - g.camX; val dz = -HALF + (i / NC + 0.5f) * CH - g.camZ
            val d2 = dx * dx + dz * dz
            if (d2 < 2500f * 2500f) { vis[visN] = i; visD[visN] = d2; visN++ }
        }
        val cgs = chunkGpu!!
        val FOG = 0.0008f

        // ---- sky ----
        GLES30.glDisable(GLES30.GL_DEPTH_TEST)
        GLES30.glUseProgram(skyP.id)
        val ty = tan(Math.toRadians(g.fov / 2.0)).toFloat()
        GLES30.glUniform3f(skyP.u("uF"), fX, fY, fZ); GLES30.glUniform3f(skyP.u("uR"), rX, rY, rZ); GLES30.glUniform3f(skyP.u("uU"), uX, uY, uZ)
        GLES30.glUniform2f(skyP.u("uT"), ty * aspect, ty)
        GLES30.glUniform3f(skyP.u("uHor"), hor[0], hor[1], hor[2]); GLES30.glUniform3f(skyP.u("uZen"), zen[0], zen[1], zen[2])
        GLES30.glUniform3f(skyP.u("uSun"), sun[0], sun[1], sun[2])
        GLES30.glUniform1f(skyP.u("uTime"), g.time)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, skyBuf)
        enableAttribs(1)
        GLES30.glVertexAttribPointer(0, 2, GLES30.GL_FLOAT, false, 8, 0)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)

        // ---- world ----
        GLES30.glUseProgram(main.id)
        scene(main, FOG)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0); GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tex)
        enableAttribs(4)
        obj(mId, 1f, 1f, 1f, 0.02f)
        outerGpu?.let { drawGpu(it) }
        GLES30.glUniform1f(main.u("uFogD"), 0.00035f)
        mountGpu?.let { drawGpu(it) }
        GLES30.glUniform1f(main.u("uFogD"), FOG)
        obj(mId, 1f, 1f, 1f, 0.06f)
        for (j in 0 until visN) cgs[vis[j]].ground?.let { drawGpu(it) }
        GLES30.glEnable(GLES30.GL_POLYGON_OFFSET_FILL)
        GLES30.glPolygonOffset(-1f, -1f)
        obj(mId, 1f, 1f, 1f, 0.28f)
        for (j in 0 until visN) cgs[vis[j]].road?.let { drawGpu(it) }
        GLES30.glPolygonOffset(-2f, -2f)
        for (j in 0 until visN) cgs[vis[j]].marks?.let { drawGpu(it) }
        GLES30.glDisable(GLES30.GL_POLYGON_OFFSET_FILL)

        // ---- trees, grass, rocks (instanced) ----
        val pr = props!!
        GLES30.glUseProgram(treeP.id)
        scene(treeP, FOG)
        GLES30.glUniform3f(treeP.u("uTint"), 1f, 1f, 1f)
        GLES30.glUniform1f(treeP.u("uGloss"), 0.03f)
        for (k in 0..3) {
            val lim = TREE_LIM[k]
            bindMesh(pr[k])
            for (j in 0 until visN) {
                if (visD[j] > lim * lim) continue
                val ig = cgs[vis[j]].inst[k] ?: continue
                GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, ig.id)
                GLES30.glEnableVertexAttribArray(4)
                GLES30.glVertexAttribPointer(4, 4, GLES30.GL_FLOAT, false, 16, 0)
                GLES30.glVertexAttribDivisor(4, 1)
                GLES30.glDrawArraysInstanced(GLES30.GL_TRIANGLES, 0, pr[k].count, ig.count)
                GLES30.glVertexAttribDivisor(4, 0)
            }
        }
        GLES30.glDisableVertexAttribArray(4)

        // ---- cars ----
        GLES30.glUseProgram(main.id)
        enableAttribs(4)
        val pc = PAINTS[g.paintIdx]
        val pitch = (-car.ax * 0.5f).coerceIn(-4f, 4f)
        val roll = (car.ay * 0.35f).coerceIn(-5f, 5f)
        drawCar(partsFor(g.spec().style), car.x, car.z, car.psi, pitch, roll,
            Math.toDegrees(car.steerAngle.toDouble()).toFloat(), Math.toDegrees(car.wheelSpin.toDouble()).toFloat(), pc, g.braking)
        for (r in g.net.remotes.values) {
            if (!r.inited) { r.x = r.tx; r.z = r.tz; r.psi = r.tpsi; r.inited = true }
            val k = min(1f, dt * 9f)
            if (abs(r.tx - r.x) > 60f || abs(r.tz - r.z) > 60f) { r.x = r.tx; r.z = r.tz }
            r.x += (r.tx - r.x) * k; r.z += (r.tz - r.z) * k
            var da = r.tpsi - r.psi
            while (da > PI) da -= (2 * PI).toFloat()
            while (da < -PI) da += (2 * PI).toFloat()
            r.psi += da * k
            r.spin += r.u / CarPhysics.RW * dt
            drawCar(partsFor(CARS[r.car].style), r.x, r.z, r.psi, 0f, 0f,
                Math.toDegrees(r.steer.toDouble()).toFloat(), Math.toDegrees(r.spin.toDouble()).toFloat(), PAINTS[r.paint], false)
        }

        // ---- decals ----
        GLES30.glEnable(GLES30.GL_BLEND)
        GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)
        GLES30.glDepthMask(false)
        GLES30.glUseProgram(decP.id)
        GLES30.glUniformMatrix4fv(decP.u("uVP"), 1, false, vp, 0)
        enableAttribs(3)
        val fx = g.fx
        if (fx.skCount > 0) {
            skFB.clear()
            if (fx.skCount == fx.skMax) {
                skFB.put(fx.sk, fx.skHead * 54, (fx.skMax - fx.skHead) * 54)
                skFB.put(fx.sk, 0, fx.skHead * 54)
            } else skFB.put(fx.sk, 0, fx.skCount * 54)
            skFB.position(0)
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, skidBuf)
            GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, fx.skCount * 54 * 4, skFB, GLES30.GL_STREAM_DRAW)
            drawDecalBound(fx.skCount * 6)
        }
        val sn = sin(car.psi); val cs = cos(car.psi)
        var di = 0
        di = decQuad(decA, di, car.x, car.z, sn, cs, 3.1f, 1.9f, 0.10f, 1f, 0.15f, 0.9f, 0.18f)
        di = decQuad(decA, di, car.x, car.z, sn, cs, 2.7f, 1.45f, 0.11f, 0f, 0f, 0f, 0.5f)
        for (r in g.net.remotes.values) di = decQuad(decA, di, r.x, r.z, sin(r.psi), cos(r.psi), 2.7f, 1.45f, 0.11f, 0f, 0f, 0f, 0.5f)
        decFB.clear(); decFB.put(decA, 0, di); decFB.position(0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, decBuf)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, di * 4, decFB, GLES30.GL_STREAM_DRAW)
        drawDecalBound(di / 9)

        // ---- sprites ----
        GLES30.glUseProgram(sprP.id)
        GLES30.glUniformMatrix4fv(sprP.u("uVP"), 1, false, vp, 0)
        GLES30.glUniform3f(sprP.u("uRt"), rX, rY, rZ); GLES30.glUniform3f(sprP.u("uUp"), uX, uY, uZ)
        var ia = 0; var ib = 0
        if (g.braking) ia = sprite(sprA, ia, car.x - sn * 2.15f, 0.82f, car.z - cs * 2.15f, 1.3f, 1f, 0.05f, 0.05f, 0.8f)
        val p = fx.p
        for (i in 0 until fx.cnt) {
            val o = i * 10
            val age = p[o + 6] / p[o + 7]
            val kind = p[o + 9]
            if (kind == 1f) {
                ia = sprite(sprA, ia, p[o], p[o + 1], p[o + 2], p[o + 8] * (1f - age * 0.5f), 1f, 0.55f + 0.3f * age, 0.15f, 0.9f * (1f - age))
            } else {
                val cr = if (kind == 0f) 0.93f else if (kind == 2f) 0.74f else 0.50f
                val cg = if (kind == 0f) 0.93f else if (kind == 2f) 0.62f else 0.55f
                val cb = if (kind == 0f) 0.95f else if (kind == 2f) 0.46f else 0.34f
                ib = sprite(sprB, ib, p[o], p[o + 1], p[o + 2], p[o + 8] * (0.6f + age * 2.2f), cr, cg, cb, 0.40f * (1f - age))
            }
        }
        if (g.raceOn && g.cpI < g.cpN) {
            val bx = g.cps[g.cpI * 2]; val bz = g.cps[g.cpI * 2 + 1]
            for (k in 0 until 14) ia = sprite(sprA, ia, bx, 2f + k * 4f, bz, 7f - k * 0.2f, 0.2f, 0.9f, 1f, 0.55f)
            for (k in 0 until 6) { val a = (k * 1.0472f) + g.time; ia = sprite(sprA, ia, bx + sin(a) * 14f, 1.5f, bz + cos(a) * 14f, 3f, 1f, 0.8f, 0.2f, 0.7f) }
        }
        enableAttribs(4)
        if (ia > 0) drawSprites(sprA, ia, 0f, 2.2f)
        if (ib > 0) { GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA); drawSprites(sprB, ib, 1f, 0.8f) }

        GLES30.glDepthMask(true)
        GLES30.glDisable(GLES30.GL_BLEND)
    }

    private fun drawSprites(a: FloatArray, len: Int, mode: Float, pw: Float) {
        if (mode < 0.5f) GLES30.glBlendFunc(GLES30.GL_ONE, GLES30.GL_ONE)
        sprFB.clear(); sprFB.put(a, 0, len); sprFB.position(0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, sprBuf)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, len * 4, sprFB, GLES30.GL_STREAM_DRAW)
        GLES30.glUniform1f(sprP.u("uMode"), mode); GLES30.glUniform1f(sprP.u("uPow"), pw)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 44, 0)
        GLES30.glVertexAttribPointer(1, 2, GLES30.GL_FLOAT, false, 44, 12)
        GLES30.glVertexAttribPointer(2, 1, GLES30.GL_FLOAT, false, 44, 20)
        GLES30.glVertexAttribPointer(3, 4, GLES30.GL_FLOAT, false, 44, 24)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, len / 11)
    }

    private fun drawDecalBound(count: Int) {
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 36, 0)
        GLES30.glVertexAttribPointer(1, 2, GLES30.GL_FLOAT, false, 36, 12)
        GLES30.glVertexAttribPointer(2, 4, GLES30.GL_FLOAT, false, 36, 20)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, count)
    }

    private fun decQuad(a: FloatArray, idx: Int, cx: Float, cz: Float, sn: Float, cs: Float, hl: Float, hw: Float, y: Float,
                        r: Float, gg: Float, b: Float, al: Float): Int {
        var i = idx
        if (i + 54 > a.size) return i
        val fxv = sn * hl; val fzv = cs * hl; val lx = cs * hw; val lz = -sn * hw
        val px = floatArrayOf(cx - fxv - lx, cx + fxv - lx, cx + fxv + lx, cx - fxv - lx, cx + fxv + lx, cx - fxv + lx)
        val pz = floatArrayOf(cz - fzv - lz, cz + fzv - lz, cz + fzv + lz, cz - fzv - lz, cz + fzv + lz, cz - fzv + lz)
        val uu = floatArrayOf(-1f, -1f, 1f, -1f, 1f, 1f, -1f, -1f, 1f, 1f, -1f, 1f)
        for (k in 0 until 6) {
            a[i++] = px[k]; a[i++] = y; a[i++] = pz[k]; a[i++] = uu[k * 2]; a[i++] = uu[k * 2 + 1]
            a[i++] = r; a[i++] = gg; a[i++] = b; a[i++] = al
        }
        return i
    }

    companion object {
        private val SPR_K = floatArrayOf(-1f, -1f, 1f, -1f, 1f, 1f, -1f, -1f, 1f, 1f, -1f, 1f)
        private val TREE_LIM = floatArrayOf(1000f, 1000f, 400f, 600f)
    }
}
