package com.neondrift.game

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.*

// ── PBR + shadow-map renderer ───────────────────────────────────────────────

private const val SHADOW_SIZE = 2048

// ── Shadow pass ──────────────────────────────────────────────────────────────
private const val SHAD_VS = """#version 300 es
layout(location=0) in vec3 aPos;
uniform mat4 uLVP;
uniform mat4 uModel;
void main(){ gl_Position = uLVP * uModel * vec4(aPos,1.0); }"""

private const val SHAD_FS = """#version 300 es
precision highp float;
void main(){}"""

// ── Main PBR pass ─────────────────────────────────────────────────────────────
private const val NOISE_GLSL = """
float hh(vec2 p){vec3 p3=fract(vec3(p.xyx)*0.1031);p3+=dot(p3,p3.yzx+33.33);return fract((p3.x+p3.y)*p3.z);}
float vn(vec2 p){vec2 i=floor(p);vec2 f=fract(p);f=f*f*(3.0-2.0*f);
  return mix(mix(hh(i),hh(i+vec2(1,0)),f.x),mix(hh(i+vec2(0,1)),hh(i+vec2(1,1)),f.x),f.y);}
"""

private const val MAIN_VS = """#version 300 es
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aNrm;
layout(location=2) in vec4 aCol;
layout(location=3) in vec2 aUV;
uniform mat4 uVP, uModel, uLVP;
out vec3 vW; out vec3 vN; out vec4 vC; out vec2 vUV; out vec4 vLS;
void main(){
  vec4 w = uModel*vec4(aPos,1.0);
  vW=w.xyz; vN=mat3(uModel)*aNrm; vC=aCol; vUV=aUV;
  vLS = uLVP*w;
  gl_Position=uVP*w;
}"""

private const val MAIN_FS = """#version 300 es
precision highp float;
in vec3 vW,vN; in vec4 vC; in vec2 vUV; in vec4 vLS;
uniform vec3 uCam,uSun,uSunC,uAmbS,uAmbG;
uniform vec3 uTint; uniform float uGloss,uMetal;
uniform sampler2D uTex,uShadow;
uniform vec3 uFogC; uniform float uFogD;
uniform vec3 uHor,uZen;
out vec4 o;
NOISE_PLACEHOLDER
float shadow(){
  vec3 p=vLS.xyz/vLS.w*0.5+0.5;
  if(p.z>1.0) return 1.0;
  float bias=0.003;
  float s=0.0;
  vec2 sz=vec2(1.0/float($SHADOW_SIZE));
  for(int x=-1;x<=1;x++) for(int y=-1;y<=1;y++){
    float d=texture(uShadow,p.xy+vec2(x,y)*sz).r;
    s+=p.z-bias>d?0.0:1.0;
  }
  return s/9.0;
}
void main(){
  vec3 N=normalize(vN); vec3 V=normalize(uCam-vW);
  if(dot(N,V)<0.0) N=-N;
  vec3 base=vC.rgb*uTint; float em=vC.a;
  float metal=uMetal; float rough=1.0-uGloss;

  if(vUV.x>=0.0){
    vec3 t=texture(uTex,vUV).rgb;
    base*=t*1.6;
  } else if(vUV.x<-1.5){
    float n1=vn(vW.xz*0.3); float n2=vn(vW.xz*2.5);
    base*=0.70+0.50*n1+0.25*(n2-0.5);
  }

  // PBR diffuse
  vec3 L=normalize(uSun);
  float NdL=max(dot(N,L),0.0);
  float sh=shadow();
  vec3 amb=mix(uAmbG,uAmbS,N.y*0.5+0.5);
  vec3 diff=base*(1.0-metal)*(amb+uSunC*NdL*sh);

  // PBR specular (Cook-Torrance simplified)
  vec3 H=normalize(L+V);
  float NdH=max(dot(N,H),0.0);
  float NdV=max(dot(N,V),0.001);
  float a=rough*rough; float a2=a*a;
  float denom=NdH*NdH*(a2-1.0)+1.0;
  float D=a2/(3.14159*denom*denom);
  float k=(rough+1.0)*(rough+1.0)/8.0;
  float G=NdV/(NdV*(1.0-k)+k)*NdL/(max(NdL,0.001)*(1.0-k)+k);
  vec3 F0=mix(vec3(0.04),base,metal);
  float fc=pow(1.0-NdV,5.0);
  vec3 F=F0+(1.0-F0)*fc;
  vec3 spec=D*G*F/(4.0*NdV+0.001)*sh*uSunC;

  // IBL approximation
  float fr=pow(1.0-NdV,4.0);
  vec3 R=reflect(-V,N);
  vec3 sk=mix(uHor,uZen,clamp(R.y*1.4,0.0,1.0));
  vec3 ibl=(sk*fr*0.9+sk*0.06)*uGloss;

  vec3 col=diff+spec+ibl;
  col=mix(col,base*2.0+vec3(0.1),em);

  // Fog
  float d=length(uCam-vW);
  float f=clamp(1.0-exp(-d*uFogD),0.0,1.0);
  col=mix(col,uFogC,f);

  // ACES tone map
  col=(col*(2.51*col+0.03))/(col*(2.43*col+0.59)+0.14);
  col=pow(col,vec3(0.4545));
  o=vec4(col,1.0);
}"""

// ── Tree instanced pass ──────────────────────────────────────────────────────
private const val TREE_VS = """#version 300 es
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aNrm;
layout(location=2) in vec4 aCol;
layout(location=3) in vec2 aUV;
layout(location=4) in vec4 aInst;
uniform mat4 uVP;
out vec3 vW,vN; out vec4 vC; out vec2 vUV;
void main(){
  float ang=aInst.w*6.2831; float c=cos(ang),s=sin(ang);
  vec3 p=vec3(aPos.x*c-aPos.z*s,aPos.y,aPos.x*s+aPos.z*c)*aInst.z;
  vW=p+vec3(aInst.x,0.0,aInst.y);
  vN=vec3(aNrm.x*c-aNrm.z*s,aNrm.y,aNrm.x*s+aNrm.z*c);
  vC=vec4(aCol.rgb*(0.80+0.40*fract(aInst.w*13.7)),aCol.a);
  vUV=vec2(-1.0,-1.0);
  gl_Position=uVP*vec4(vW,1.0);
}"""

// ── Sky ─────────────────────────────────────────────────────────────────────
private const val SKY_VS = """#version 300 es
layout(location=0) in vec2 aP; out vec2 vP;
void main(){ vP=aP; gl_Position=vec4(aP,0.9999,1.0); }"""

private const val SKY_FS = """#version 300 es
precision highp float;
in vec2 vP;
uniform vec3 uF,uR,uU; uniform vec2 uT;
uniform vec3 uHor,uZen,uSun; uniform float uTime;
out vec4 o;
NOISE_PLACEHOLDER
float fbm(vec2 p){float a=0.5,s=0.0;for(int i=0;i<4;i++){s+=a*vn(p);p*=2.03;a*=0.5;}return s;}
void main(){
  vec3 d=normalize(uF+vP.x*uT.x*uR+vP.y*uT.y*uU);
  float t=clamp(d.y,0.0,1.0);
  vec3 col=mix(uHor,uZen,pow(t,0.5));
  if(d.y<0.0) col=uHor;
  vec3 sd=normalize(uSun);
  float s=dot(d,sd);
  col+=vec3(1.0,0.85,0.6)*(pow(max(s,0.0),6.0)*0.10+pow(max(s,0.0),80.0)*0.5);
  col+=vec3(1.0,0.95,0.85)*smoothstep(0.9994,0.9998,s)*5.0;
  if(d.y>0.0){
    vec2 uv=d.xz/(d.y+0.18)*1.4+vec2(uTime*0.012,0.0);
    float c=smoothstep(0.50,0.78,fbm(uv));
    float lit=0.80+0.35*clamp(dot(normalize(vec3(d.x,0.3,d.z)),normalize(vec3(sd.x,0.3,sd.z))),0.0,1.0);
    col=mix(col,vec3(1.0,1.0,1.04)*lit,c*0.9*smoothstep(0.0,0.14,d.y));
  }
  col=(col*(2.51*col+0.03))/(col*(2.43*col+0.59)+0.14);
  col=pow(col,vec3(0.4545));
  o=vec4(col,1.0);
}"""

// ── Bloom (2-pass) ───────────────────────────────────────────────────────────
private const val QUAD_VS = """#version 300 es
layout(location=0) in vec2 aP; out vec2 vUV;
void main(){ vUV=aP*0.5+0.5; gl_Position=vec4(aP,0,1); }"""

private const val BRIGHT_FS = """#version 300 es
precision mediump float;
in vec2 vUV; uniform sampler2D uT; out vec4 o;
void main(){
  vec3 c=texture(uT,vUV).rgb;
  float b=dot(c,vec3(0.2126,0.7152,0.0722));
  o=vec4(b>0.82?c:vec3(0.0),1.0);
}"""

private const val BLUR_FS = """#version 300 es
precision mediump float;
in vec2 vUV; uniform sampler2D uT; uniform vec2 uDir; out vec4 o;
void main(){
  vec4 s=vec4(0.0);
  float w[5]; w[0]=0.227;w[1]=0.194;w[2]=0.121;w[3]=0.054;w[4]=0.016;
  s+=texture(uT,vUV)*w[0];
  for(int i=1;i<5;i++){
    s+=texture(uT,vUV+uDir*float(i))*w[i];
    s+=texture(uT,vUV-uDir*float(i))*w[i];
  }
  o=s;
}"""

private const val COMP_FS = """#version 300 es
precision mediump float;
in vec2 vUV; uniform sampler2D uScene,uBloom; uniform float uExposure;
out vec4 o;
void main(){
  vec3 s=texture(uScene,vUV).rgb;
  vec3 b=texture(uBloom,vUV).rgb;
  vec3 c=s+b*0.45;
  // Vignette
  vec2 uv=vUV-0.5; float v=1.0-dot(uv,uv)*1.6;
  c*=max(v,0.0);
  o=vec4(c*uExposure,1.0);
}"""

// ── Sprite / decal ───────────────────────────────────────────────────────────
private const val SPR_VS = """#version 300 es
layout(location=0) in vec3 aC; layout(location=1) in vec2 aK;
layout(location=2) in float aS; layout(location=3) in vec4 aCol;
uniform mat4 uVP; uniform vec3 uRt,uUp; out vec2 vK; out vec4 vCol;
void main(){ vec3 p=aC+(uRt*aK.x+uUp*aK.y)*aS; vK=aK; vCol=aCol; gl_Position=uVP*vec4(p,1.0); }"""

private const val SPR_FS = """#version 300 es
precision mediump float;
in vec2 vK; in vec4 vCol; uniform float uMode,uPow; out vec4 o;
void main(){ float r=length(vK); if(r>1.0) discard; float a=pow(1.0-r,uPow)*vCol.a;
  if(uMode>0.5) o=vec4(vCol.rgb,a); else o=vec4(vCol.rgb*a,1.0); }"""

private const val DEC_VS = """#version 300 es
layout(location=0) in vec3 aP; layout(location=1) in vec2 aUV; layout(location=2) in vec4 aCol;
uniform mat4 uVP; out vec2 vUV; out vec4 vCol;
void main(){ vUV=aUV; vCol=aCol; gl_Position=uVP*vec4(aP,1.0); }"""

private const val DEC_FS = """#version 300 es
precision mediump float;
in vec2 vUV; in vec4 vCol; out vec4 o;
void main(){ float a=vUV.x>5.0?1.0:smoothstep(1.0,0.15,length(vUV)); o=vec4(vCol.rgb,vCol.a*a); }"""

// ── Helpers ──────────────────────────────────────────────────────────────────
private fun compile(type: Int, src: String): Int {
    val s = GLES30.glCreateShader(type)
    GLES30.glShaderSource(s, src); GLES30.glCompileShader(s)
    val st = IntArray(1); GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, st, 0)
    if (st[0] == 0) throw RuntimeException("Shader:\n" + GLES30.glGetShaderInfoLog(s))
    return s
}

class Prog(vs: String, fs: String) {
    val id = GLES30.glCreateProgram()
    private val locs = HashMap<String, Int>()
    init {
        GLES30.glAttachShader(id, compile(GLES30.GL_VERTEX_SHADER, vs))
        GLES30.glAttachShader(id, compile(GLES30.GL_FRAGMENT_SHADER, fs))
        GLES30.glLinkProgram(id)
        val st = IntArray(1); GLES30.glGetProgramiv(id, GLES30.GL_LINK_STATUS, st, 0)
        if (st[0] == 0) throw RuntimeException("Link:\n" + GLES30.glGetProgramInfoLog(id))
    }
    fun u(n: String) = locs.getOrPut(n) { GLES30.glGetUniformLocation(id, n) }
}

class Gpu(val id: Int, val count: Int)
class ChunkGpu { var ground: Gpu? = null; var road: Gpu? = null; var marks: Gpu? = null; val inst = arrayOfNulls<Gpu>(4) }

private fun fbuf(len: Int): FloatBuffer = ByteBuffer.allocateDirect(len * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
private fun newBuf(): Int { val a = IntArray(1); GLES30.glGenBuffers(1, a, 0); return a[0] }
private fun newTex(): Int { val a = IntArray(1); GLES30.glGenTextures(1, a, 0); return a[0] }
private fun newFbo(): Int { val a = IntArray(1); GLES30.glGenFramebuffers(1, a, 0); return a[0] }
private fun newRbo(): Int { val a = IntArray(1); GLES30.glGenRenderbuffers(1, a, 0); return a[0] }

private fun uploadMesh(mb: MB): Gpu {
    val id = newBuf()
    val b = fbuf(mb.n); b.put(mb.d, 0, mb.n); b.position(0)
    GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, id)
    GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, mb.n * 4, b, GLES30.GL_STATIC_DRAW)
    return Gpu(id, mb.verts)
}
private fun upMesh(mb: MB?): Gpu? = if (mb == null || mb.n == 0) null else uploadMesh(mb)
private fun upInst(fl: FL): Gpu? {
    if (fl.n == 0) return null
    val id = newBuf()
    val b = fbuf(fl.n); b.put(fl.a, 0, fl.n); b.position(0)
    GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, id)
    GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, fl.n * 4, b, GLES30.GL_STATIC_DRAW)
    return Gpu(id, fl.count)
}

private fun enableAttribs(n: Int) {
    for (i in 0 until 4) if (i < n) GLES30.glEnableVertexAttribArray(i) else GLES30.glDisableVertexAttribArray(i)
}

private fun tex2D(w: Int, h: Int, fmt: Int, type: Int, filter: Int): Int {
    val t = newTex()
    GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, t)
    GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, fmt, w, h, 0, fmt, type, null)
    GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, filter)
    GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, filter)
    GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
    GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
    return t
}

// ── Main renderer ─────────────────────────────────────────────────────────────
class Renderer(private val g: Game) : GLSurfaceView.Renderer {
    private lateinit var mainP: Prog
    private lateinit var treeP: Prog
    private lateinit var skyP: Prog
    private lateinit var sprP: Prog
    private lateinit var decP: Prog
    private lateinit var shadP: Prog
    private lateinit var brightP: Prog
    private lateinit var blurP: Prog
    private lateinit var compP: Prog

    // Shadow FBO
    private var shadowFbo = 0; private var shadowTex = 0
    // Bloom FBOs
    private var sceneFbo = 0; private var sceneTex = 0; private var sceneRbo = 0
    private var bloom0Fbo = 0; private var bloom0Tex = 0
    private var bloom1Fbo = 0; private var bloom1Tex = 0
    private var quadBuf = 0

    private var props: Array<Gpu>? = null
    private var chunkGpu: Array<ChunkGpu>? = null
    private var outerGpu: Gpu? = null; private var mountGpu: Gpu? = null
    private var uploaded = false
    private val carCache = HashMap<Int, Array<Gpu>>()
    private var albiTex = 0
    private var skidBuf = 0
    private var decBuf2 = 0
    private var sprBuf2 = 0

    private val sprA = FloatArray(11 * 6 * 700)
    private val sprB = FloatArray(11 * 6 * 500)
    private val sprFB = fbuf(11 * 6 * 700)
    private val decA = FloatArray(9 * 6 * 24)
    private val decFB = fbuf(9 * 6 * 24)
    private val skFB = fbuf(1500 * 54)

    private val proj = FloatArray(16); private val view = FloatArray(16); private val vp = FloatArray(16)
    private val mId = FloatArray(16); private val mYaw = FloatArray(16); private val mBody = FloatArray(16); private val mTmp = FloatArray(16)
    private val lvp = FloatArray(16); private val lproj = FloatArray(16); private val lview = FloatArray(16)
    private var W = 1; private var H = 1
    private var aspect = 1.78f; private var last = 0L

    private val hor = floatArrayOf(0.62f, 0.76f, 0.94f)
    private val zen = floatArrayOf(0.14f, 0.30f, 0.75f)
    private val sun = floatArrayOf(0.40f, 0.78f, 0.48f)

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        mainP  = Prog(MAIN_VS, MAIN_FS.replace("NOISE_PLACEHOLDER", NOISE_GLSL).replace("SHADOW_SIZE_VAL", SHADOW_SIZE.toString()))
        treeP  = Prog(TREE_VS, MAIN_FS.replace("NOISE_PLACEHOLDER", NOISE_GLSL).replace("SHADOW_SIZE_VAL", SHADOW_SIZE.toString()))
        skyP   = Prog(SKY_VS, SKY_FS.replace("NOISE_PLACEHOLDER", NOISE_GLSL))
        sprP   = Prog(SPR_VS,  SPR_FS)
        decP   = Prog(DEC_VS,  DEC_FS)
        shadP  = Prog(SHAD_VS, SHAD_FS)
        brightP= Prog(QUAD_VS, BRIGHT_FS)
        blurP  = Prog(QUAD_VS, BLUR_FS)
        compP  = Prog(QUAD_VS, COMP_FS)

        props = Array(4) { uploadMesh(buildProps()[it]) }

        val q = floatArrayOf(-1f,-1f,1f,-1f,-1f,1f,1f,1f)
        val qb = fbuf(8); qb.put(q); qb.position(0)
        quadBuf = newBuf()
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, quadBuf)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, 32, qb, GLES30.GL_STATIC_DRAW)

        shadowFbo = newFbo(); shadowTex = tex2D(SHADOW_SIZE, SHADOW_SIZE, GLES30.GL_DEPTH_COMPONENT, GLES30.GL_UNSIGNED_INT, GLES30.GL_NEAREST)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, shadowTex)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_COMPARE_MODE, GLES30.GL_COMPARE_REF_TO_TEXTURE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_COMPARE_FUNC, GLES30.GL_LEQUAL)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, shadowFbo)
        GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_DEPTH_ATTACHMENT, GLES30.GL_TEXTURE_2D, shadowTex, 0)
        GLES30.glDrawBuffers(1, intArrayOf(GLES30.GL_NONE), 0)
        GLES30.glReadBuffer(GLES30.GL_NONE)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)

        makeAlbedoTex()
        skidBuf = newBuf(); decBuf2 = newBuf(); sprBuf2 = newBuf()
        carCache.clear(); uploaded = false; chunkGpu = null
        Matrix.setIdentityM(mId, 0)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        last = 0L
    }

    private fun makeAlbedoTex() {
        val bmp = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp); cv.drawColor(Color.rgb(140, 142, 148))
        val p = Paint(); val rnd = java.util.Random(3)
        for (cy in 0 until 8) for (cx in 0 until 8) {
            val x = cx * 32f; val y = cy * 32f
            val k = rnd.nextFloat()
            p.color = when {
                k < 0.35f -> Color.rgb(25, 55, 95)
                k < 0.65f -> Color.rgb(35, 70, 115)
                k < 0.90f -> Color.rgb(20, 42, 78)
                else -> Color.rgb(90, 145, 195)
            }
            cv.drawRect(x+5, y+6, x+27, y+26, p)
            p.color = Color.rgb(110, 112, 118); cv.drawRect(x+5, y+26, x+27, y+28, p)
        }
        albiTex = newTex()
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, albiTex)
        GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0)
        GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR_MIPMAP_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_REPEAT)
        bmp.recycle()
    }

    private fun makeBloomFbos(w: Int, h: Int) {
        val bw = w / 2; val bh = h / 2
        sceneFbo = newFbo()
        sceneTex = tex2D(w, h, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, GLES30.GL_LINEAR)
        sceneRbo = newRbo()
        GLES30.glBindRenderbuffer(GLES30.GL_RENDERBUFFER, sceneRbo)
        GLES30.glRenderbufferStorage(GLES30.GL_RENDERBUFFER, GLES30.GL_DEPTH_COMPONENT24, w, h)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, sceneFbo)
        GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, sceneTex, 0)
        GLES30.glFramebufferRenderbuffer(GLES30.GL_FRAMEBUFFER, GLES30.GL_DEPTH_ATTACHMENT, GLES30.GL_RENDERBUFFER, sceneRbo)
        bloom0Fbo = newFbo(); bloom0Tex = tex2D(bw, bh, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, GLES30.GL_LINEAR)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, bloom0Fbo)
        GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, bloom0Tex, 0)
        bloom1Fbo = newFbo(); bloom1Tex = tex2D(bw, bh, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, GLES30.GL_LINEAR)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, bloom1Fbo)
        GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, bloom1Tex, 0)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        W = width; H = height; aspect = width.toFloat() / maxOf(1, height)
        GLES30.glViewport(0, 0, width, height)
        makeBloomFbos(width, height)
    }

    private fun uploadWorld() {
        val w = g.world
        outerGpu = uploadMesh(w.outer!!); mountGpu = uploadMesh(w.mountains!!)
        val gl = ArrayList<FloatArray>(); val pl = ArrayList<Float>()
        chunkGpu = Array(NC * NC) { i ->
            val cd = w.chunks[i]; val cg = ChunkGpu()
            cg.ground = upMesh(cd.ground); cg.road = upMesh(cd.road); cg.marks = upMesh(cd.marks)
            for (k in 0..3) cg.inst[k] = upInst(cd.inst[k]); cg
        }
        w.releaseMeshes(); uploaded = true
    }

    private fun partsFor(style: Int) = carCache.getOrPut(style) {
        val m = buildCar(style)
        arrayOf(uploadMesh(m.paint), uploadMesh(m.trim), uploadMesh(m.glass), uploadMesh(m.head), uploadMesh(m.tail), uploadMesh(m.wheel))
    }

    private fun sceneUniforms(p: Prog, fog: Float) {
        GLES30.glUniformMatrix4fv(p.u("uVP"), 1, false, vp, 0)
        GLES30.glUniformMatrix4fv(p.u("uLVP"), 1, false, lvp, 0)
        GLES30.glUniform3f(p.u("uCam"), g.camX, g.camY, g.camZ)
        GLES30.glUniform3f(p.u("uSun"), sun[0], sun[1], sun[2])
        GLES30.glUniform3f(p.u("uSunC"), 1.08f, 0.95f, 0.80f)
        GLES30.glUniform3f(p.u("uAmbS"), 0.38f, 0.46f, 0.68f)
        GLES30.glUniform3f(p.u("uAmbG"), 0.20f, 0.19f, 0.16f)
        GLES30.glUniform3f(p.u("uHor"), hor[0], hor[1], hor[2])
        GLES30.glUniform3f(p.u("uZen"), zen[0], zen[1], zen[2])
        GLES30.glUniform3f(p.u("uFogC"), hor[0], hor[1], hor[2])
        GLES30.glUniform1f(p.u("uFogD"), fog)
        GLES30.glUniform1i(p.u("uTex"), 0)
        GLES30.glUniform1i(p.u("uShadow"), 1)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE1)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, shadowTex)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, albiTex)
    }

    private fun obj(p: Prog, model: FloatArray, r: Float, gg: Float, b: Float, gloss: Float, metal: Float = 0f) {
        GLES30.glUniformMatrix4fv(p.u("uModel"), 1, false, model, 0)
        GLES30.glUniform3f(p.u("uTint"), r, gg, b)
        GLES30.glUniform1f(p.u("uGloss"), gloss)
        GLES30.glUniform1f(p.u("uMetal"), metal)
    }

    private fun bindMesh(gpu: Gpu) {
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, gpu.id)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 48, 0)
        GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, 48, 12)
        GLES30.glVertexAttribPointer(2, 4, GLES30.GL_FLOAT, false, 48, 24)
        GLES30.glVertexAttribPointer(3, 2, GLES30.GL_FLOAT, false, 48, 40)
    }

    private fun drawGpu(gpu: Gpu) { bindMesh(gpu); GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, gpu.count) }

    private fun drawCar(parts: Array<Gpu>, x: Float, z: Float, psi: Float, pitch: Float, roll: Float,
                        steerDeg: Float, spinDeg: Float, paint: FloatArray, brake: Boolean, p: Prog) {
        Matrix.setIdentityM(mYaw, 0)
        Matrix.translateM(mYaw, 0, x, 0f, z)
        Matrix.rotateM(mYaw, 0, Math.toDegrees(psi.toDouble()).toFloat(), 0f, 1f, 0f)
        System.arraycopy(mYaw, 0, mBody, 0, 16)
        Matrix.translateM(mBody, 0, 0f, 0.45f, 0f)
        Matrix.rotateM(mBody, 0, pitch, 1f, 0f, 0f)
        Matrix.rotateM(mBody, 0, roll, 0f, 0f, 1f)
        Matrix.translateM(mBody, 0, 0f, -0.45f, 0f)
        // Paint - metallic
        obj(p, mBody, paint[0], paint[1], paint[2], 0.85f, 0.85f); bindMesh(parts[0]); GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, parts[0].count)
        // Trim - chrome
        obj(p, mBody, 0.85f, 0.87f, 0.90f, 0.95f, 0.90f); drawGpu(parts[1])
        // Glass
        obj(p, mBody, 0.08f, 0.14f, 0.20f, 0.60f, 0f); drawGpu(parts[2])
        // Headlights
        obj(p, mBody, 1f, 1f, 1f, 0f, 0f); drawGpu(parts[3])
        // Tail lights
        val tl = if (brake) 1.9f else 0.7f
        obj(p, mBody, tl, tl * 0.03f, tl * 0.03f, 0f, 0f); drawGpu(parts[4])
        // Wheels
        bindMesh(parts[5])
        for (i in 0..3) {
            val xl = if (i % 2 == 0) 0.84f else -0.84f
            val zl = if (i < 2) -1.3f else 1.3f
            System.arraycopy(mYaw, 0, mTmp, 0, 16)
            Matrix.translateM(mTmp, 0, xl, 0.34f, zl)
            if (i >= 2) Matrix.rotateM(mTmp, 0, steerDeg, 0f, 1f, 0f)
            Matrix.rotateM(mTmp, 0, spinDeg, 1f, 0f, 0f)
            obj(p, mTmp, 0.75f, 0.77f, 0.80f, 0.65f, 0.80f)
            GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, parts[5].count)
        }
    }

    private fun drawQuad() {
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, quadBuf)
        GLES30.glVertexAttribPointer(0, 2, GLES30.GL_FLOAT, false, 8, 0)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
    }

    private fun buildLightVP(car: CarPhysics) {
        val lx = sun[0] * 300f; val ly = sun[1] * 300f; val lz = sun[2] * 300f
        val tx = car.x; val tz = car.z
        Matrix.orthoM(lproj, 0, -260f, 260f, -260f, 260f, 1f, 800f)
        Matrix.setLookAtM(lview, 0, tx + lx, ly, tz + lz, tx, 0f, tz, 0f, 1f, 0f)
        Matrix.multiplyMM(lvp, 0, lproj, 0, lview, 0)
    }

    private fun shadowPass(car: CarPhysics) {
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, shadowFbo)
        GLES30.glViewport(0, 0, SHADOW_SIZE, SHADOW_SIZE)
        GLES30.glClear(GLES30.GL_DEPTH_BUFFER_BIT)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glUseProgram(shadP.id)
        GLES30.glUniformMatrix4fv(shadP.u("uLVP"), 1, false, lvp, 0)
        enableAttribs(1)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 48, 0)
        val cgs = chunkGpu!!
        for (i in 0 until NC * NC) {
            val dx = -HALF + (i % NC + 0.5f) * CH - car.x
            val dz = -HALF + (i / NC + 0.5f) * CH - car.z
            if (dx * dx + dz * dz > 500f * 500f) continue
            cgs[i].ground?.let {
                GLES30.glUniformMatrix4fv(shadP.u("uModel"), 1, false, mId, 0)
                GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, it.id)
                GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, it.count)
            }
        }
        // Car shadow
        GLES30.glUniformMatrix4fv(shadP.u("uModel"), 1, false, mBody, 0)
        val parts = partsFor(g.spec().style)
        bindMesh(parts[0]); GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, parts[0].count)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
        GLES30.glViewport(0, 0, W, H)
    }

    private fun sprite(a: FloatArray, idx: Int, x: Float, y: Float, z: Float, s: Float, r: Float, gg: Float, b: Float, al: Float): Int {
        var i = idx
        if (i + 66 > a.size) return i
        for (k in 0 until 6) {
            a[i++] = x; a[i++] = y; a[i++] = z
            a[i++] = SPR_K[k * 2]; a[i++] = SPR_K[k * 2 + 1]
            a[i++] = s; a[i++] = r; a[i++] = gg; a[i++] = b; a[i++] = al; a[i++] = 0f
        }
        return i
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        var dt = if (last == 0L) 0.016f else ((now - last) / 1e9f).coerceIn(0.001f, 0.05f)
        last = now
        g.update(dt)
        if (!g.ready) { GLES30.glClearColor(0.03f, 0.04f, 0.08f, 1f); GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT); return }
        if (!uploaded) { uploadWorld(); return }

        val car = g.car

        Matrix.perspectiveM(proj, 0, g.fov, aspect, 1f, 4500f)
        Matrix.setLookAtM(view, 0, g.camX, g.camY, g.camZ, g.lookX, g.lookY, g.lookZ, 0f, 1f, 0f)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)
        System.arraycopy(vp, 0, g.vp, 0, 16)

        var fX = g.lookX - g.camX; var fY = g.lookY - g.camY; var fZ = g.lookZ - g.camZ
        val fl = sqrt(fX*fX+fY*fY+fZ*fZ); fX/=fl; fY/=fl; fZ/=fl
        var rX = -fZ; val rY = 0f; var rZ = fX
        val rl = sqrt(rX*rX+rZ*rZ).coerceAtLeast(0.0001f); rX/=rl; rZ/=rl
        val uX=rY*fZ-rZ*fY; val uY=rZ*fX-rX*fZ; val uZ=rX*fY-rY*fX

        buildLightVP(car)
        shadowPass(car)

        // ── Render to scene FBO ──────────────────────────────────────────────
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, sceneFbo)
        GLES30.glViewport(0, 0, W, H)
        GLES30.glClearColor(hor[0], hor[1], hor[2], 1f)
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

        // Sky
        GLES30.glDisable(GLES30.GL_DEPTH_TEST)
        GLES30.glUseProgram(skyP.id)
        val ty = tan(Math.toRadians(g.fov / 2.0)).toFloat()
        GLES30.glUniform3f(skyP.u("uF"), fX, fY, fZ); GLES30.glUniform3f(skyP.u("uR"), rX, rY, rZ); GLES30.glUniform3f(skyP.u("uU"), uX, uY, uZ)
        GLES30.glUniform2f(skyP.u("uT"), ty * aspect, ty)
        GLES30.glUniform3f(skyP.u("uHor"), hor[0], hor[1], hor[2]); GLES30.glUniform3f(skyP.u("uZen"), zen[0], zen[1], zen[2])
        GLES30.glUniform3f(skyP.u("uSun"), sun[0], sun[1], sun[2]); GLES30.glUniform1f(skyP.u("uTime"), g.time)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, quadBuf)
        enableAttribs(1); GLES30.glVertexAttribPointer(0, 2, GLES30.GL_FLOAT, false, 8, 0)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)

        // World
        val FOG = 0.0008f
        GLES30.glUseProgram(mainP.id); sceneUniforms(mainP, FOG)
        enableAttribs(4)
        obj(mainP, mId, 1f, 1f, 1f, 0.02f); outerGpu?.let { drawGpu(it) }
        GLES30.glUniform1f(mainP.u("uFogD"), 0.00035f)
        mountGpu?.let { obj(mainP, mId, 1f, 1f, 1f, 0.25f); drawGpu(it) }
        GLES30.glUniform1f(mainP.u("uFogD"), FOG)
        val cgs = chunkGpu!!
        val vis = IntArray(NC * NC); val visD = FloatArray(NC * NC); var visN = 0
        for (i in 0 until NC * NC) {
            val dx = -HALF + (i % NC + 0.5f) * CH - g.camX
            val dz = -HALF + (i / NC + 0.5f) * CH - g.camZ
            val d2 = dx * dx + dz * dz
            if (d2 < 2500f * 2500f) { vis[visN] = i; visD[visN] = d2; visN++ }
        }
        obj(mainP, mId, 1f, 1f, 1f, 0.06f)
        for (j in 0 until visN) cgs[vis[j]].ground?.let { drawGpu(it) }
        GLES30.glEnable(GLES30.GL_POLYGON_OFFSET_FILL)
        GLES30.glPolygonOffset(-1f, -1f)
        for (j in 0 until visN) cgs[vis[j]].road?.let { obj(mainP, mId, 1f, 1f, 1f, 0.35f); drawGpu(it) }
        GLES30.glPolygonOffset(-2f, -2f)
        for (j in 0 until visN) cgs[vis[j]].marks?.let { drawGpu(it) }
        GLES30.glDisable(GLES30.GL_POLYGON_OFFSET_FILL)

        // Trees instanced
        GLES30.glUseProgram(treeP.id); sceneUniforms(treeP, FOG)
        GLES30.glUniform1f(treeP.u("uMetal"), 0f)
        val pr = props!!
        for (k in 0..3) {
            val lim = TREE_LIM[k]
            bindMesh(pr[k])
            for (j in 0 until visN) {
                if (visD[j] > lim * lim) continue
                val ig = cgs[vis[j]].inst[k] ?: continue
                GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, ig.id)
                GLES30.glEnableVertexAttribArray(4)
                GLES30.glVertexAttribPointer(4, 4, GLES30.GL_FLOAT, false, 16, 0)
                GLES30.glVertexAttribDivisor(4, 1)
                GLES30.glDrawArraysInstanced(GLES30.GL_TRIANGLES, 0, pr[k].count, ig.count)
                GLES30.glVertexAttribDivisor(4, 0)
            }
        }
        GLES30.glDisableVertexAttribArray(4)

        // Cars
        GLES30.glUseProgram(mainP.id); sceneUniforms(mainP, FOG); enableAttribs(4)
        val pc = PAINTS[g.paintIdx]
        val pitch = (-car.ax * 0.5f).coerceIn(-4f, 4f)
        val roll = (car.ay * 0.35f).coerceIn(-5f, 5f)
        drawCar(partsFor(g.spec().style), car.x, car.z, car.psi, pitch, roll,
            Math.toDegrees(car.steerAngle.toDouble()).toFloat(), Math.toDegrees(car.wheelSpin.toDouble()).toFloat(), pc, g.braking, mainP)
        for (r in g.net.remotes.values) {
            if (!r.inited) { r.x = r.tx; r.z = r.tz; r.psi = r.tpsi; r.inited = true }
            val k = minOf(1f, dt * 9f)
            if (abs(r.tx - r.x) > 60f || abs(r.tz - r.z) > 60f) { r.x = r.tx; r.z = r.tz }
            r.x += (r.tx - r.x) * k; r.z += (r.tz - r.z) * k
            var da = r.tpsi - r.psi; while (da > PI) da -= (2 * PI).toFloat(); while (da < -PI) da += (2 * PI).toFloat()
            r.psi += da * k; r.spin += r.u / CarPhysics.RW * dt
            drawCar(partsFor(CARS[r.car].style), r.x, r.z, r.psi, 0f, 0f,
                Math.toDegrees(r.steer.toDouble()).toFloat(), Math.toDegrees(r.spin.toDouble()).toFloat(), PAINTS[r.paint], false, mainP)
        }

        // Decals
        GLES30.glEnable(GLES30.GL_BLEND)
        GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)
        GLES30.glDepthMask(false)
        GLES30.glUseProgram(decP.id)
        GLES30.glUniformMatrix4fv(decP.u("uVP"), 1, false, vp, 0)
        enableAttribs(3)
        val fx = g.fx
        if (fx.skCount > 0) {
            skFB.clear()
            if (fx.skCount == fx.skMax) { skFB.put(fx.sk, fx.skHead * 54, (fx.skMax - fx.skHead) * 54); skFB.put(fx.sk, 0, fx.skHead * 54) }
            else skFB.put(fx.sk, 0, fx.skCount * 54)
            skFB.position(0)
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, this.skidBuf)
            GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, fx.skCount * 54 * 4, skFB, GLES30.GL_STREAM_DRAW)
            drawDecalBound(fx.skCount * 6)
        }
        val sn = sin(car.psi); val cs = cos(car.psi)
        var di = 0
        di = decQuad(decA, di, car.x, car.z, sn, cs, 3.1f, 1.9f, 0.10f, 0.6f, 0.1f, 0.9f, 0.15f)
        di = decQuad(decA, di, car.x, car.z, sn, cs, 2.7f, 1.45f, 0.11f, 0f, 0f, 0f, 0.5f)
        decFB.clear(); decFB.put(decA, 0, di); decFB.position(0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, decBuf2)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, di * 4, decFB, GLES30.GL_STREAM_DRAW)
        drawDecalBound(di / 9)

        // Sprites
        GLES30.glUseProgram(sprP.id)
        GLES30.glUniformMatrix4fv(sprP.u("uVP"), 1, false, vp, 0)
        GLES30.glUniform3f(sprP.u("uRt"), rX, rY, rZ); GLES30.glUniform3f(sprP.u("uUp"), uX, uY, uZ)
        var ia = 0; var ib = 0
        if (g.braking) ia = sprite(sprA, ia, car.x - sn * 2.15f, 0.82f, car.z - cs * 2.15f, 1.3f, 1f, 0.05f, 0.05f, 0.8f)
        val p2 = fx.p
        for (i in 0 until fx.cnt) {
            val o = i * 10; val age = p2[o + 6] / p2[o + 7]; val kind = p2[o + 9]
            if (kind == 1f) ia = sprite(sprA, ia, p2[o], p2[o+1], p2[o+2], p2[o+8]*(1f-age*.5f), 1f, .55f+.3f*age, .15f, .9f*(1f-age))
            else {
                val cr = if (kind==0f) .93f else if (kind==2f) .74f else .50f
                val cg = if (kind==0f) .93f else if (kind==2f) .62f else .55f
                val cb = if (kind==0f) .95f else if (kind==2f) .46f else .34f
                ib = sprite(sprB, ib, p2[o], p2[o+1], p2[o+2], p2[o+8]*(0.6f+age*2.2f), cr, cg, cb, .40f*(1f-age))
            }
        }
        if (g.raceOn && g.cpI < g.cpN) {
            val bx = g.cps[g.cpI * 2]; val bz = g.cps[g.cpI * 2 + 1]
            for (k in 0 until 14) ia = sprite(sprA, ia, bx, 2f + k * 4f, bz, 7f - k * .2f, .2f, .9f, 1f, .55f)
        }
        enableAttribs(4)

        if (ia > 0) { GLES30.glBlendFunc(GLES30.GL_ONE, GLES30.GL_ONE); drawSprites(sprA, ia, 0f, 2.2f, sprBuf2) }
        if (ib > 0) { GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA); drawSprites(sprB, ib, 1f, 0.8f, sprBuf2) }
        GLES30.glDepthMask(true); GLES30.glDisable(GLES30.GL_BLEND)

        // ── Bloom pass ───────────────────────────────────────────────────────
        val bw = W / 2; val bh = H / 2
        GLES30.glDisable(GLES30.GL_DEPTH_TEST)
        enableAttribs(1)
        // Bright extract
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, bloom0Fbo)
        GLES30.glViewport(0, 0, bw, bh)
        GLES30.glUseProgram(brightP.id)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0); GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, sceneTex)
        GLES30.glUniform1i(brightP.u("uT"), 0); drawQuad()
        // H blur
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, bloom1Fbo)
        GLES30.glUseProgram(blurP.id)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, bloom0Tex)
        GLES30.glUniform1i(blurP.u("uT"), 0); GLES30.glUniform2f(blurP.u("uDir"), 1f / bw, 0f); drawQuad()
        // V blur
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, bloom0Fbo)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, bloom1Tex)
        GLES30.glUniform2f(blurP.u("uDir"), 0f, 1f / bh); drawQuad()
        // Composite to screen
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
        GLES30.glViewport(0, 0, W, H)
        GLES30.glUseProgram(compP.id)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0); GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, sceneTex)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE1); GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, bloom0Tex)
        GLES30.glUniform1i(compP.u("uScene"), 0); GLES30.glUniform1i(compP.u("uBloom"), 1)
        GLES30.glUniform1f(compP.u("uExposure"), 1.05f); drawQuad()
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)


    }

    private fun drawSprites(a: FloatArray, len: Int, mode: Float, pw: Float, buf: Int) {
        sprFB.clear(); sprFB.put(a, 0, len); sprFB.position(0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, buf)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, len * 4, sprFB, GLES30.GL_STREAM_DRAW)
        GLES30.glUniform1f(sprP.u("uMode"), mode); GLES30.glUniform1f(sprP.u("uPow"), pw)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 44, 0)
        GLES30.glVertexAttribPointer(1, 2, GLES30.GL_FLOAT, false, 44, 12)
        GLES30.glVertexAttribPointer(2, 1, GLES30.GL_FLOAT, false, 44, 20)
        GLES30.glVertexAttribPointer(3, 4, GLES30.GL_FLOAT, false, 44, 24)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, len / 11)
    }

    private fun drawDecalBound(count: Int) {
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 36, 0)
        GLES30.glVertexAttribPointer(1, 2, GLES30.GL_FLOAT, false, 36, 12)
        GLES30.glVertexAttribPointer(2, 4, GLES30.GL_FLOAT, false, 36, 20)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, count)
    }

    private fun decQuad(a: FloatArray, idx: Int, cx: Float, cz: Float, sn: Float, cs: Float,
                        hl: Float, hw: Float, y: Float, r: Float, gg: Float, b: Float, al: Float): Int {
        var i = idx
        if (i + 54 > a.size) return i
        val fxv=sn*hl; val fzv=cs*hl; val lx=cs*hw; val lz=-sn*hw
        val px=floatArrayOf(cx-fxv-lx,cx+fxv-lx,cx+fxv+lx,cx-fxv-lx,cx+fxv+lx,cx-fxv+lx)
        val pz=floatArrayOf(cz-fzv-lz,cz+fzv-lz,cz+fzv+lz,cz-fzv-lz,cz+fzv+lz,cz-fzv+lz)
        val uu=floatArrayOf(-1f,-1f,1f,-1f,1f,1f,-1f,-1f,1f,1f,-1f,1f)
        for (k in 0 until 6) { a[i++]=px[k]; a[i++]=y; a[i++]=pz[k]; a[i++]=uu[k*2]; a[i++]=uu[k*2+1]; a[i++]=r; a[i++]=gg; a[i++]=b; a[i++]=al }
        return i
    }

    companion object {
        private val SPR_K = floatArrayOf(-1f,-1f,1f,-1f,1f,1f,-1f,-1f,1f,1f,-1f,1f)
        private val TREE_LIM = floatArrayOf(1000f, 1000f, 400f, 600f)
    }
}
